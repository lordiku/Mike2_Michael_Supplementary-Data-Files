
% Data is recorded to an MS Excel spreadsheet when [CalcOut_p] is called. 
% Specifically, data relating to the catalyst pellet scale domain is
% recorded. 

% [CalcOut_p] also manipulates the spreadsheet to allow for parametric data
% to be recorded based on the temperature or H2S increment simulated. 

% Data is retrieved from the simulation. 
MatrixSummary_p1 = zeros(cellnum,partnum); MatrixSummary_p2 = zeros(cellnum,partnum);
MatrixSummary_p3 = zeros(cellnum,partnum); MatrixSummary_p4 = zeros(cellnum,partnum);
MatrixSummary_p5 = zeros(cellnum,partnum); MatrixSummary_p6 = zeros(cellnum,partnum);
MatrixSummary_p7 = zeros(cellnum,partnum); MatrixSummary_p8 = zeros(cellnum,partnum);
MatrixSummary_p9 = zeros(cellnum,partnum); MatrixSummary_p10 = zeros(cellnum,partnum);

MatrixSummary_p1 = pMatrixTemp(:,:,timestep); SimData1 = strcat('B',num2str(cellnum*0+5*1));
MatrixSummary_p2 = pMatrixDens(:,:,timestep); SimData2 = strcat('B',num2str(cellnum*1+5*2));
MatrixSummary_p3 = pMatrixFracM_CH4(:,:,timestep); SimData3 = strcat('B',num2str(cellnum*2+5*3));
MatrixSummary_p4 = pMatrixFracM_CO2(:,:,timestep); SimData4 = strcat('B',num2str(cellnum*3+5*4));
MatrixSummary_p5 = pMatrixFracM_H2O(:,:,timestep); SimData5 = strcat('B',num2str(cellnum*4+5*5));
MatrixSummary_p6 = pMatrixFracM_CO(:,:,timestep); SimData6 = strcat('B',num2str(cellnum*5+5*6));
MatrixSummary_p7 = pMatrixFracM_H2(:,:,timestep); SimData7 = strcat('B',num2str(cellnum*6+5*7));
MatrixSummary_p8 = pMatrixFracM_H2S(:,:,timestep); SimData8 = strcat('B',num2str(cellnum*7+5*8));
MatrixSummary_p9 = pMatrixFracM_N2(:,:,timestep); SimData9 = strcat('B',num2str(cellnum*8+5*9));
MatrixSummary_p10 = pMatrixFracM_O2(:,:,timestep); SimData10 = strcat('B',num2str(cellnum*9+5*10));

% Simulation data is printed to a temporary Excel sheet called "DataDump_p"
% where it can then be moved into different spreadsheets depending on need.

% Navigation of the spreadsheet is done via a "switch-case" structure based
% on the H2S and temperature cases being ran. Generally, H2S will be
% recorded in individual workbooks, while temperature will be recorded
% in individual spreadsheets. The command "writematrix" then instructs
% MATLAB to record the information to MS Excel in the appropriate spot.
% Both simulated and equilibrium data are recorded. 

switch H2SParam
    case 1
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary_p1,'DataDump0_p.xlsx','Sheet',1,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump0_p.xlsx','Sheet',1,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump0_p.xlsx','Sheet',1,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump0_p.xlsx','Sheet',1,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump0_p.xlsx','Sheet',1,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump0_p.xlsx','Sheet',1,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump0_p.xlsx','Sheet',1,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump0_p.xlsx','Sheet',1,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump0_p.xlsx','Sheet',1,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump0_p.xlsx','Sheet',1,'Range',SimData10);
            case 2 % 1023 K
                writematrix(MatrixSummary_p1,'DataDump0_p.xlsx','Sheet',2,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump0_p.xlsx','Sheet',2,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump0_p.xlsx','Sheet',2,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump0_p.xlsx','Sheet',2,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump0_p.xlsx','Sheet',2,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump0_p.xlsx','Sheet',2,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump0_p.xlsx','Sheet',2,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump0_p.xlsx','Sheet',2,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump0_p.xlsx','Sheet',2,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump0_p.xlsx','Sheet',2,'Range',SimData10);
            case 3 % 1073 K
                writematrix(MatrixSummary_p1,'DataDump0_p.xlsx','Sheet',3,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump0_p.xlsx','Sheet',3,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump0_p.xlsx','Sheet',3,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump0_p.xlsx','Sheet',3,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump0_p.xlsx','Sheet',3,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump0_p.xlsx','Sheet',3,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump0_p.xlsx','Sheet',3,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump0_p.xlsx','Sheet',3,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump0_p.xlsx','Sheet',3,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump0_p.xlsx','Sheet',3,'Range',SimData10);
            case 4 % 1123 K
                writematrix(MatrixSummary_p1,'DataDump0_p.xlsx','Sheet',4,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump0_p.xlsx','Sheet',4,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump0_p.xlsx','Sheet',4,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump0_p.xlsx','Sheet',4,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump0_p.xlsx','Sheet',4,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump0_p.xlsx','Sheet',4,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump0_p.xlsx','Sheet',4,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump0_p.xlsx','Sheet',4,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump0_p.xlsx','Sheet',4,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump0_p.xlsx','Sheet',4,'Range',SimData10);
            case 5 % 1173 K
                writematrix(MatrixSummary_p1,'DataDump0_p.xlsx','Sheet',5,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump0_p.xlsx','Sheet',5,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump0_p.xlsx','Sheet',5,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump0_p.xlsx','Sheet',5,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump0_p.xlsx','Sheet',5,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump0_p.xlsx','Sheet',5,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump0_p.xlsx','Sheet',5,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump0_p.xlsx','Sheet',5,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump0_p.xlsx','Sheet',5,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump0_p.xlsx','Sheet',5,'Range',SimData10);
            case 6 % 1223 K
                writematrix(MatrixSummary_p1,'DataDump0_p.xlsx','Sheet',6,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump0_p.xlsx','Sheet',6,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump0_p.xlsx','Sheet',6,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump0_p.xlsx','Sheet',6,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump0_p.xlsx','Sheet',6,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump0_p.xlsx','Sheet',6,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump0_p.xlsx','Sheet',6,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump0_p.xlsx','Sheet',6,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump0_p.xlsx','Sheet',6,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump0_p.xlsx','Sheet',6,'Range',SimData10);
            case 7 % 1273 K
                writematrix(MatrixSummary_p1,'DataDump0_p.xlsx','Sheet',7,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump0_p.xlsx','Sheet',7,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump0_p.xlsx','Sheet',7,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump0_p.xlsx','Sheet',7,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump0_p.xlsx','Sheet',7,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump0_p.xlsx','Sheet',7,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump0_p.xlsx','Sheet',7,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump0_p.xlsx','Sheet',7,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump0_p.xlsx','Sheet',7,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump0_p.xlsx','Sheet',7,'Range',SimData10);
            case 8 % 1323 K
                writematrix(MatrixSummary_p1,'DataDump0_p.xlsx','Sheet',8,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump0_p.xlsx','Sheet',8,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump0_p.xlsx','Sheet',8,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump0_p.xlsx','Sheet',8,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump0_p.xlsx','Sheet',8,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump0_p.xlsx','Sheet',8,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump0_p.xlsx','Sheet',8,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump0_p.xlsx','Sheet',8,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump0_p.xlsx','Sheet',8,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump0_p.xlsx','Sheet',8,'Range',SimData10);
            case 9 % 1373 K
                writematrix(MatrixSummary_p1,'DataDump0_p.xlsx','Sheet',9,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump0_p.xlsx','Sheet',9,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump0_p.xlsx','Sheet',9,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump0_p.xlsx','Sheet',9,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump0_p.xlsx','Sheet',9,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump0_p.xlsx','Sheet',9,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump0_p.xlsx','Sheet',9,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump0_p.xlsx','Sheet',9,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump0_p.xlsx','Sheet',9,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump0_p.xlsx','Sheet',9,'Range',SimData10);
        end
    case 2
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary_p1,'DataDump25_p.xlsx','Sheet',1,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump25_p.xlsx','Sheet',1,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump25_p.xlsx','Sheet',1,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump25_p.xlsx','Sheet',1,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump25_p.xlsx','Sheet',1,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump25_p.xlsx','Sheet',1,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump25_p.xlsx','Sheet',1,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump25_p.xlsx','Sheet',1,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump25_p.xlsx','Sheet',1,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump25_p.xlsx','Sheet',1,'Range',SimData10);
            case 2 % 1023 K
                writematrix(MatrixSummary_p1,'DataDump25_p.xlsx','Sheet',2,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump25_p.xlsx','Sheet',2,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump25_p.xlsx','Sheet',2,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump25_p.xlsx','Sheet',2,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump25_p.xlsx','Sheet',2,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump25_p.xlsx','Sheet',2,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump25_p.xlsx','Sheet',2,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump25_p.xlsx','Sheet',2,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump25_p.xlsx','Sheet',2,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump25_p.xlsx','Sheet',2,'Range',SimData10);
            case 3 % 1073 K
                writematrix(MatrixSummary_p1,'DataDump25_p.xlsx','Sheet',3,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump25_p.xlsx','Sheet',3,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump25_p.xlsx','Sheet',3,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump25_p.xlsx','Sheet',3,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump25_p.xlsx','Sheet',3,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump25_p.xlsx','Sheet',3,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump25_p.xlsx','Sheet',3,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump25_p.xlsx','Sheet',3,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump25_p.xlsx','Sheet',3,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump25_p.xlsx','Sheet',3,'Range',SimData10);
            case 4 % 1123 K
                writematrix(MatrixSummary_p1,'DataDump25_p.xlsx','Sheet',4,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump25_p.xlsx','Sheet',4,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump25_p.xlsx','Sheet',4,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump25_p.xlsx','Sheet',4,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump25_p.xlsx','Sheet',4,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump25_p.xlsx','Sheet',4,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump25_p.xlsx','Sheet',4,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump25_p.xlsx','Sheet',4,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump25_p.xlsx','Sheet',4,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump25_p.xlsx','Sheet',4,'Range',SimData10);
            case 5 % 1173 K
                writematrix(MatrixSummary_p1,'DataDump25_p.xlsx','Sheet',5,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump25_p.xlsx','Sheet',5,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump25_p.xlsx','Sheet',5,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump25_p.xlsx','Sheet',5,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump25_p.xlsx','Sheet',5,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump25_p.xlsx','Sheet',5,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump25_p.xlsx','Sheet',5,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump25_p.xlsx','Sheet',5,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump25_p.xlsx','Sheet',5,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump25_p.xlsx','Sheet',5,'Range',SimData10);
            case 6 % 1223 K
                writematrix(MatrixSummary_p1,'DataDump25_p.xlsx','Sheet',6,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump25_p.xlsx','Sheet',6,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump25_p.xlsx','Sheet',6,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump25_p.xlsx','Sheet',6,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump25_p.xlsx','Sheet',6,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump25_p.xlsx','Sheet',6,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump25_p.xlsx','Sheet',6,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump25_p.xlsx','Sheet',6,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump25_p.xlsx','Sheet',6,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump25_p.xlsx','Sheet',6,'Range',SimData10);
            case 7 % 1273 K
                writematrix(MatrixSummary_p1,'DataDump25_p.xlsx','Sheet',7,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump25_p.xlsx','Sheet',7,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump25_p.xlsx','Sheet',7,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump25_p.xlsx','Sheet',7,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump25_p.xlsx','Sheet',7,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump25_p.xlsx','Sheet',7,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump25_p.xlsx','Sheet',7,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump25_p.xlsx','Sheet',7,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump25_p.xlsx','Sheet',7,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump25_p.xlsx','Sheet',7,'Range',SimData10);
            case 8 % 1323 K
                writematrix(MatrixSummary_p1,'DataDump25_p.xlsx','Sheet',8,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump25_p.xlsx','Sheet',8,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump25_p.xlsx','Sheet',8,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump25_p.xlsx','Sheet',8,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump25_p.xlsx','Sheet',8,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump25_p.xlsx','Sheet',8,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump25_p.xlsx','Sheet',8,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump25_p.xlsx','Sheet',8,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump25_p.xlsx','Sheet',8,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump25_p.xlsx','Sheet',8,'Range',SimData10);
            case 9 % 1373 K
                writematrix(MatrixSummary_p1,'DataDump25_p.xlsx','Sheet',9,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump25_p.xlsx','Sheet',9,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump25_p.xlsx','Sheet',9,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump25_p.xlsx','Sheet',9,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump25_p.xlsx','Sheet',9,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump25_p.xlsx','Sheet',9,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump25_p.xlsx','Sheet',9,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump25_p.xlsx','Sheet',9,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump25_p.xlsx','Sheet',9,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump25_p.xlsx','Sheet',9,'Range',SimData10);
        end
    case 3
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary_p1,'DataDump50_p.xlsx','Sheet',1,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump50_p.xlsx','Sheet',1,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump50_p.xlsx','Sheet',1,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump50_p.xlsx','Sheet',1,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump50_p.xlsx','Sheet',1,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump50_p.xlsx','Sheet',1,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump50_p.xlsx','Sheet',1,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump50_p.xlsx','Sheet',1,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump50_p.xlsx','Sheet',1,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump50_p.xlsx','Sheet',1,'Range',SimData10);
            case 2 % 1023 K
                writematrix(MatrixSummary_p1,'DataDump50_p.xlsx','Sheet',2,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump50_p.xlsx','Sheet',2,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump50_p.xlsx','Sheet',2,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump50_p.xlsx','Sheet',2,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump50_p.xlsx','Sheet',2,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump50_p.xlsx','Sheet',2,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump50_p.xlsx','Sheet',2,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump50_p.xlsx','Sheet',2,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump50_p.xlsx','Sheet',2,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump50_p.xlsx','Sheet',2,'Range',SimData10);
            case 3 % 1073 K
                writematrix(MatrixSummary_p1,'DataDump50_p.xlsx','Sheet',3,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump50_p.xlsx','Sheet',3,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump50_p.xlsx','Sheet',3,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump50_p.xlsx','Sheet',3,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump50_p.xlsx','Sheet',3,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump50_p.xlsx','Sheet',3,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump50_p.xlsx','Sheet',3,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump50_p.xlsx','Sheet',3,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump50_p.xlsx','Sheet',3,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump50_p.xlsx','Sheet',3,'Range',SimData10);
            case 4 % 1123 K
                writematrix(MatrixSummary_p1,'DataDump50_p.xlsx','Sheet',4,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump50_p.xlsx','Sheet',4,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump50_p.xlsx','Sheet',4,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump50_p.xlsx','Sheet',4,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump50_p.xlsx','Sheet',4,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump50_p.xlsx','Sheet',4,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump50_p.xlsx','Sheet',4,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump50_p.xlsx','Sheet',4,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump50_p.xlsx','Sheet',4,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump50_p.xlsx','Sheet',4,'Range',SimData10);
            case 5 % 1173 K
                writematrix(MatrixSummary_p1,'DataDump50_p.xlsx','Sheet',5,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump50_p.xlsx','Sheet',5,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump50_p.xlsx','Sheet',5,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump50_p.xlsx','Sheet',5,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump50_p.xlsx','Sheet',5,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump50_p.xlsx','Sheet',5,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump50_p.xlsx','Sheet',5,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump50_p.xlsx','Sheet',5,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump50_p.xlsx','Sheet',5,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump50_p.xlsx','Sheet',5,'Range',SimData10);
            case 6 % 1223 K
                writematrix(MatrixSummary_p1,'DataDump50_p.xlsx','Sheet',6,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump50_p.xlsx','Sheet',6,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump50_p.xlsx','Sheet',6,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump50_p.xlsx','Sheet',6,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump50_p.xlsx','Sheet',6,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump50_p.xlsx','Sheet',6,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump50_p.xlsx','Sheet',6,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump50_p.xlsx','Sheet',6,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump50_p.xlsx','Sheet',6,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump50_p.xlsx','Sheet',6,'Range',SimData10);
            case 7 % 1273 K
                writematrix(MatrixSummary_p1,'DataDump50_p.xlsx','Sheet',7,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump50_p.xlsx','Sheet',7,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump50_p.xlsx','Sheet',7,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump50_p.xlsx','Sheet',7,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump50_p.xlsx','Sheet',7,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump50_p.xlsx','Sheet',7,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump50_p.xlsx','Sheet',7,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump50_p.xlsx','Sheet',7,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump50_p.xlsx','Sheet',7,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump50_p.xlsx','Sheet',7,'Range',SimData10);
            case 8 % 1323 K
                writematrix(MatrixSummary_p1,'DataDump50_p.xlsx','Sheet',8,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump50_p.xlsx','Sheet',8,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump50_p.xlsx','Sheet',8,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump50_p.xlsx','Sheet',8,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump50_p.xlsx','Sheet',8,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump50_p.xlsx','Sheet',8,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump50_p.xlsx','Sheet',8,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump50_p.xlsx','Sheet',8,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump50_p.xlsx','Sheet',8,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump50_p.xlsx','Sheet',8,'Range',SimData10);
            case 9 % 1373 K
                writematrix(MatrixSummary_p1,'DataDump50_p.xlsx','Sheet',9,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump50_p.xlsx','Sheet',9,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump50_p.xlsx','Sheet',9,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump50_p.xlsx','Sheet',9,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump50_p.xlsx','Sheet',9,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump50_p.xlsx','Sheet',9,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump50_p.xlsx','Sheet',9,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump50_p.xlsx','Sheet',9,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump50_p.xlsx','Sheet',9,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump50_p.xlsx','Sheet',9,'Range',SimData10);
        end
    case 4
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary_p1,'DataDump100_p.xlsx','Sheet',1,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump100_p.xlsx','Sheet',1,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump100_p.xlsx','Sheet',1,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump100_p.xlsx','Sheet',1,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump100_p.xlsx','Sheet',1,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump100_p.xlsx','Sheet',1,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump100_p.xlsx','Sheet',1,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump100_p.xlsx','Sheet',1,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump100_p.xlsx','Sheet',1,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump100_p.xlsx','Sheet',1,'Range',SimData10);
            case 2 % 1023 K
                writematrix(MatrixSummary_p1,'DataDump100_p.xlsx','Sheet',2,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump100_p.xlsx','Sheet',2,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump100_p.xlsx','Sheet',2,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump100_p.xlsx','Sheet',2,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump100_p.xlsx','Sheet',2,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump100_p.xlsx','Sheet',2,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump100_p.xlsx','Sheet',2,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump100_p.xlsx','Sheet',2,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump100_p.xlsx','Sheet',2,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump100_p.xlsx','Sheet',2,'Range',SimData10);
            case 3 % 1073 K
                writematrix(MatrixSummary_p1,'DataDump100_p.xlsx','Sheet',3,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump100_p.xlsx','Sheet',3,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump100_p.xlsx','Sheet',3,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump100_p.xlsx','Sheet',3,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump100_p.xlsx','Sheet',3,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump100_p.xlsx','Sheet',3,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump100_p.xlsx','Sheet',3,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump100_p.xlsx','Sheet',3,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump100_p.xlsx','Sheet',3,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump100_p.xlsx','Sheet',3,'Range',SimData10);
            case 4 % 1123 K
                writematrix(MatrixSummary_p1,'DataDump100_p.xlsx','Sheet',4,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump100_p.xlsx','Sheet',4,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump100_p.xlsx','Sheet',4,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump100_p.xlsx','Sheet',4,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump100_p.xlsx','Sheet',4,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump100_p.xlsx','Sheet',4,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump100_p.xlsx','Sheet',4,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump100_p.xlsx','Sheet',4,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump100_p.xlsx','Sheet',4,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump100_p.xlsx','Sheet',4,'Range',SimData10);
            case 5 % 1173 K
                writematrix(MatrixSummary_p1,'DataDump100_p.xlsx','Sheet',5,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump100_p.xlsx','Sheet',5,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump100_p.xlsx','Sheet',5,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump100_p.xlsx','Sheet',5,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump100_p.xlsx','Sheet',5,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump100_p.xlsx','Sheet',5,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump100_p.xlsx','Sheet',5,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump100_p.xlsx','Sheet',5,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump100_p.xlsx','Sheet',5,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump100_p.xlsx','Sheet',5,'Range',SimData10);
            case 6 % 1223 K
                writematrix(MatrixSummary_p1,'DataDump100_p.xlsx','Sheet',6,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump100_p.xlsx','Sheet',6,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump100_p.xlsx','Sheet',6,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump100_p.xlsx','Sheet',6,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump100_p.xlsx','Sheet',6,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump100_p.xlsx','Sheet',6,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump100_p.xlsx','Sheet',6,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump100_p.xlsx','Sheet',6,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump100_p.xlsx','Sheet',6,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump100_p.xlsx','Sheet',6,'Range',SimData10);
            case 7 % 1273 K
                writematrix(MatrixSummary_p1,'DataDump100_p.xlsx','Sheet',7,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump100_p.xlsx','Sheet',7,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump100_p.xlsx','Sheet',7,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump100_p.xlsx','Sheet',7,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump100_p.xlsx','Sheet',7,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump100_p.xlsx','Sheet',7,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump100_p.xlsx','Sheet',7,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump100_p.xlsx','Sheet',7,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump100_p.xlsx','Sheet',7,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump100_p.xlsx','Sheet',7,'Range',SimData10);
            case 8 % 1323 K
                writematrix(MatrixSummary_p1,'DataDump100_p.xlsx','Sheet',8,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump100_p.xlsx','Sheet',8,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump100_p.xlsx','Sheet',8,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump100_p.xlsx','Sheet',8,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump100_p.xlsx','Sheet',8,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump100_p.xlsx','Sheet',8,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump100_p.xlsx','Sheet',8,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump100_p.xlsx','Sheet',8,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump100_p.xlsx','Sheet',8,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump100_p.xlsx','Sheet',8,'Range',SimData10);
            case 9 % 1373 K
                writematrix(MatrixSummary_p1,'DataDump100_p.xlsx','Sheet',9,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump100_p.xlsx','Sheet',9,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump100_p.xlsx','Sheet',9,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump100_p.xlsx','Sheet',9,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump100_p.xlsx','Sheet',9,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump100_p.xlsx','Sheet',9,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump100_p.xlsx','Sheet',9,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump100_p.xlsx','Sheet',9,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump100_p.xlsx','Sheet',9,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump100_p.xlsx','Sheet',9,'Range',SimData10);
        end
    case 5
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary_p1,'DataDump200_p.xlsx','Sheet',1,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump200_p.xlsx','Sheet',1,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump200_p.xlsx','Sheet',1,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump200_p.xlsx','Sheet',1,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump200_p.xlsx','Sheet',1,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump200_p.xlsx','Sheet',1,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump200_p.xlsx','Sheet',1,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump200_p.xlsx','Sheet',1,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump200_p.xlsx','Sheet',1,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump200_p.xlsx','Sheet',1,'Range',SimData10);
            case 2 % 1023 K
                writematrix(MatrixSummary_p1,'DataDump200_p.xlsx','Sheet',2,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump200_p.xlsx','Sheet',2,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump200_p.xlsx','Sheet',2,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump200_p.xlsx','Sheet',2,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump200_p.xlsx','Sheet',2,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump200_p.xlsx','Sheet',2,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump200_p.xlsx','Sheet',2,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump200_p.xlsx','Sheet',2,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump200_p.xlsx','Sheet',2,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump200_p.xlsx','Sheet',2,'Range',SimData10);
            case 3 % 1073 K
                writematrix(MatrixSummary_p1,'DataDump200_p.xlsx','Sheet',3,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump200_p.xlsx','Sheet',3,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump200_p.xlsx','Sheet',3,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump200_p.xlsx','Sheet',3,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump200_p.xlsx','Sheet',3,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump200_p.xlsx','Sheet',3,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump200_p.xlsx','Sheet',3,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump200_p.xlsx','Sheet',3,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump200_p.xlsx','Sheet',3,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump200_p.xlsx','Sheet',3,'Range',SimData10);
            case 4 % 1123 K
                writematrix(MatrixSummary_p1,'DataDump200_p.xlsx','Sheet',4,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump200_p.xlsx','Sheet',4,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump200_p.xlsx','Sheet',4,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump200_p.xlsx','Sheet',4,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump200_p.xlsx','Sheet',4,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump200_p.xlsx','Sheet',4,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump200_p.xlsx','Sheet',4,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump200_p.xlsx','Sheet',4,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump200_p.xlsx','Sheet',4,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump200_p.xlsx','Sheet',4,'Range',SimData10);
            case 5 % 1173 K
                writematrix(MatrixSummary_p1,'DataDump200_p.xlsx','Sheet',5,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump200_p.xlsx','Sheet',5,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump200_p.xlsx','Sheet',5,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump200_p.xlsx','Sheet',5,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump200_p.xlsx','Sheet',5,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump200_p.xlsx','Sheet',5,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump200_p.xlsx','Sheet',5,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump200_p.xlsx','Sheet',5,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump200_p.xlsx','Sheet',5,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump200_p.xlsx','Sheet',5,'Range',SimData10);
            case 6 % 1223 K
                writematrix(MatrixSummary_p1,'DataDump200_p.xlsx','Sheet',6,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump200_p.xlsx','Sheet',6,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump200_p.xlsx','Sheet',6,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump200_p.xlsx','Sheet',6,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump200_p.xlsx','Sheet',6,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump200_p.xlsx','Sheet',6,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump200_p.xlsx','Sheet',6,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump200_p.xlsx','Sheet',6,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump200_p.xlsx','Sheet',6,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump200_p.xlsx','Sheet',6,'Range',SimData10);
            case 7 % 1273 K
                writematrix(MatrixSummary_p1,'DataDump200_p.xlsx','Sheet',7,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump200_p.xlsx','Sheet',7,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump200_p.xlsx','Sheet',7,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump200_p.xlsx','Sheet',7,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump200_p.xlsx','Sheet',7,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump200_p.xlsx','Sheet',7,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump200_p.xlsx','Sheet',7,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump200_p.xlsx','Sheet',7,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump200_p.xlsx','Sheet',7,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump200_p.xlsx','Sheet',7,'Range',SimData10);
            case 8 % 1323 K
                writematrix(MatrixSummary_p1,'DataDump200_p.xlsx','Sheet',8,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump200_p.xlsx','Sheet',8,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump200_p.xlsx','Sheet',8,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump200_p.xlsx','Sheet',8,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump200_p.xlsx','Sheet',8,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump200_p.xlsx','Sheet',8,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump200_p.xlsx','Sheet',8,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump200_p.xlsx','Sheet',8,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump200_p.xlsx','Sheet',8,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump200_p.xlsx','Sheet',8,'Range',SimData10);
            case 9 % 1373 K
                writematrix(MatrixSummary_p1,'DataDump200_p.xlsx','Sheet',9,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump200_p.xlsx','Sheet',9,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump200_p.xlsx','Sheet',9,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump200_p.xlsx','Sheet',9,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump200_p.xlsx','Sheet',9,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump200_p.xlsx','Sheet',9,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump200_p.xlsx','Sheet',9,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump200_p.xlsx','Sheet',9,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump200_p.xlsx','Sheet',9,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump200_p.xlsx','Sheet',9,'Range',SimData10);
        end
    case 6
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary_p1,'DataDump300_p.xlsx','Sheet',1,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump300_p.xlsx','Sheet',1,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump300_p.xlsx','Sheet',1,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump300_p.xlsx','Sheet',1,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump300_p.xlsx','Sheet',1,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump300_p.xlsx','Sheet',1,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump300_p.xlsx','Sheet',1,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump300_p.xlsx','Sheet',1,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump300_p.xlsx','Sheet',1,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump300_p.xlsx','Sheet',1,'Range',SimData10);
            case 2 % 1023 K
                writematrix(MatrixSummary_p1,'DataDump300_p.xlsx','Sheet',2,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump300_p.xlsx','Sheet',2,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump300_p.xlsx','Sheet',2,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump300_p.xlsx','Sheet',2,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump300_p.xlsx','Sheet',2,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump300_p.xlsx','Sheet',2,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump300_p.xlsx','Sheet',2,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump300_p.xlsx','Sheet',2,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump300_p.xlsx','Sheet',2,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump300_p.xlsx','Sheet',2,'Range',SimData10);
            case 3 % 1073 K
                writematrix(MatrixSummary_p1,'DataDump300_p.xlsx','Sheet',3,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump300_p.xlsx','Sheet',3,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump300_p.xlsx','Sheet',3,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump300_p.xlsx','Sheet',3,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump300_p.xlsx','Sheet',3,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump300_p.xlsx','Sheet',3,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump300_p.xlsx','Sheet',3,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump300_p.xlsx','Sheet',3,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump300_p.xlsx','Sheet',3,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump300_p.xlsx','Sheet',3,'Range',SimData10);
            case 4 % 1123 K
                writematrix(MatrixSummary_p1,'DataDump300_p.xlsx','Sheet',4,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump300_p.xlsx','Sheet',4,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump300_p.xlsx','Sheet',4,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump300_p.xlsx','Sheet',4,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump300_p.xlsx','Sheet',4,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump300_p.xlsx','Sheet',4,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump300_p.xlsx','Sheet',4,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump300_p.xlsx','Sheet',4,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump300_p.xlsx','Sheet',4,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump300_p.xlsx','Sheet',4,'Range',SimData10);
            case 5 % 1173 K
                writematrix(MatrixSummary_p1,'DataDump300_p.xlsx','Sheet',5,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump300_p.xlsx','Sheet',5,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump300_p.xlsx','Sheet',5,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump300_p.xlsx','Sheet',5,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump300_p.xlsx','Sheet',5,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump300_p.xlsx','Sheet',5,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump300_p.xlsx','Sheet',5,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump300_p.xlsx','Sheet',5,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump300_p.xlsx','Sheet',5,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump300_p.xlsx','Sheet',5,'Range',SimData10);
            case 6 % 1223 K
                writematrix(MatrixSummary_p1,'DataDump300_p.xlsx','Sheet',6,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump300_p.xlsx','Sheet',6,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump300_p.xlsx','Sheet',6,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump300_p.xlsx','Sheet',6,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump300_p.xlsx','Sheet',6,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump300_p.xlsx','Sheet',6,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump300_p.xlsx','Sheet',6,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump300_p.xlsx','Sheet',6,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump300_p.xlsx','Sheet',6,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump300_p.xlsx','Sheet',6,'Range',SimData10);
            case 7 % 1273 K
                writematrix(MatrixSummary_p1,'DataDump300_p.xlsx','Sheet',7,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump300_p.xlsx','Sheet',7,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump300_p.xlsx','Sheet',7,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump300_p.xlsx','Sheet',7,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump300_p.xlsx','Sheet',7,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump300_p.xlsx','Sheet',7,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump300_p.xlsx','Sheet',7,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump300_p.xlsx','Sheet',7,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump300_p.xlsx','Sheet',7,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump300_p.xlsx','Sheet',7,'Range',SimData10);
            case 8 % 1323 K
                writematrix(MatrixSummary_p1,'DataDump300_p.xlsx','Sheet',8,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump300_p.xlsx','Sheet',8,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump300_p.xlsx','Sheet',8,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump300_p.xlsx','Sheet',8,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump300_p.xlsx','Sheet',8,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump300_p.xlsx','Sheet',8,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump300_p.xlsx','Sheet',8,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump300_p.xlsx','Sheet',8,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump300_p.xlsx','Sheet',8,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump300_p.xlsx','Sheet',8,'Range',SimData10);
            case 9 % 1373 K
                writematrix(MatrixSummary_p1,'DataDump300_p.xlsx','Sheet',9,'Range',SimData1);
                writematrix(MatrixSummary_p2,'DataDump300_p.xlsx','Sheet',9,'Range',SimData2);
                writematrix(MatrixSummary_p3,'DataDump300_p.xlsx','Sheet',9,'Range',SimData3);
                writematrix(MatrixSummary_p4,'DataDump300_p.xlsx','Sheet',9,'Range',SimData4);
                writematrix(MatrixSummary_p5,'DataDump300_p.xlsx','Sheet',9,'Range',SimData5);
                writematrix(MatrixSummary_p6,'DataDump300_p.xlsx','Sheet',9,'Range',SimData6);
                writematrix(MatrixSummary_p7,'DataDump300_p.xlsx','Sheet',9,'Range',SimData7);
                writematrix(MatrixSummary_p8,'DataDump300_p.xlsx','Sheet',9,'Range',SimData8);
                writematrix(MatrixSummary_p9,'DataDump300_p.xlsx','Sheet',9,'Range',SimData9);
                writematrix(MatrixSummary_p10,'DataDump300_p.xlsx','Sheet',9,'Range',SimData10);
        end
end

