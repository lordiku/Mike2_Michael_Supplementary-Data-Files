function TotalDens = Mix_Dens(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, xMH2S, i)

    % Calculates multicomponent gas-phase density, based on Peng-Robinson
    % (1976) and pseudo-critical gas mixture properties. 

    % Initializing matrix structure. Saving gas species compositions. 
    PureDens = zeros(i,8);
    PureDens = [xMCH4 xMCO2 xMCO xMH2O xMH2 xMN2 xMO2 xMH2S];
    
    % Data taken from: 
    % Elliott, J., Lira, C. (2012). Introductory Chemical Engineering
    % Thermodynamics (2nd Ed.). Upper Saddle River, NJ: Pearson Education Inc.

    R = ones(i,1)*8.3144598; % m^3*Pa/K/mol, universal gas constant
    rhoSTP = 44.59; % mol/m^3, for water vapour - initial guess.
    rho = rhoSTP .* ((P./101315).*(273.15./T)); % Guess using IGL
    % Critical temperatures, pressures, and acentric factors for species.
    % deg-K, MPa, [no dim.]

    PRSpec = [ 190.6  4.604  0.011       %CH4
               304.2  7.382  0.228       %CO2
               647.3  22.12  0.344       %H2O
               132.9  3.499  0.066       %CO
               33.3   1.297  -0.215      %H2
               126.1  3.394  0.040       %N2
               154.6  5.043  0.022       %O2
               373.4  8.963  0.081       %H2S
               ];

    % Computes pseudo-critical temperature, pressure, and acentric factor
    % (as per Smith et al., 2018)
    T_crit = PureDens*PRSpec(:,1); % deg-K
    P_crit = PureDens*PRSpec(:,2); % MPa
    acentric = PureDens*PRSpec(:,3); % no dim.

    % Calculation of coefficients for PR-EOS calculation. 
    kappa = (0.37464 + 1.54226 .* acentric - 0.26992 .* acentric .^ 2);

    alpha = (1 + kappa .* (1 - sqrt(T .* (1 ./ T_crit)))).^2;
    a_c = (0.45723553 .* (R .^ 2)) .* ((T_crit .^ 2) ./ (P_crit .* 10^6)); 
    a = a_c .* alpha; 
    b = (0.07779607 .* R) .* (T_crit ./ (P_crit .* 10^6));

    rhoCheck = rho;
    
    % Calculation of compressibility factor for desired species. 
    Z_mix = 1./(1 - b .* (rho)) - (a ./ (b .* R .* T)) .* (b .* rho ./ (1 + ...
        2 .* b .* rho - b.^2 .* rho .^2));
    
    % Ideal gas law, n/V = rho = R/ZRT.
    rho = P ./ (Z_mix .*R .* T); %mol/m^3
    
    % Calculation iterates until the error threshold is satisfied. 
    while sum(abs(1-rho./rhoCheck)) > 10E-3
    
    % Calculation of compressibility factor for desired species. 
    Z_mix = 1./(1 - b .* (rho)) - (a ./ (b .* R .* T)) .* (b .* rho ./ (1 + ...
        2 .* b .* rho - b.^2 .* rho .^2));
    
    % Ideal gas law, n/V = rho = R/ZRT.
    rho = P ./ (Z_mix .*R .* T); %mol/m^3
    
    rhoCheck = rho;
    
    end
    
    % Getting mean mass density (g/mol) for gas mixture. 
    mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
    mN2 = 28.02; mO2 = 32.00; mH2S = 34.03;
    MoltoMass = mCH4*xMCH4 + mCO*xMCO + mCO2*xMCO2 + mH2*xMH2 + mH2O*xMH2O + ...
        mN2*xMN2 + mO2*xMO2 + mH2S*xMH2S;
    
    % mol/m^3 * kg/kmol * (kmol/1000mol) = kg/m^3
    TotalDens = rho .* (MoltoMass/1000); 

end