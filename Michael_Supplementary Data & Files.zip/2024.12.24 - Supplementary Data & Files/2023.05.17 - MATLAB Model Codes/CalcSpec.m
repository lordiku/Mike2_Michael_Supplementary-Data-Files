
% Species mass fractions are solved within the reactor domain, such that
% the catalyst pellet surface concentrations are consistent between the
% reactor-scale and pellet-scale domains. 

% Values are retrieved for every cell center in the domain. 
i = cellnum;
P = rMatrixPress(:,k-1); T = rMatrixTemp(:,k-1); xCH4 = rMatrixFrac_CH4(:,k-1);
xCO2 = rMatrixFrac_CO2(:,k-1); xH2O = rMatrixFrac_H2O(:,k-1);
xCO = rMatrixFrac_CO(:,k-1); xH2 = rMatrixFrac_H2(:,k-1); 
xN2 = rMatrixFrac_N2(:,k-1); xO2 = rMatrixFrac_O2(:,k-1); xH2S = rMatrixFrac_H2S(:,k-1); 

% Retrieving catalyst surface field property vectors.  
Ts = sMatrixTemp(:,k-1); xsCH4 = sMatrixFrac_CH4(:,k-1);
xsCO2 = sMatrixFrac_CO2(:,k-1); xsH2O = sMatrixFrac_H2O(:,k-1);
xsCO = sMatrixFrac_CO(:,k-1); xsH2 = sMatrixFrac_H2(:,k-1); 
xsN2 = sMatrixFrac_N2(:,k-1); xsO2 = sMatrixFrac_O2(:,k-1); xsH2S = sMatrixFrac_H2S(:,k-1); 

% Thermodynamic and transport values are retrieved for every cell center 
% and face in the domain. 
uz1 = rMeshVel(1:i,k-1); uz2 = rMeshVel(2:i+1,k-1); uz = rMatrixVel(:,k-1);
rho1 = rMeshDens(1:i,k-1); rho2 = rMeshDens(2:i+1,k-1); rho = rMatrixDens(:,k-1);
mu1 = rMesh_mu(1:i,k-1); mu2 = rMesh_mu(2:i+1,k-1); mu = rMatrix_Mu(:,k-1);
Cp1 = rMeshCp(1:i,k-1); Cp2 = rMeshCp(2:i+1,k-1); Cp = rMatrixCp(:,k-1);
cond1 = rMesh_cond(1:i,k-1); cond2 = rMesh_cond(2:i+1,k-1); cond = rMatrix_cond(:,k-1);

% Reaction rates are retrieved. Note that these are still in mol/kgcat.s
% Effectiveness factors are applied to the reactions themselves here. 
MatrixSMR1 = sMatrixRXN(:,k-1,1); rxn1 = MatrixSMR1.*eff1;   % CH4 + H2O -> CO + 3H2
MatrixSMR2 = sMatrixRXN(:,k-1,2); rxn2 = MatrixSMR2.*eff2;   % CO + H2O -> CO2 + H2
MatrixSMR3 = sMatrixRXN(:,k-1,3); rxn3 = MatrixSMR3.*eff3;  % CH4 + 2H2O -> CO2 + 4H2

% Finding species reaction rates, based on stoichiometric equations.
% Note: molar weights are adjusted to show Kg/mol from g/mol.
% Here, reaction rates are converted to kg/s, following SI unit convention.
% (kgcat/m^3)*(mol/kgcat.s)*(g/mol)*(kg/1000g) = kg/m^3.s
coeff1 = (1-eps).*rho_s.*dz./1000;
rxnCH4 = coeff1.*mCH4.*  (-rxn1-rxn3); 
rxnCO2 = coeff1.*mCO2.*  (rxn2+rxn3); 
rxnH2O = coeff1.*mH2O.*  (-rxn1-rxn2-rxn3-rxn3);
rxnCO = coeff1.*mCO.*    (rxn1-rxn2);
rxnH2 = coeff1.*mH2.*    (rxn1+rxn1+rxn1+rxn2+rxn3+rxn3+rxn3+rxn3);

% Effective diffusivities are calculated based on the molecular
% diffusivities for each species, as well as the velocity of gas flow
% through the porous media. 

% Diffusivities are retrieved, and effective diffusivities are defined. 
D1 = rdiff(1:i,:); 
D2 = rdiff(2:i+1,:);
D_ea1 = zeros(i,8); D_ea2 = zeros(i,8);

% Effective diffusivities are calculated for each species. Note that the
% diffusivity matrices are defined to hold the molecular diffusivity of all
% species together at every face within the domain. For consistency, the
% effective diffusivity follows the same form. 

% NOTE: Based on axial dispersion correlation from Edwards & Richardson (1968)

for j = 1:8
D_ea1(:,j) = 0.73.*D1(:,j) + (0.5.*uz1(:,1).*d_p)./(1 + 9.7.*D1(:,j)./((uz1(:,1).*d_p))); 
D_ea2(:,j) = 0.73.*D2(:,j) + (0.5.*uz2(:,1).*d_p)./(1 + 9.7.*D2(:,j)./((uz2(:,1).*d_p)));
end

% Effective diffusivities for each species at every face are then set in
% order to incorporate them into the species continuity equations. 

DCH4_1 = D_ea1(:,1); DCH4_2 = D_ea2(:,1); 
DCO2_1 = D_ea1(:,2); DCO2_2 = D_ea2(:,2); 
DH2O_1 = D_ea1(:,3); DH2O_2 = D_ea2(:,3); 
DCO_1 = D_ea1(:,4); DCO_2 = D_ea2(:,4); 
DH2_1 = D_ea1(:,5); DH2_2 = D_ea2(:,5); 
DN2_1 = D_ea1(:,6); DN2_2 = D_ea2(:,6); 
DO2_1 = D_ea1(:,7); DO2_2 = D_ea2(:,7); 
DH2S_1 = D_ea1(:,8); DH2S_2 = D_ea2(:,8); 

% Calculation of Peclet numbers and "correction" coefficients. See thesis,
% Tutorial C, for details. Briefly, calculation is improved by inserting a
% "correction" coefficient adjusting mathematical diffusion based on the
% relationship between convective and diffusive terms. This coefficient is
% derived from a "sort-of" weak form solution to a steady-state
% convection-diffusion problem, which helps improve numerical accuracy as
% the simulation proceeds. This technique follows from Patankar (1980). 

PecCH4_1 = (rho1 .* uz1)./(DCH4_1./dz); PecCH4_2 = (rho2 .* uz2)./(DCH4_2./dz);
PecCO2_1 = (rho1 .* uz1)./(DCO2_1./dz); PecCO2_2 = (rho2 .* uz2)./(DCO2_2./dz);
PecH2O_1 = (rho1 .* uz1)./(DH2O_1./dz); PecH2O_2 = (rho2 .* uz2)./(DH2O_2./dz);
PecCO_1 = (rho1 .* uz1)./(DCO_1./dz); PecCO_2 = (rho2 .* uz2)./(DCO_2./dz);
PecH2_1 = (rho1 .* uz1)./(DH2_1./dz); PecH2_2 = (rho2 .* uz2)./(DH2_2./dz);
PecN2_1 = (rho1 .* uz1)./(DN2_1./dz); PecN2_2 = (rho2 .* uz2)./(DN2_2./dz);
PecO2_1 = (rho1 .* uz1)./(DO2_1./dz); PecO2_2 = (rho2 .* uz2)./(DO2_2./dz);
PecH2S_1 = (rho1 .* uz1)./(DH2S_1./dz); PecH2S_2 = (rho2 .* uz2)./(DH2S_2./dz);

CorrCH4_1 = PecCH4_1 ./ (exp(PecCH4_1)-1); CorrCH4_2 = PecCH4_2 ./ (exp(PecCH4_2)-1);
CorrCO2_1 = PecCO2_1 ./ (exp(PecCO2_1)-1); CorrCO2_2 = PecCO2_2 ./ (exp(PecCO2_2)-1);
CorrH2O_1 = PecH2O_1 ./ (exp(PecH2O_1)-1); CorrH2O_2 = PecH2O_2 ./ (exp(PecH2O_2)-1);
CorrCO_1 = PecCO_1 ./ (exp(PecCO_1)-1); CorrCO_2 = PecCO_2 ./ (exp(PecCO_2)-1);
CorrH2_1 = PecH2_1 ./ (exp(PecH2_1)-1); CorrH2_2 = PecH2_2 ./ (exp(PecH2_2)-1);
CorrN2_1 = PecN2_1 ./ (exp(PecN2_1)-1); CorrN2_2 = PecN2_2 ./ (exp(PecN2_2)-1);
CorrO2_1 = PecO2_1 ./ (exp(PecO2_1)-1); CorrO2_2 = PecO2_2 ./ (exp(PecO2_2)-1);
CorrH2S_1 = PecH2S_1 ./ (exp(PecH2S_1)-1); CorrH2S_2 = PecH2S_2 ./ (exp(PecH2S_2)-1);

% Here, we again consider a generalized form of the derived and discretized
% continuity equation. Coefficient values are calculated in vectorized
% form, and positioned in diagonal matrices (accounting for the inlet and
% outlet faces). 

err = 1; % reset the error counter. 

% To maintain consistency between modeling scales, the reactor-scale
% concentration and pellet scale concentrations must all align such that
% the catalyst surface concentration calculated within the reactor-scale
% domain is nearly equal to that of the catalyst surface concentration
% calculated within the pellet-scale domain. The "calculated"
% concentrations, identified by the moniker suffix "_c", are initialized. 
xsCH4_c = xsCH4; xsCO2_c = xsCO2; xsH2O_c = xsH2O; 
xsCO_c = xsCO; xsH2_c = xsH2; xsN2_c = xsN2; xsO2_c = xsO2; xsH2S_c = xsH2S;
xCH4_c = xCH4; xCO2_c = xCO2; xH2O_c = xH2O; 
xCO_c = xCO; xH2_c = xH2; xN2_c = xN2; xO2_c = xO2; xH2S_c = xH2S;

% Coefficient values are used to reduce the number of operations being
% calculated by MATLAB. "a_ps1" and "a_ps2" values do not change. 
a_ps1 = (eps.*rho).*(dz./dt); a_ps2 = av.*rho.*dz;

% Calculation of species proceeds until the error threshold is achieved. 
while err > 10^-3

% Coefficient matrices for each species are assembled per the
% discretization presented in Tutorial D of the thesis. 

% For illustration, CH4 is described here. 
% Left (west) coefficient values are calculated and oriented. 
Frac_CH4LHS_LFace = -rho1.*uz1-DCH4_1.*eps.*rho1./dz.*CorrCH4_1;
Frac_CH4LHS_LFace2 = cat(1,zeros(1,i),cat(2,diag(Frac_CH4LHS_LFace(2:i)),zeros(i-1,1)));

% Cell center coefficient values are calculated and oriented. 
Frac_CH4LHS_Cell = diag((a_ps1+km_CH4.*av.*rho.*dz+rho2.*uz2+DCH4_2.*eps.*rho2./dz.*CorrCH4_2+DCH4_1.*eps.*rho1./dz.*CorrCH4_1));

% Right (east) coefficient values are calculated and oriented. 
Frac_CH4LHS_RFace = -DCH4_2.*eps.*rho2./dz.*CorrCH4_2;
Frac_CH4LHS_RFace2 = cat(2,zeros(i,1),cat(1,diag(Frac_CH4LHS_RFace(1:i-1)),zeros(1,i-1)));

% The overall coefficient matrix for CH4 is assembled. 
Frac_CH4LHS = Frac_CH4LHS_LFace2 + Frac_CH4LHS_Cell + Frac_CH4LHS_RFace2;

% The solution matrix for CH4 is calculated. 
Frac_CH4RHS = eps.*rho.*xCH4.*(dz/dt)+km_CH4.*av.*rho.*dz.*xsCH4_c;

% The coefficient and solution matrices for CO2 are assembled. 
Frac_CO2LHS_LFace = -rho1.*uz1-DCO2_1.*eps.*rho1./dz.*CorrCO2_1;
Frac_CO2LHS_LFace2 = cat(1,zeros(1,i),cat(2,diag(Frac_CO2LHS_LFace(2:i)),zeros(i-1,1)));
Frac_CO2LHS_Cell = diag((a_ps1+km_CO2.*av.*rho.*dz+rho2.*uz2+DCO2_2.*eps.*rho2./dz.*CorrCO2_2+DCO2_1.*eps.*rho1./dz.*CorrCO2_1));
Frac_CO2LHS_RFace = -DCO2_2.*eps.*rho2./dz.*CorrCO2_2;
Frac_CO2LHS_RFace2 = cat(2,zeros(i,1),cat(1,diag(Frac_CO2LHS_RFace(1:i-1)),zeros(1,i-1)));
Frac_CO2LHS = Frac_CO2LHS_LFace2 + Frac_CO2LHS_Cell + Frac_CO2LHS_RFace2;
Frac_CO2RHS = eps.*rho.*xCO2.*(dz/dt)+km_CO2.*av.*rho.*dz.*xsCO2_c;

% The coefficient and solution matrices for H2O are assembled. 
Frac_H2OLHS_LFace = -rho1.*uz1-DH2O_1.*eps.*rho1./dz.*CorrH2O_1;
Frac_H2OLHS_LFace2 = cat(1,zeros(1,i),cat(2,diag(Frac_H2OLHS_LFace(2:i)),zeros(i-1,1)));
Frac_H2OLHS_Cell = diag((a_ps1+km_H2O.*av.*rho.*dz+rho2.*uz2+DH2O_2.*eps.*rho2./dz.*CorrH2O_2+DH2O_1.*eps.*rho1./dz.*CorrH2O_1));
Frac_H2OLHS_RFace = -DH2O_2.*eps.*rho2./dz.*CorrH2O_2;
Frac_H2OLHS_RFace2 = cat(2,zeros(i,1),cat(1,diag(Frac_H2OLHS_RFace(1:i-1)),zeros(1,i-1)));
Frac_H2OLHS = Frac_H2OLHS_LFace2 + Frac_H2OLHS_Cell + Frac_H2OLHS_RFace2;
Frac_H2ORHS = eps.*rho.*xH2O.*(dz/dt)+km_H2O.*av.*rho.*dz.*xsH2O_c;

% The coefficient and solution matrices for CO are assembled. 
Frac_COLHS_LFace = -rho1.*uz1-DCO_1.*eps.*rho1./dz.*CorrCO_1;
Frac_COLHS_LFace2 = cat(1,zeros(1,i),cat(2,diag(Frac_COLHS_LFace(2:i)),zeros(i-1,1)));
Frac_COLHS_Cell = diag((a_ps1+km_CO.*av.*rho.*dz+rho2.*uz2+DCO_2.*eps.*rho2./dz.*CorrCO_2+DCO_1.*eps.*rho1./dz.*CorrCO_1));
Frac_COLHS_RFace = -DCO_2.*eps.*rho2./dz.*CorrCO_2;
Frac_COLHS_RFace2 = cat(2,zeros(i,1),cat(1,diag(Frac_COLHS_RFace(1:i-1)),zeros(1,i-1)));
Frac_COLHS = Frac_COLHS_LFace2 + Frac_COLHS_Cell + Frac_COLHS_RFace2;
Frac_CORHS = eps.*rho.*xCO.*(dz/dt)+km_CO.*av.*rho.*dz.*xsCO_c;

% The coefficient and solution matrices for H2 are assembled. 
Frac_H2LHS_LFace = -rho1.*uz1-DH2_1.*eps.*rho1./dz.*CorrH2_1;
Frac_H2LHS_LFace2 = cat(1,zeros(1,i),cat(2,diag(Frac_H2LHS_LFace(2:i)),zeros(i-1,1)));
Frac_H2LHS_Cell = diag((a_ps1+km_H2.*av.*rho.*dz+rho2.*uz2+DH2_2.*eps.*rho2./dz.*CorrH2_2+DH2_1.*eps.*rho1./dz.*CorrH2_1));
Frac_H2LHS_RFace = -DH2_2.*eps.*rho2./dz.*CorrH2_2;
Frac_H2LHS_RFace2 = cat(2,zeros(i,1),cat(1,diag(Frac_H2LHS_RFace(1:i-1)),zeros(1,i-1)));
Frac_H2LHS = Frac_H2LHS_LFace2 + Frac_H2LHS_Cell + Frac_H2LHS_RFace2;
Frac_H2RHS = eps.*rho.*xH2.*(dz/dt)+km_H2.*av.*rho.*dz.*xsH2_c;

% The coefficient and solution matrices for N2 are assembled. 
Frac_N2LHS_LFace = -rho1.*uz1-DN2_1.*eps.*rho1./dz.*CorrN2_1;
Frac_N2LHS_LFace2 = cat(1,zeros(1,i),cat(2,diag(Frac_N2LHS_LFace(2:i)),zeros(i-1,1)));
Frac_N2LHS_Cell = diag((a_ps1+km_N2.*av.*rho.*dz+rho2.*uz2+DN2_2.*eps.*rho2./dz.*CorrN2_2+DN2_1.*eps.*rho1./dz.*CorrN2_1));
Frac_N2LHS_RFace = -DN2_2.*eps.*rho2./dz.*CorrN2_2;
Frac_N2LHS_RFace2 = cat(2,zeros(i,1),cat(1,diag(Frac_N2LHS_RFace(1:i-1)),zeros(1,i-1)));
Frac_N2LHS = Frac_N2LHS_LFace2 + Frac_N2LHS_Cell + Frac_N2LHS_RFace2;
Frac_N2RHS = eps.*rho.*xN2.*(dz/dt)+km_N2.*av.*rho.*dz.*xsN2_c;

% The coefficient and solution matrices for O2 are assembled. 
Frac_O2LHS_LFace = -rho1.*uz1-DO2_1.*eps.*rho1./dz.*CorrO2_1;
Frac_O2LHS_LFace2 = cat(1,zeros(1,i),cat(2,diag(Frac_O2LHS_LFace(2:i)),zeros(i-1,1)));
Frac_O2LHS_Cell = diag((a_ps1+km_O2.*av.*rho.*dz+rho2.*uz2+DO2_2.*eps.*rho2./dz.*CorrO2_2+DO2_1.*eps.*rho1./dz.*CorrO2_1));
Frac_O2LHS_RFace = -DO2_2.*eps.*rho2./dz.*CorrO2_2;
Frac_O2LHS_RFace2 = cat(2,zeros(i,1),cat(1,diag(Frac_O2LHS_RFace(1:i-1)),zeros(1,i-1)));
Frac_O2LHS = Frac_O2LHS_LFace2 + Frac_O2LHS_Cell + Frac_O2LHS_RFace2;
Frac_O2RHS = eps.*rho.*xO2.*(dz/dt)+km_O2.*av.*rho.*dz.*xsO2_c;

% The coefficient and solution matrices for H2S are assembled. 
Frac_H2SLHS_LFace = -rho1.*uz1-DH2S_1.*eps.*rho1./dz.*CorrH2S_1;
Frac_H2SLHS_LFace2 = cat(1,zeros(1,i),cat(2,diag(Frac_H2SLHS_LFace(2:i)),zeros(i-1,1)));
Frac_H2SLHS_Cell = diag((a_ps1+km_H2S.*av.*rho.*dz+rho2.*uz2+DH2S_2.*eps.*rho2./dz.*CorrH2S_2+DH2S_1.*eps.*rho1./dz.*CorrH2S_1));
Frac_H2SLHS_RFace = -DH2S_2.*eps.*rho2./dz.*CorrH2S_2;
Frac_H2SLHS_RFace2 = cat(2,zeros(i,1),cat(1,diag(Frac_H2SLHS_RFace(1:i-1)),zeros(1,i-1)));
Frac_H2SLHS = Frac_H2SLHS_LFace2 + Frac_H2SLHS_Cell + Frac_H2SLHS_RFace2;
Frac_H2SRHS = eps.*rho.*xH2S.*(dz/dt)+km_H2S.*av.*rho.*dz.*xsH2S_c;

% Boundary conditions for the species continuity equations follow the same
% lines as that of the energy continuity equation - the inlet is defined by
% a Dirichlet boundary condition (i.e. it is fixed at the composition of
% the feed gas to the reactor), and the outlet is defined by a Neumann
% boundary condition (i.e. effective diffusivity ceases once the gas exits
% the reactor). 

% Inlet boundaries are defined. 

Frac_CH4LHS(1,1) = eps*rho(1,1)*(dz/dt)+km_CH4(1,1).*av.*rho(1,1).*dz+rho2(1,1)*uz2(1,1)+DCH4_2(1,1)*eps*rho2(1,1)/dz*CorrCH4_2(1,1)+DCH4_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrCH4_1(1,1);
Frac_CH4LHS(1,2) = -DCH4_2(1,1)*eps*rho2(1,1)/dz*CorrCH4_2(1,1);
Frac_CH4RHS(1,1) = eps*rho(1,1)*xCH4(1,1)*(dz/dt)+km_CH4(1,1).*av.*rho(1,1).*dz.*xsCH4_c(1,1)+(rho1(1,1)*uz1(1,1)+DCH4_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrCH4_1(1,1))*xCH4_in;

Frac_CO2LHS(1,1) = eps*rho(1,1)*(dz/dt)+km_CO2(1,1).*av.*rho(1,1).*dz+rho2(1,1)*uz2(1,1)+DCO2_2(1,1)*eps*rho2(1,1)/dz*CorrCO2_2(1,1)+DCO2_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrCO2_1(1,1);
Frac_CO2LHS(1,2) = -DCO2_2(1,1)*eps*rho2(1,1)/dz*CorrCO2_2(1,1);
Frac_CO2RHS(1,1) = eps*rho(1,1)*xCO2(1,1)*(dz/dt)+km_CO2(1,1).*av.*rho(1,1).*dz.*xsCO2_c(1,1)+(rho1(1,1)*uz1(1,1)+DCO2_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrCO2_1(1,1))*xCO2_in;

Frac_H2OLHS(1,1) = eps*rho(1,1)*(dz/dt)+km_H2O(1,1).*av.*rho(1,1).*dz+rho2(1,1)*uz2(1,1)+DH2O_2(1,1)*eps*rho2(1,1)/dz*CorrH2O_2(1,1)+DH2O_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrH2O_1(1,1);
Frac_H2OLHS(1,2) = -DH2O_2(1,1)*eps*rho2(1,1)/dz*CorrH2O_2(1,1);
Frac_H2ORHS(1,1) = eps*rho(1,1)*xH2O(1,1)*(dz/dt)+km_H2O(1,1).*av.*rho(1,1).*dz.*xsH2O_c(1,1)+(rho1(1,1)*uz1(1,1)+DH2O_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrH2O_1(1,1))*xH2O_in;

Frac_COLHS(1,1) = eps*rho(1,1)*(dz/dt)+km_CO(1,1).*av.*rho(1,1).*dz+rho2(1,1)*uz2(1,1)+DCO_2(1,1)*eps*rho2(1,1)/dz*CorrCO_2(1,1)+DCO_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrCO_1(1,1);
Frac_COLHS(1,2) = -DCO_2(1,1)*eps*rho2(1,1)/dz*CorrCO_2(1,1);
Frac_CORHS(1,1) = eps*rho(1,1)*xCO(1,1)*(dz/dt)+km_CO(1,1).*av.*rho(1,1).*dz.*xsCO_c(1,1)+(rho1(1,1)*uz1(1,1)+DCO_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrCO_1(1,1))*xCO_in;

Frac_H2LHS(1,1) = eps*rho(1,1)*(dz/dt)+km_H2(1,1).*av.*rho(1,1).*dz+rho2(1,1)*uz2(1,1)+DH2_2(1,1)*eps*rho2(1,1)/dz*CorrH2_2(1,1)+DH2_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrH2_1(1,1);
Frac_H2LHS(1,2) = -DH2_2(1,1)*eps*rho2(1,1)/dz*CorrH2_2(1,1);
Frac_H2RHS(1,1) = eps*rho(1,1)*xH2(1,1)*(dz/dt)+km_H2(1,1).*av.*rho(1,1).*dz.*xsH2_c(1,1)+(rho1(1,1)*uz1(1,1)+DH2_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrH2_1(1,1))*xH2_in;

Frac_N2LHS(1,1) = eps*rho(1,1)*(dz/dt)+km_N2(1,1).*av.*rho(1,1).*dz+rho2(1,1)*uz2(1,1)+DN2_2(1,1)*eps*rho2(1,1)/dz*CorrN2_2(1,1)+DN2_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrN2_1(1,1);
Frac_N2LHS(1,2) = -DN2_2(1,1)*eps*rho2(1,1)/dz*CorrN2_2(1,1);
Frac_N2RHS(1,1) = eps*rho(1,1)*xN2(1,1)*(dz/dt)+km_N2(1,1).*av.*rho(1,1).*dz.*xsN2_c(1,1)+(rho1(1,1)*uz1(1,1)+DN2_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrN2_1(1,1))*xN2_in;

Frac_O2LHS(1,1) = eps*rho(1,1)*(dz/dt)+km_O2(1,1).*av.*rho(1,1).*dz+rho2(1,1)*uz2(1,1)+DO2_2(1,1)*eps*rho2(1,1)/dz*CorrO2_2(1,1)+DO2_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrO2_1(1,1);
Frac_O2LHS(1,2) = -DO2_2(1,1)*eps*rho2(1,1)/dz*CorrO2_2(1,1);
Frac_O2RHS(1,1) = eps*rho(1,1)*xO2(1,1)*(dz/dt)+km_O2(1,1).*av.*rho(1,1).*dz.*xsO2_c(1,1)+(rho1(1,1)*uz1(1,1)+DO2_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrO2_1(1,1))*xO2_in;

Frac_H2SLHS(1,1) = eps*rho(1,1)*(dz/dt)+km_H2S(1,1).*av.*rho(1,1).*dz+rho2(1,1)*uz2(1,1)+DH2S_2(1,1)*eps*rho2(1,1)/dz*CorrH2S_2(1,1)+DH2S_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrH2S_1(1,1);
Frac_H2SLHS(1,2) = -DH2S_2(1,1)*eps*rho2(1,1)/dz*CorrH2S_2(1,1);
Frac_H2SRHS(1,1) = eps*rho(1,1)*xH2S(1,1)*(dz/dt)+km_H2S(1,1).*av.*rho(1,1).*dz.*xsH2S_c(1,1)+(rho1(1,1)*uz1(1,1)+DH2S_1(1,1)*eps*rho1(1,1)/(dz/2)*CorrH2S_1(1,1))*xH2S_in;

% Outlet boundaries are defined. 

Frac_CH4LHS(i,i-1) = -rho1(i,1)*uz1(i,1)-DCH4_1(i,1)*eps*rho1(i,1)/dz*CorrCH4_1(i,1);
Frac_CH4LHS(i,i) = eps*rho(i,1)*(dz/dt)+km_CH4(i,1).*av.*rho(i,1).*dz+rho2(i,1)*uz2(i,1)+DCH4_1(i,1)*eps*rho1(i,1)/dz*CorrCH4_1(i,1);
Frac_CH4RHS(i,1) = eps*rho(i,1)*xCH4(i,1)*(dz/dt)+km_CH4(i,1).*av.*rho(i,1).*dz.*xsCH4_c(i,1);

Frac_CO2LHS(i,i-1) = -rho1(i,1)*uz1(i,1)-DCO2_1(i,1)*eps*rho1(i,1)/dz*CorrCO2_1(i,1);
Frac_CO2LHS(i,i) = eps*rho(i,1)*(dz/dt)+km_CO2(i,1).*av.*rho(i,1).*dz+rho2(i,1)*uz2(i,1)+DCO2_1(i,1)*eps*rho1(i,1)/dz*CorrCO2_1(i,1);
Frac_CO2RHS(i,1) = eps*rho(i,1)*xCO2(i,1)*(dz/dt)+km_CO2(i,1).*av.*rho(i,1).*dz.*xsCO2_c(i,1);

Frac_H2OLHS(i,i-1) = -rho1(i,1)*uz1(i,1)-DH2O_1(i,1)*eps*rho1(i,1)/dz*CorrH2O_1(i,1);
Frac_H2OLHS(i,i) = eps*rho(i,1)*(dz/dt)+km_H2O(i,1).*av.*rho(i,1).*dz+rho2(i,1)*uz2(i,1)+DH2O_1(i,1)*eps*rho1(i,1)/dz*CorrH2O_1(i,1);
Frac_H2ORHS(i,1) = eps*rho(i,1)*xH2O(i,1)*(dz/dt)+km_H2O(i,1).*av.*rho(i,1).*dz.*xsH2O_c(i,1);

Frac_COLHS(i,i-1) = -rho1(i,1)*uz1(i,1)-DCO_1(i,1)*eps*rho1(i,1)/dz*CorrCO_1(i,1);
Frac_COLHS(i,i) = eps*rho(i,1)*(dz/dt)+km_CO(i,1).*av.*rho(i,1).*dz+rho2(i,1)*uz2(i,1)+DCO_1(i,1)*eps*rho1(i,1)/dz*CorrCO_1(i,1);
Frac_CORHS(i,1) = eps*rho(i,1)*xCO(i,1)*(dz/dt)+km_CO(i,1).*av.*rho(i,1).*dz.*xsCO_c(i,1);

Frac_H2LHS(i,i-1) = -rho1(i,1)*uz1(i,1)-DH2_1(i,1)*eps*rho1(i,1)/dz*CorrH2_1(i,1);
Frac_H2LHS(i,i) = eps*rho(i,1)*(dz/dt)+km_H2(i,1).*av.*rho(i,1).*dz+rho2(i,1)*uz2(i,1)+DH2_1(i,1)*eps*rho1(i,1)/dz*CorrH2_1(i,1);
Frac_H2RHS(i,1) = eps*rho(i,1)*xH2(i,1)*(dz/dt)+km_H2(i,1).*av.*rho(i,1).*dz.*xsH2_c(i,1);

Frac_N2LHS(i,i-1) = -rho1(i,1)*uz1(i,1)-DN2_1(i,1)*eps*rho1(i,1)/dz*CorrN2_1(i,1);
Frac_N2LHS(i,i) = eps*rho(i,1)*(dz/dt)+km_N2(i,1).*av.*rho(i,1).*dz+rho2(i,1)*uz2(i,1)+DN2_1(i,1)*eps*rho1(i,1)/dz*CorrN2_1(i,1);
Frac_N2RHS(i,1) = eps*rho(i,1)*xN2(i,1)*(dz/dt)+km_N2(i,1).*av.*rho(i,1).*dz.*xsN2_c(i,1);

Frac_O2LHS(i,i-1) = -rho1(i,1)*uz1(i,1)-DO2_1(i,1)*eps*rho1(i,1)/dz*CorrO2_1(i,1);
Frac_O2LHS(i,i) = eps*rho(i,1)*(dz/dt)+km_O2(i,1).*av.*rho(i,1).*dz+rho2(i,1)*uz2(i,1)+DO2_1(i,1)*eps*rho1(i,1)/dz*CorrO2_1(i,1);
Frac_O2RHS(i,1) = eps*rho(i,1)*xO2(i,1)*(dz/dt)+km_O2(i,1).*av.*rho(i,1).*dz.*xsO2_c(i,1);

Frac_H2SLHS(i,i-1) = -rho1(i,1)*uz1(i,1)-DH2S_1(i,1)*eps*rho1(i,1)/dz*CorrH2S_1(i,1);
Frac_H2SLHS(i,i) = eps*rho(i,1)*(dz/dt)+km_H2S(i,1).*av.*rho(i,1).*dz+rho2(i,1)*uz2(i,1)+DH2S_1(i,1)*eps*rho1(i,1)/dz*CorrH2S_1(i,1);
Frac_H2SRHS(i,1) = eps*rho(i,1)*xH2S(i,1)*(dz/dt)+km_H2S(i,1).*av.*rho(i,1).*dz.*xsH2S_c(i,1);

% With the completed coefficient and solution matrices, the mass fraction
% profiles of each species can now be solved for the whole domain. Each of
% these are solved individually. 

rMatrixSoln_CH4 = sparse(Frac_CH4LHS\Frac_CH4RHS); CH4Neg = find(rMatrixSoln_CH4<0);
rMatrixSoln_CO2 = sparse(Frac_CO2LHS\Frac_CO2RHS); CO2Neg = find(rMatrixSoln_CO2<0);
rMatrixSoln_H2O = sparse(Frac_H2OLHS\Frac_H2ORHS); H2ONeg = find(rMatrixSoln_H2O<0);
rMatrixSoln_CO = sparse(Frac_COLHS\Frac_CORHS); CONeg = find(rMatrixSoln_CO<0);
rMatrixSoln_H2 = sparse(Frac_H2LHS\Frac_H2RHS); H2Neg = find(rMatrixSoln_H2<0);
rMatrixSoln_N2 = sparse(Frac_N2LHS\Frac_N2RHS); N2Neg = find(rMatrixSoln_N2<0);
rMatrixSoln_O2 = sparse(Frac_O2LHS\Frac_O2RHS); O2Neg = find(rMatrixSoln_O2<0);
rMatrixSoln_H2S = sparse(Frac_H2SLHS\Frac_H2SRHS); H2SNeg = find(rMatrixSoln_H2S<0);

% ERROR TRAPPING - Goal here is to identify whether 'over-reaction' has
% occurred given the time step and reaction rate. In this case, the
% simulation may need to be relaxed in order to come to an acceptable
% solution. 

if sum(abs(CH4Neg))>0
    disp('Negative CH4 Detected - quitting program'); ForceReturn = 1; return
elseif sum(abs(CO2Neg))>0
    disp('Negative CO2  Detected - quitting program'); ForceReturn = 1; return  
elseif sum(abs(H2ONeg))>0
    disp('Negative H2O  Detected - quitting program'); ForceReturn = 1; return
elseif sum(abs(CONeg))>0
    disp('Negative CO  Detected - quitting program'); ForceReturn = 1; return
elseif sum(abs(H2Neg))>0
    disp('Negative H2  Detected - quitting program'); ForceReturn = 1; return
end

% The calculated species concentrations are updated for use in determining
% the catalyst surface species concentrations. 
xCH4_c = rMatrixSoln_CH4(1:cellnum,1);
xCO2_c = rMatrixSoln_CO2(1:cellnum,1);
xH2O_c = rMatrixSoln_H2O(1:cellnum,1);
xCO_c = rMatrixSoln_CO(1:cellnum,1);
xH2_c = rMatrixSoln_H2(1:cellnum,1);
xN2_c = rMatrixSoln_N2(1:cellnum,1);
xO2_c = rMatrixSoln_O2(1:cellnum,1);
xH2S_c = rMatrixSoln_H2S(1:cellnum,1);

% Species balance at the catalyst surface is computed. 
if convmod == 1
    CalcPellet  % trigger calculation of pellet internal comp profiles. 
else
    CalcSurf    % trigger calculation of surface comp only. 
end

% Error between the "new" and "old" catalyst surface species concentrations
% is calculated. 
err = sum(abs(1-xsCH4_n./xsCH4_o));

end

% Calculated catalyst surface species concentrations are saved into memory.
sMatrixFrac_CH4(:,k) = xsCH4_c;
sMatrixFrac_CO2(:,k) = xsCO2_c;
sMatrixFrac_H2O(:,k) = xsH2O_c;
sMatrixFrac_CO(:,k) = xsCO_c;
sMatrixFrac_H2(:,k) = xsH2_c;
sMatrixFrac_N2(:,k) = xsN2_c;
sMatrixFrac_O2(:,k) = xsO2_c;
sMatrixFrac_H2S(:,k) = xsH2S_c;

% The mass fractions are retrieved into the appropriate matrix for the
% given time step. 
rMatrixFrac_CH4(:,k) = rMatrixSoln_CH4(1:cellnum,1);
rMatrixFrac_CO2(:,k) = rMatrixSoln_CO2(1:cellnum,1); 
rMatrixFrac_H2O(:,k) = rMatrixSoln_H2O(1:cellnum,1); 
rMatrixFrac_CO(:,k) = rMatrixSoln_CO(1:cellnum,1); 
rMatrixFrac_H2(:,k) = rMatrixSoln_H2(1:cellnum,1); 
rMatrixFrac_N2(:,k) = rMatrixSoln_N2(1:cellnum,1); 
rMatrixFrac_O2(:,k) = rMatrixSoln_O2(1:cellnum,1); 
rMatrixFrac_H2S(:,k) = rMatrixSoln_H2S(1:cellnum,1); 

rMatrixFrac_ALL(:,k) = rMatrixFrac_CH4(:,k) + rMatrixFrac_CO2(:,k) + ...
    rMatrixFrac_H2O(:,k) + rMatrixFrac_CO(:,k) + rMatrixFrac_H2(:,k) + ...
    rMatrixFrac_N2(:,k) + rMatrixFrac_O2(:,k) + rMatrixFrac_H2S(:,k);

% The mean molecular weight wihtin the reactor domain is calculated. 
rMasstoMol = rMatrixFrac_CH4(:,k)./mCH4 + rMatrixFrac_CO2(:,k)./mCO2 + ...
    rMatrixFrac_H2O(:,k)./mH2O + rMatrixFrac_CO(:,k)./mCO + ...
    rMatrixFrac_H2(:,k)./mH2 + rMatrixFrac_N2(:,k)./mN2 + ...
    rMatrixFrac_O2(:,k)./mO2 + rMatrixFrac_H2S(:,k)./mH2S; rMoltoMass = 1./rMasstoMol;

% Mole fractions for each species within the reactor domain are then calculated. 
rMatrixFracM_CH4(:,k) = rMatrixFrac_CH4(:,k)./(mCH4./rMoltoMass);
rMatrixFracM_CO2(:,k) = rMatrixFrac_CO2(:,k)./(mCO2./rMoltoMass); 
rMatrixFracM_H2O(:,k) = rMatrixFrac_H2O(:,k)./(mH2O./rMoltoMass); 
rMatrixFracM_CO(:,k) = rMatrixFrac_CO(:,k)./(mCO./rMoltoMass); 
rMatrixFracM_H2(:,k) = rMatrixFrac_H2(:,k)./(mH2./rMoltoMass); 
rMatrixFracM_N2(:,k) = rMatrixFrac_N2(:,k)./(mN2./rMoltoMass); 
rMatrixFracM_O2(:,k) = rMatrixFrac_O2(:,k)./(mO2./rMoltoMass); 
rMatrixFracM_H2S(:,k) = rMatrixFrac_H2S(:,k)./(mH2S./rMoltoMass); 
rMatrixFracM_ALL(:,k) = rMatrixFracM_CH4(:,k) + rMatrixFracM_CO2(:,k) + ...
    rMatrixFracM_H2O(:,k) + rMatrixFracM_CO(:,k) + rMatrixFracM_H2(:,k) + ...
    rMatrixFracM_N2(:,k) + rMatrixFracM_O2(:,k) + rMatrixFracM_H2S(:,k);

% The mean molecular weight at the catalyst surface is calculated. 
sMasstoMol = sMatrixFrac_CH4(:,k)./mCH4 + sMatrixFrac_CO2(:,k)./mCO2 + ...
    sMatrixFrac_H2O(:,k)./mH2O + sMatrixFrac_CO(:,k)./mCO + ...
    sMatrixFrac_H2(:,k)./mH2 + sMatrixFrac_N2(:,k)./mN2 + ...
    sMatrixFrac_O2(:,k)./mO2 + sMatrixFrac_H2S(:,k)./mH2S; 
    sMoltoMass = 1./sMasstoMol;

% Mole fractions for each species at the catalyst surface are then calculated. 
sMatrixFracM_CH4(:,k) = sMatrixFrac_CH4(:,k)./(mCH4./sMoltoMass);
sMatrixFracM_CO2(:,k) = sMatrixFrac_CO2(:,k)./(mCO2./sMoltoMass); 
sMatrixFracM_H2O(:,k) = sMatrixFrac_H2O(:,k)./(mH2O./sMoltoMass); 
sMatrixFracM_CO(:,k) = sMatrixFrac_CO(:,k)./(mCO./sMoltoMass); 
sMatrixFracM_H2(:,k) = sMatrixFrac_H2(:,k)./(mH2./sMoltoMass); 
sMatrixFracM_N2(:,k) = sMatrixFrac_N2(:,k)./(mN2./sMoltoMass); 
sMatrixFracM_O2(:,k) = sMatrixFrac_O2(:,k)./(mO2./sMoltoMass); 
sMatrixFracM_H2S(:,k) = sMatrixFrac_H2S(:,k)./(mH2S./sMoltoMass); 
sMatrixFracM_ALL(:,k) = sMatrixFracM_CH4(:,k) + sMatrixFracM_CO2(:,k) + ...
    sMatrixFracM_H2O(:,k) + sMatrixFracM_CO(:,k) + sMatrixFracM_H2(:,k) + ...
    sMatrixFracM_N2(:,k) + sMatrixFracM_O2(:,k) + sMatrixFracM_H2S(:,k);

% This section calculates the equilibrium coverage of H2S on the catalyst,
% and then tries to estimate the degree of adsorption and desorption
% exhibited by the catalyst. Note that, given the strength of sulfur
% chemisorption, adsorption / desorption is assumed to be instantaneous. 

if convmod == 1

    % Mass and mole fractions of hydrogen sulfide are retrieved from
    % memory. 
    YpH2S = pMatrixFracM_H2S(:,:,k); YpH2 = pMatrixFracM_H2(:,:,k); R = ones(i,1) .* 8.3144598;
    XpH2S = pMatrixFrac_H2S(:,:,k); XpH2 = pMatrixFrac_H2(:,:,k); prho = pMatrixDens(:,:,k-1);

    % Equilibrium sulfur coverage is calculated within each pellet. 
    peqCoverage = 1 - 0.293 .* exp(-35800./R./Tp).*(YpH2S./YpH2).^-0.3;

    % Weight of sulfur when catalyst solid is saturated; for slab geometry 
    % this becomes pellet surface area times thickness.
    pwsat_H2S(:,:,k) = peqCoverage .* AdCap_H2S .* rho_s .* (4 .* pi .* (d_p/2)^2) .* drp .* eps_p;
    wg_H2S = XpH2S .* prho .* (4 .* pi .* (d_p ./ 2) .^ 2) .* drp .* eps_p;

    for i = 1:cellnum
        for c = 1:partnum

            % Every segment of every pellet is checked to see whether the
            % gas-phase concentration represents an H2S saturated
            % atmosphere. 

            % First, an error trap is used to determine whether the sulfur
            % correlation has computed a value beyond the bounds of
            % acceptable saturated sulfur mass absorption. 
            if or(pwsat_H2S(i,c,k) > 1, pwsat_H2S(i,c,k) < 0)
                pwsat_H2S(i,c,k) = 0;
            end
            
            % If the weight of sulfur adsorbed to the catalyst surface is
            % less than what would be there under saturated conditions,
            % then the gas-phase H2S moves to the catalyst surface and
            % adsorbs. 
            if wp_H2S(i,c,k-1) < pwsat_H2S(i,c,k)
                H2SAds = wg_H2S(i,c,1) * (1-wp_H2S(i,c,k-1)./pwsat_H2S(i,c,k));
                Turtle = wp_H2S(i,c,k-1) + H2SAds;
                wp_H2S(i,c,k) = Turtle;
                pMatrixFrac_H2S(i,c,k) = ((pMatrixFrac_H2S(i,c,k) .* prho(i,c,1) .* (4 .* pi .* (d_p/2)^2) .* drp .* eps_p) - H2SAds)./...
                (prho(i,c,1) .* (4 .* pi .* (d_p/2)^2) .* drp .* eps_p);
            
            % If the weight of sulfur adsorbed to the catalyst surface is
            % greater than what would be there under saturated conditions,
            % then surface-adsorbed H2S desorbs from the surface of the
            % catalyst into the gas phase. 
            elseif pCoverage(i,c,k-1) > 0.80
                H2SAds = wg_H2S(i,c,1) * (1-wp_H2S(i,c,k-1)./pwsat_H2S(i,c,k));
                Turtle = wp_H2S(i,c,k-1) + H2SAds;
                wp_H2S(i,c,k) = Turtle;
                pMatrixFrac_H2S(i,c,k) = ((pMatrixFrac_H2S(i,c,k) .* prho(i,c,1) .* (4 .* pi .* (d_p/2)^2) .* drp .* eps_p) - H2SAds)./...
                (prho(i,c,1) .* (4 .* pi .* (d_p/2)^2) .* drp .* eps_p);

            % If neither is true, then the solid and gas phase H2S are in
            % equilibrium with one another. No change occurs. 
            else
                wp_H2S(i,c,k) = wp_H2S(i,c,k-1);
            end

            % Where the saturated adsorbed quantity of sulfur is non-zero,
            % pellet sulfur coverage is calculated (vs. staying zero). 
            if sum(pwsat_H2S(i,c,k)) > 0
                pCoverage(i,c,k) = wp_H2S(i,c,k)./(AdCap_H2S .* rho_s .* (4 .* pi .* (d_p/2)^2) .* drp .* eps_p);
            end
        end
    end
    
% A similar calculation follows for the catalyst surface as well; the code
% below executes during simplified heterogeneous modeling. 

else 
    YsH2S = sMatrixFracM_H2S(:,k); YsH2 = sMatrixFracM_H2(:,k); R = ones(i,1)*8.3144598;
    XsH2S = sMatrixFrac_H2S(:,k); XsH2 = sMatrixFrac_H2(:,k); srho = sMatrixDens(:,k-1);
    
    % Follows from Koningen & Sjostrom, 1998. Arrhenius-type correlation. 
    seqCoverage = 1 - 0.293 .* exp(-35800./R./Ts).*(YsH2S./YsH2).^-0.3;
    
    wsat_H2S(:,k) = seqCoverage .* AdCap_H2S .* rho_s .* (pi .* (d_p/2)^2) .* dz .* eps_p;
    wg_H2S = XsH2S .* srho .* (pi .* (d_p/2)^2) .* dz .* eps_p;
    
    for i = 1:cellnum
        
        if or(wsat_H2S(i,k) > 1, wsat_H2S(i,k) < 0)
            wsat_H2S(i,k) = 0;
        end
        
        if ws_H2S(i,k-1) < wsat_H2S(i,k-1)
            H2SAds = wg_H2S(i,1) * (1-ws_H2S(i,k-1)/wsat_H2S(i,k-1));
            Turtle = ws_H2S(i,k-1) + H2SAds;
            ws_H2S(i,k) = Turtle;
            sMatrixFrac_H2S(i,k) = ((sMatrixFrac_H2S(i,k) .* srho(i,1) .* (pi .* (d_p/2)^2) .* dz .* eps_p) - H2SAds)./...
            (srho(i,1) .* (pi .* (d_p/2)^2) .* dz .* eps_p);
        
        elseif sCoverage(i,k-1) > 0.80
            H2SAds = wg_H2S(i,1) * (1-ws_H2S(i,k-1)/wsat_H2S(i,k-1));
            Turtle = ws_H2S(i,k-1) + H2SAds;
            ws_H2S(i,k) = Turtle;
            sMatrixFrac_H2S(i,k) = ((sMatrixFrac_H2S(i,k) .* srho(i,1) .* (pi .* (d_p/2)^2) .* dz .* eps_p) - H2SAds)./...
            (srho(i,1) .* (pi .* (d_p/2)^2) .* dz .* eps_p);
        
        else
            ws_H2S(i,k) = ws_H2S(i,k-1);
        end
    end
    
    if sum(wsat_H2S(:,k)) > 0
        sCoverage(:,k) = ws_H2S(:,k)./(AdCap_H2S .* rho_s .* (pi .* (d_p/2)^2) .* dz .* eps_p);
    end
end

