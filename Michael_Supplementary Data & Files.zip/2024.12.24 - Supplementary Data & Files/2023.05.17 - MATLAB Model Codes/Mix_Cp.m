function TotalCp = Mix_Cp(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2, xH2S, i)
    
    % Data taken from: 
    % Elliott, J., Lira, C. (2012). Introductory Chemical Engineering
    % Thermodynamics (2nd Ed.). Upper Saddle River, NJ: Pearson Education Inc.

    % CH4, CO2, H2O, CO, H2, N2, O2, H2S
    Coeff = [   1   19.25   5.21E-02    1.20E-05   -1.13E-08
                2   19.80   7.34E-02   -5.60E-05    1.72E-08
                3   32.24   1.92E-03    1.06E-05   -3.60E-09
                4   30.87  -1.29E-02    2.79E-05   -1.27E-08
                5   27.14   9.27E-03   -1.38E-05    7.65E-09
                6   31.15  -0.01357     2.68E-05   -1.17E-08
                7   28.11  -3.70E-06    1.75E-05   -1.07E-08
                8   31.90   2.34E-03    2.18E-05   -1.02E-08];

    % Calculations are based on an empirical relationship:
    % C1 + C2 * T + C3 * T^2 + C4 * T^3

    % Returns as J/mol.K
    PureCp(:,1) = (Coeff(:,2) + Coeff(:,3).*T + Coeff(:,4).*T.^2 + Coeff(:,5).*T.^3);  
    PureCp(:,2) = [xCH4 xCO2 xH2O xCO xH2 xN2 xO2 xH2S];
    
    % Heat capacity is taken as the sum of products of individual species
    % heat capacities and their molar fractions. 
    CalcCp = PureCp(:,1)'*PureCp(:,2);
    
    % Getting mean mass density (g/mol) for gas mixture. 
    mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
    mN2 = 28.02; mO2 = 32.00; mH2S = 34.03;
    MoltoMass = mCH4*xCH4 + mCO*xCO + mCO2*xCO2 + mH2*xH2 + mH2O*xH2O + ...
        mN2*xN2 + mO2*xO2 + mH2S*xH2S;
    
    % Convert J/mol.K * (1 kJ/1000 J) * (mol/g) * (1000g/kg) = kJ/kg.K
    TotalCp = CalcCp .*(1/1000).*(1./MoltoMass).*1000;

end