
%% Gibbs Free Energy "Wrapper"
% M. Fabrik, 2023
%
% This code is mean to iterate through the Gibbs Energy solver, and provide
% a total set of values at a given temperature and pressure for various
% equilibrium compositions. 

%% CODE BEGINS

Pmin = 100000; Pmax = 200000; Pstep = 50000; Pnum = (Pmax-Pmin)/Pstep;
Tmin = 873; Tmax = 1273; Tstep = 50; Tnum = (Tmax-Tmin)/Tstep; 
% SCmin = 0.05; SCmax = 1.0; SCstep = 0.05; SCnum = (SCmax-SCmin)/SCstep;
% 
% xMCO2 = 0.45; 
% xMCO = 0.0001; 
% xMH2 = 0.0001; 
% 
% xMN2 = 0.04; 
% xMO2 = 0.000001;

xMCH4 = 0.05; xMCO2 = 0.15; xMH2O = 0.25; 
xMCO = 0.15; xMH2 = 0.15; xMH2S = 0;
xMO2 = 0.000001; xMN2 = 0.25-xMO2; 

%TotalIts = Pnum * Tnum * xMCH4num; GibbsData = zeros(TotalIts, 8); 
ItNum = 0;
% 
% for SC_i = SCmin:SCstep:SCmax
%     xMCH4 = (1-xMCO2-xMCO-xMH2-xMN2-xMO2)/(1+SC_i);
%     xMH2O = (1-xMCO2-xMCO-xMH2-xMN2-xMO2-xMCH4);
for P_i = Pmin:Pstep:Pmax
for T_i = Tmin:Tstep:Tmax

CCRatio = xMCO2 / xMCH4;
ItNum = ItNum + 1; GibbsData(ItNum,1) = P_i; GibbsData(ItNum,2) = T_i; GibbsData(ItNum,3) = CCRatio;
CompVect = GibbsEq(P_i,T_i,xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2).';
GibbsData(ItNum,4:10) = CompVect;

Prompt = ['Iteration: ',num2str(ItNum)]; disp(Prompt);

% end
end
end
% end

writematrix(GibbsData,'EquibData.xlsx','Sheet',1,'Range','B5');

