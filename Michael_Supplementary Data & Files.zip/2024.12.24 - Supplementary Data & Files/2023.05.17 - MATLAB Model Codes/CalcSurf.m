
% In simplified heterogeneous modeling, the catalyst pellet surface
% temperature and species concentrations are solved with [CalcSurf]. The
% pellet itself is considered homogeneous, and all interactions through the
% film are assumed to be interactions on the pellet as a whole. 

% Reaction rates are retrieved. Note that these are still in mol/kgcat.s
% Heats of reaction determined for pellet based on temp. 
MatrixSMR1 = sMatrixRXN(:,k-1,1); rxn1 = MatrixSMR1.*eff1; Hrxn1 = H_Calc(Ts,1);
MatrixSMR2 = sMatrixRXN(:,k-1,2); rxn2 = MatrixSMR2.*eff2; Hrxn2 = H_Calc(Ts,2);
MatrixSMR3 = sMatrixRXN(:,k-1,3); rxn3 = MatrixSMR3.*eff3; Hrxn3 = H_Calc(Ts,3);
Qrxn = -(rxn1.*Hrxn1+rxn2.*Hrxn2+rxn3.*Hrxn3) .* rho_s .* (1-eps);

% Construction of the catalyst pellet conservation of energy matrix. The
% matrix is then solved and stored in memory. 
sHeatLHS_Temp = diag((rhoCp_p).*(dz./dt));
sHeatRHS = (rhoCp_p).*(dz./dt).*Ts - Qfilm.*dz + Qrxn.*dz;
sMatrixSoln = sparse(sHeatLHS_Temp\sHeatRHS);
SurfTemp = sMatrixSoln(1:cellnum,1); sMatrixTemp(:,k) = SurfTemp;

% Pellet surface pressure is assumed to be constant and equal to the
% corresponding pressure in the reactor. 
SurfPress = P; sMatrixPress(:,k) = SurfPress; 

% Construction of the catalyst pellet species mass conservation matrix. The
% matrices is then solved and stored in memory. 
Frac_CH4LHS_Surf = diag(a_ps1+km_CH4.*a_ps2);
Frac_CH4RHS_Surf = a_ps1.*xsCH4 + km_CH4.*a_ps2.*xCH4_c + rxnCH4;
Frac_CO2LHS_Surf = diag(a_ps1+km_CO2.*a_ps2);
Frac_CO2RHS_Surf = a_ps1.*xsCO2 + km_CO2.*a_ps2.*xCO2_c + rxnCO2;
Frac_H2OLHS_Surf = diag(a_ps1+km_H2O.*a_ps2);
Frac_H2ORHS_Surf = a_ps1.*xsH2O + km_H2O.*a_ps2.*xH2O_c + rxnH2O;
Frac_COLHS_Surf = diag(a_ps1+km_CO.*a_ps2);
Frac_CORHS_Surf = a_ps1.*xsCO + km_CO.*a_ps2.*xCO_c + rxnCO;
Frac_H2LHS_Surf = diag(a_ps1+km_H2.*a_ps2);
Frac_H2RHS_Surf = a_ps1.*xsH2 + km_H2.*a_ps2.*xH2_c + rxnH2;
Frac_N2LHS_Surf = diag(a_ps1+km_N2.*a_ps2);
Frac_N2RHS_Surf = a_ps1.*xsN2 + km_N2.*a_ps2.*xN2_c; % Rate term excluded.
Frac_O2LHS_Surf = diag(a_ps1+km_O2.*a_ps2);
Frac_O2RHS_Surf = a_ps1.*xsO2 + km_O2.*a_ps2.*xO2_c; % Rate term excluded.
Frac_H2SLHS_Surf = diag(a_ps1+km_H2S.*a_ps2);
Frac_H2SRHS_Surf = a_ps1.*xsH2S + km_H2S.*a_ps2.*xH2S_c; % Rate term excluded.

sMatrixSoln_sCH4 = sparse(Frac_CH4LHS_Surf\Frac_CH4RHS_Surf);
sMatrixSoln_sCO2 = sparse(Frac_CO2LHS_Surf\Frac_CO2RHS_Surf);
sMatrixSoln_sH2O = sparse(Frac_H2OLHS_Surf\Frac_H2ORHS_Surf);
sMatrixSoln_sCO = sparse(Frac_COLHS_Surf\Frac_CORHS_Surf);
sMatrixSoln_sH2 = sparse(Frac_H2LHS_Surf\Frac_H2RHS_Surf);
sMatrixSoln_sN2 = sparse(Frac_N2LHS_Surf\Frac_N2RHS_Surf);
sMatrixSoln_sO2 = sparse(Frac_O2LHS_Surf\Frac_O2RHS_Surf);
sMatrixSoln_sH2S = sparse(Frac_H2SLHS_Surf\Frac_H2SRHS_Surf);

% The last iteration's calculation for catalyst surface species
% concentration is saved, while the current one is calculated. 

rc = 0;     % Relaxation coefficient is defined for converging on the 
            % catalyst surface concentration. 

xsCH4_o = xsCH4_c; xsCH4_n = sMatrixSoln_sCH4(:,1); xsCH4_c = xsCH4_o .* rc + xsCH4_n .* (1-rc); 
xsCO2_o = xsCO2_c; xsCO2_n = sMatrixSoln_sCO2(:,1); xsCO2_c = xsCO2_o .* rc + xsCO2_n .* (1-rc); 
xsH2O_o = xsH2O_c; xsH2O_n = sMatrixSoln_sH2O(:,1); xsH2O_c = xsH2O_o .* rc + xsH2O_n .* (1-rc); 
xsCO_o = xsCO_c; xsCO_n = sMatrixSoln_sCO(:,1); xsCO_c = xsCO_o .* rc + xsCO_n .* (1-rc); 
xsH2_o = xsH2_c; xsH2_n = sMatrixSoln_sH2(:,1); xsH2_c = xsH2_o .* rc + xsH2_n .* (1-rc); 
xsN2_o = xsN2_c; xsN2_n = sMatrixSoln_sN2(:,1); xsN2_c = xsN2_o .* rc + xsN2_n .* (1-rc); 
xsO2_o = xsO2_c; xsO2_n = sMatrixSoln_sO2(:,1); xsO2_c = xsO2_o .* rc + xsO2_n .* (1-rc); 
xsH2S_o = xsH2S_c; xsH2S_n = sMatrixSoln_sH2S(:,1); xsH2S_c = xsH2S_o .* rc + xsH2S_n .* (1-rc); 

% Catalyst surface fraction is saved to memory. 
sMatrixFrac_CH4(:,k) = xsCH4_c;
sMatrixFrac_CO2(:,k) = xsCO2_c;
sMatrixFrac_H2O(:,k) = xsH2O_c;
sMatrixFrac_CO(:,k) = xsCO_c;
sMatrixFrac_H2(:,k) = xsH2_c;
sMatrixFrac_N2(:,k) = xsN2_c;
sMatrixFrac_O2(:,k) = xsO2_c;
sMatrixFrac_H2S(:,k) = xsH2S_c;
