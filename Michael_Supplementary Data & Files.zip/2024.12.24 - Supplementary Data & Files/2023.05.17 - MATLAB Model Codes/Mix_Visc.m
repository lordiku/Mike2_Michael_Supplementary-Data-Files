function TotalVisc = Mix_Visc(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, xMH2S, i)

% Multicomponent gas mixture viscosity is based on the Wilke Equation,
% which can be reviewed in Transport Phenomena, 2nd Ed. (Bird et al., 2002)

    % Setting up a matrix to store pure component properties.
    PureVisc = zeros(i,8,4);
    
    % Setting molar masses of each species. 
    PureVisc(:,:,3) = ones(i,1) * [16.04 44.02 18.03 28.01 2.02 28.02 32.00 34.03];
    
    % Setting mass fractions of the species.
    PureVisc(:,:,4) = [xMCH4 xMCO2 xMH2O xMCO xMH2 xMN2 xMO2 xMH2S];
                    
    %% Viscosities of the gas species (excl. H2O)    
    % Coefficient Ordering: CH4, CO2, CO, H2-1, H2-2, N2, O2-1, O2-2
    % H2O Viscosity covered by IAPWS_Visc.

    % Data taken from: 
    % Rohsenow, W., Hartnett, J., Cho, Y. (1998). Handbook of Heat Transfer
    % (3rd Ed). New York, NY: The McGraw-Hill Companies, Inc. 
    
    % H2S Data derived from Chung et al., 1984, 1988
    % Outlined in: The Properties of Gases and Liquids (Poling, Prausnitz, and
    % O'Connell)

    % Coefficient Ordering: (1) CH4, (2) CO2, (3) CO, (4) H2-1
    %                       (5) H2-2, (6) N2, (7) O2, (8) H2S. 
    % Coeff = [   1  2.96827E-01  3.71120E-02   1.21830E-05  -7.02426E-08   7.54327E-11  -2.72372E-14   0
    %             2 -8.09519E-01  6.03953E-02  -2.82485E-05   9.84378E-09  -1.47315E-12   0             0
    %             3 -5.24575E-01  7.96060E-02  -7.82295E-05   6.28215E-08  -2.83747E-11   5.31783E-15   0
    %             4 -1.35666E-01  6.84116E-02  -3.92875E-04   1.89960E-06  -5.23104E-09   7.44910E-12  -4.25094E-15
    %             5  2.72941E00   2.32244E-02  -7.62879E-06   2.92585E-09  -5.28899E-13   0             0
    %             6  2.54650E-02  7.53370E-02  -6.51566E-05   4.34945E-08  -1.56225E-11   2.24967E-15   0
    %             7 -3.97863E-01  8.76059E-02  -7.06412E-05   4.62870E-08  -1.69044E-11   2.53415E-15   0
    %             8  3.58400E-01  3.34650E-02   4.42050E-05  -1.11210E-07   1.13350E-10  -5.66580E-14  -1.12980E-17];

    Coeff1 = [  1  2.96827E-01  3.71120E-02   1.21830E-05  -7.02426E-08   7.54327E-11  -2.72372E-14   0
                2 -8.09519E-01  6.03953E-02  -2.82485E-05   9.84378E-09  -1.47315E-12   0             0
                0  0            0             0             0             0             0             0  
                3 -5.24575E-01  7.96060E-02  -7.82295E-05   6.28215E-08  -2.83747E-11   5.31783E-15   0
                5  2.72941E00   2.32244E-02  -7.62879E-06   2.92585E-09  -5.28899E-13   0             0
                6  2.54650E-02  7.53370E-02  -6.51566E-05   4.34945E-08  -1.56225E-11   2.24967E-15   0
                7 -3.97863E-01  8.76059E-02  -7.06412E-05   4.62870E-08  -1.69044E-11   2.53415E-15   0
                8  3.58400E-01  3.34650E-02   4.42050E-05  -1.11210E-07   1.13350E-10  -5.66580E-14   1.12980E-17];

    % For efficiency's sake, only the correlations falling within the
    % typical reactor temperature range are taken. 

    PureVisc(:,:,2) = (T./T)*Coeff1(:,2)' + T*Coeff1(:,3)' + (T.^2)*Coeff1(:,4)' + ...
        (T.^3)*Coeff1(:,5)' + (T.^4)*Coeff1(:,6)' + (T.^5)*Coeff1(:,7)' + ...
        (T.^6)*Coeff1(:,8)';
    
    TestVisc = PureVisc(:,:,2);
    
    %% Steam Conductivity

    % This is calculated for water in the vapour phase. 

    % Water density is needed for this calculation, and is here calculated
    % using the Peng Robinson Equation of State. 

    % rhoSTP = 44.59; % mol/m^3
    rho = 44.59 .* ((P./101315).*(273.15./T)); % Guess using IGL

    % Values commented out to speed up computation; pre-calculated and
    % entered in below. 

    % T_crit = 647.3 % deg-K
    % P_crit = 22.12 % MPa
    % acentric = 0.344 % no dim.

    % Calculation of coefficients for PR-EOS calculation. 
    % kappa = (0.37464 + 1.54226 .* 0.344 - 0.26992 .* 0.344 .^ 2);
    % alpha = (1 + kappa .* (1 - sqrt(T .* (1 ./ 647.3)))).^2;
    % a_c = (0.45723553 .* (8.3144598 .^ 2)) .* ((647.3 .^ 2) ./ (22.12 .* 10^6)); 
    % a = a_c .* alpha; 
    
    a = (0.598734298607441) .* (1 + (0.873236186880000) .* (1 - sqrt(T .* (1 ./ 647.3)))).^2;
    b = (0.07779607 .* 8.3144598) .* (647.3 ./ (22.12 .* 10^6));
    R = 8.3144598; % m^3*Pa/K/mol, universal gas constant
    
    rhoCheck = rho;
    
    % Calculation of compressibility factor for desired species. 
    Z_mix = 1./(1 - b .* (rho)) - (a ./ (b .* 8.3144598 .* T)) .* (b .* rho ./ (1 + ...
        2 .* b .* rho - b.^2 .* rho .^2));
    
    % Ideal gas law, n/V = rho = R/ZRT.
    rho = P ./ (Z_mix .*R .* T); %mol/m^3
    
    % Calculation iterates until the error threshold is satisfied. 
    while sum(abs(1-rho./rhoCheck)) > 10E-3
    
    % Calculation of compressibility factor for desired species. 
    Z_mix = 1./(1 - b .* (rho)) - (a ./ (b .* R .* T)) .* (b .* rho ./ (1 + ...
        2 .* b .* rho - b.^2 .* rho .^2));
    
    % Ideal gas law, n/V = rho = R/ZRT.
    rho = P ./ (Z_mix .*R .* T); %mol/m^3
    
    rhoCheck = rho;
    
    end
    
    % The viscosity of water vapour is calculated based on "Release on the
    % IAPWS Formulation 2008 for the Viscosity of Ordinary Water Substances"
    % from the International Association for the Properties of Water and Steam.

    % Data taken from:
    % Wagner, W., Kretzschmar, H-J. (2008). International Steam Tables (2nd
    % Ed.). Berlin, Germany: Springer-Verlag. 

    theta1 = T ./ 647.096; % critical temperature divided by actual temperature
    theta2 = 647.096 ./ T;
    delta2 = (rho .* 18.02 ./ 1000) ./ 322; % actual mass dens. divided by critical density

    % Coefficient values for viscosity in the ideal gas limit. 
%     coeff1 =   [1 0.0167752
%                 2 0.0220462
%                 3 0.006366564
%                 4 -0.00241605];

%     Original Looping Code.
%     term1sum = 0;
%     for i = 1:4
%         term1sum = term1sum + coeff1(i,2) .* theta .^ (i-1);
%     end

    % Calculate sum for viscosity in the ideal gas limit. 
    term1sum = (0.0167752) .* theta1 .^ (1-1)+ (0.0220462) .* theta1 .^ (1-2)+...
        (0.006366564) .* theta1 .^ (1-3)+ (-0.00241605) .* theta1 .^ (1-4);

    % Coefficient values for viscosity, adjusting the ideal gas limit calc. 
%     1 0 0 0.520094    6 1 1 0.999115      11 2 1 -0.906851    16 3 1 0.257399           
%     2 0 1 0.0850895   7 1 2 1.88797       12 2 2 -0.772479    17 4 0 -0.0325372     
%     3 0 2 -1.08374    8 1 3 1.26613       13 2 3 -0.489837    18 4 3 0.0698452    
%     4 0 3 -0.289555   9 1 5 0.120573      14 2 4 -0.257040    19 5 4 0.00872102         
%     5 1 0 0.222531    10 2 0 -0.281378    15 3 0 0.161913     20 6 3 -0.00435673
%                                                               21 6 5 -0.000593264

    term2sum = (0.520094) .* ((delta2 - 1) .^  0) .* ((theta2 .^ -1 - 1) .^ 0) +...
                (0.0850895) .* ((delta2 - 1) .^ 0) .* ((theta2 .^ -1 - 1) .^ 1) +...
                (-1.08374) .* ((delta2 - 1) .^  0) .* ((theta2 .^ -1 - 1) .^ 2) +...
                (-0.289555) .* ((delta2 - 1) .^ 0) .* ((theta2 .^ -1 - 1) .^ 3) +...
                (0.222531) .* ((delta2 - 1) .^  1) .* ((theta2 .^ -1 - 1) .^ 0) +...
                (0.999115) .* ((delta2 - 1) .^  1) .* ((theta2 .^ -1 - 1) .^ 1) +...
                (1.88797) .* ((delta2 - 1) .^   1) .* ((theta2 .^ -1 - 1) .^ 2) +...
                (1.26613) .* ((delta2 - 1) .^   1) .* ((theta2 .^ -1 - 1) .^ 3) +...
                (0.120573) .* ((delta2 - 1) .^  1) .* ((theta2 .^ -1 - 1) .^ 5) +...
                (-0.281378) .* ((delta2 - 1) .^ 2) .* ((theta2 .^ -1 - 1) .^ 0) +...
                (-0.906851) .* ((delta2 - 1) .^ 2) .* ((theta2 .^ -1 - 1) .^ 1) +...
                (-0.772479) .* ((delta2 - 1) .^ 2) .* ((theta2 .^ -1 - 1) .^ 2) +...
                (-0.489837) .* ((delta2 - 1) .^ 2) .* ((theta2 .^ -1 - 1) .^ 3) +...
                (-0.257040) .* ((delta2 - 1) .^ 2) .* ((theta2 .^ -1 - 1) .^ 4) +...
                (0.161913) .* ((delta2 - 1) .^  3) .* ((theta2 .^ -1 - 1) .^ 0) +...
                (0.257399) .* ((delta2 - 1) .^  3) .* ((theta2 .^ -1 - 1) .^ 1) +...
                (-0.0325372) .* ((delta2 - 1).^ 4) .* ((theta2 .^ -1 - 1) .^ 0) +...
                (0.0698452) .* ((delta2 - 1) .^ 4) .* ((theta2 .^ -1 - 1) .^ 3) +...
                (0.00872102) .* ((delta2 - 1).^ 5) .* ((theta2 .^ -1 - 1) .^ 4) +...
                (-0.00435673) .* ((delta2 - 1)  .^ 6) .* ((theta2 .^ -1 - 1) .^ 3) +...
                (-0.000593264) .* ((delta2 - 1) .^ 6) .* ((theta2 .^ -1 - 1) .^ 5);

    % Calculate the viscosity, in units of 1*10^-6 Pa.s
    PureVisc(:,3,2) = ((theta1 .^ 0.5) .* ((term1sum) .^ -1)) .* (exp(delta2.*term2sum)); % 10^-6 Pa.s
    
    % In Wilke's equation, the viscosities of binary mixtures of each gas
    % species are calculated, and are then summed up into the total gas
    % mixture. For example, for a CH4-CO2-H2O feed mixture, the viscosity
    % would be the sum of the binary mixture viscosities for CH4-CO2,
    % CH4-H2O, and CO2-H2O. 
    
    % A number of alternative mixed gas methods can be found in The
    % Properties of Gases and Liquids, commonly derived from either
    % Chapman-Enskog theory or Corresponding States theory. Wilke's
    % equation is taken as a semi-empirical method. 
    
    % Precalculate as much as possible, using the fact that molar weights
    % are constant throughout the reactor.
    M_AB = PureVisc(1,:,3).' * (1./(PureVisc(1,:,3)));
    M_AB1 = (1./sqrt(8)) .* ((1 + M_AB) .^ (-1/2)); M_AB2 = ((1./M_AB).^(1/4));
    
    % Multicomponent viscosities for each species are calculated, one
    % species at a time. 
    SpecVisc = zeros(i,1);
    for j = 1:i
        v_AB = PureVisc(j,:,2).' * (1./(PureVisc(j,:,2)));
        BinVisc = M_AB1 .* (1 + ((v_AB).^(1/2)).*M_AB2).^2;
        SpecVisc(j,1) = sum(PureVisc(j,:,2) .* PureVisc(j,:,4) .* (1./(PureVisc(j,:,4) * BinVisc.'))); 
    end

    % An alternate calculation based on simple ideal gas law mixing is made
    % available as well. 
    IGLVisc = PureVisc(:,1,2) .* PureVisc(:,1,4) + PureVisc(:,2,2) .* PureVisc(:,2,4) + ...
        PureVisc(:,3,2) .* PureVisc(:,3,4) + PureVisc(:,4,2) .* PureVisc(:,4,4) + ...
        PureVisc(:,5,2) .* PureVisc(:,5,4) + PureVisc(:,6,2) .* PureVisc(:,6,4) + ...
        PureVisc(:,7,2) .* PureVisc(:,7,4) + PureVisc(:,8,2) .* PureVisc(:,8,4);
    
    %Viscosity reported as Ns/m^2, or Pa.s
    %TotalVisc = IGLVisc.*10^-6;
    TotalVisc = SpecVisc.*10^-6;
    
end