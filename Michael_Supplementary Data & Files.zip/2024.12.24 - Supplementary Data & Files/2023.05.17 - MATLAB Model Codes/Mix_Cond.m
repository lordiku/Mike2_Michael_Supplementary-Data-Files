function TotalCond = Mix_Cond(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2, xH2S, i)

% Multicomponent gas mixture conductivity is based on the relation of 
% Mason and Saxena, which can be reviewed in Transport Phenomena, 2nd Ed. 
% (Bird et al., 2002)

    % Setting up a matrix to store pure component properties.
    PureCond = zeros(i,8,3);
    
    % Setting molar masses of each species. 
    PureCond(:,:,2) = ones(i,1) * [16.04 44.02 18.03 28.01 2.02 28.02 32.00 34.03];
    
    % Setting mass fractions of the species.
    PureCond(:,:,3) = [xCH4 xCO2 xH2O xCO xH2 xN2 xO2 xH2S];
    
    %% Conductivities of the gas species (excl. H2O)    
        
    % Data taken from: 
    % Rohsenow, W., Hartnett, J., Cho, Y. (1998). Handbook of Heat Transfer
    % (3rd Ed). New York, NY: The McGraw-Hill Companies, Inc. 

    % H2O thermal conductivity covered by IAPWS_Visc.

    % H2S Data derived from Chung et al., 1984, 1988
    % Outlined in: The Properties of Gases and Liquids (Poling, Prausnitz, and
    % O'Connell)

    % Coefficient Ordering: (1) CH4, (2) CO2-1, (3) CO2-2, (4) CO, (5) H2-1, 
    %                       (6) H2-2, (7) N2, (8) O2-1, (9) O2-2, (10) H2S. 
    % Coeff = [   1  -1.34015E-02   3.66307E-04  -1.82249E-06   5.93988E-09  -9.14055E-12   6.78969E-15   -1.95049E-18
    %             2   2.97149E-03  -1.33472E-05   3.14444E-07  -4.75106E-10   2.68500E-13   0             0
    %             3   6.08538E-02  -3.63680E-04   1.01344E-06  -9.70424E-10   3.27864E-13   0             0
    %             4  -7.41704E-04   9.87435E-05  -3.77511E-08  -1.99334E-11   3.65528E-14  -1.24272E-17   0
    %             5   2.00971E-02   3.23462E-04   2.16372E-06  -6.49151E-09   5.52408E-12   0             0
    %             6   1.08311E-01   2.21164E-04   2.26381E-07  -1.74259E-10   4.64686E-14   0             0
    %             7  -1.52318E-03   1.18880E-04  -1.20928E-07   1.15568E-10  -6.36537E-14   1.47167E-17   0
    %             8  -7.67278E-04   1.03560E-04  -4.62034E-08   1.51980E-11  0              0             0
    %             9  -1.86545E-01   7.05649E-04  -7.71025E-07   4.02144E-10  -7.84908E-14   0             0
    %             10  1.50370E00    4.93050E-02   9.83960E-05  -1.74930E-07   1.84790E-10  -1.04140E-13   -2.32660E-17];

    % CO2-1 < 600K; H2-1 < 500 K; O2-1 < 1000 K 

    % For efficiency's sake, only the correlations falling within the
    % typical reactor temperature range are taken. 
    % Note that oxygen is assumed to follow curve above 1000K, given that this
    % is where the reactor will most often operate. 

    Coeff1 = [   1  -1.34015E-02   3.66307E-04  -1.82249E-06   5.93988E-09  -9.14055E-12   6.78969E-15   -1.95049E-18
                 3   6.08538E-02  -3.63680E-04   1.01344E-06  -9.70424E-10   3.27864E-13   0             0
                 0   0             0             0             0             0             0             0
                 4  -7.41704E-04   9.87435E-05  -3.77511E-08  -1.99334E-11   3.65528E-14  -1.24272E-17   0
                 6   1.08311E-01   2.21164E-04   2.26381E-07  -1.74259E-10   4.64686E-14   0             0
                 7  -1.52318E-03   1.18880E-04  -1.20928E-07   1.15568E-10  -6.36537E-14   1.47167E-17   0
                 9  -1.86545E-01   7.05649E-04  -7.71025E-07   4.02144E-10  -7.84908E-14   0             0
                 10  1.50370E-03   4.93050E-05   9.83960E-08  -1.74930E-10   1.84790E-13  -1.04140E-16   2.32660E-20];

    % Thermal conductivities are calculated in units of W/m.K
    PureCond(:,:,1) = (T./T)*Coeff1(:,2)' + T*Coeff1(:,3)' + (T.^2)*Coeff1(:,4)' + ...
        (T.^3)*Coeff1(:,5)' + (T.^4)*Coeff1(:,6)' + (T.^5)*Coeff1(:,7)' + ...
        (T.^6)*Coeff1(:,8)';
    
    %% Steam Conductivity
    
    % This is calculated for water in the vapour phase. 

    % Water density is needed for this calculation, and is here calculated
    % using the Peng Robinson Equation of State. 

    % rhoSTP = 44.59; % mol/m^3
    rho = 44.59 .* ((P./101315).*(273.15./T)); % Guess using IGL

    % Values commented out to speed up computation; pre-calculated and
    % entered in below. 

    % T_crit = 647.3 % deg-K
    % P_crit = 22.12 % MPa
    % acentric = 0.344 % no dim.

    % Calculation of coefficients for PR-EOS calculation. 
    % kappa = (0.37464 + 1.54226 .* 0.344 - 0.26992 .* 0.344 .^ 2);
    % alpha = (1 + kappa .* (1 - sqrt(T .* (1 ./ 647.3)))).^2;
    % a_c = (0.45723553 .* (8.3144598 .^ 2)) .* ((647.3 .^ 2) ./ (22.12 .* 10^6)); 
    % a = a_c .* alpha; 
    
    a = (0.598734298607441) .* (1 + (0.873236186880000) .* (1 - sqrt(T .* (1 ./ 647.3)))).^2;
    b = (0.07779607 .* 8.3144598) .* (647.3 ./ (22.12 .* 10^6));
    R = 8.3144598; % m^3*Pa/K/mol, universal gas constant
    
    rhoCheck = rho;
    
    % Calculation of compressibility factor for desired species. 
    Z_mix = 1./(1 - b .* (rho)) - (a ./ (b .* 8.3144598 .* T)) .* (b .* rho ./ (1 + ...
        2 .* b .* rho - b.^2 .* rho .^2));
    
    % Ideal gas law, n/V = rho = R/ZRT.
    rho = P ./ (Z_mix .*R .* T); %mol/m^3
    
    % Calculation iterates until the error threshold is satisfied. 
    while sum(abs(1-rho./rhoCheck)) > 10E-3
    
    % Calculation of compressibility factor for desired species. 
    Z_mix = 1./(1 - b .* (rho)) - (a ./ (b .* R .* T)) .* (b .* rho ./ (1 + ...
        2 .* b .* rho - b.^2 .* rho .^2));
    
    % Ideal gas law, n/V = rho = R/ZRT.
    rho = P ./ (Z_mix .*R .* T); %mol/m^3
    
    rhoCheck = rho;
    
    end
    
    % The thermal conductivity of water is calculated based on "Revised Release
    % on the IAPS Formulation 1985 for the Thermal Conductivity of Ordinary
    % Water Substance" from the International Association for the Properties of
    % Water and Steam.

    % Data taken from:
    % Wagner, W., Kretzschmar, H-J. (2008). International Steam Tables (2nd
    % Ed.). Berlin, Germany: Springer-Verlag. 

    theta = T ./ 647.096; % reduced temperature. 
    delta = (rho .* 18.02 ./ 1000) ./ 322; % actual mass dens. divided by critical density

    % Coefficients for reduced temperature contribution. 
%     coeff1 =   [1 0.0102811
%                 2 0.0299621
%                 3 0.0156146
%                 4 -0.00422464];

%     Original Looping Code.
%     term1sum = 0;
%     for i = 1:4
%         term1sum = term1sum + coeff1(i,2) .* theta .^ (i-1);
%     end

    term1sum = (0.0102811) .* theta .^ (1-1)+ (0.0299621) .* theta .^ (1-2)+...
        (0.0156146) .* theta .^ (1-3)+ (-0.00422464) .* theta .^ (1-4);
    
    % Coefficients for reduced volume contribution. 
%     n1 = -0.397070; n2 = 0.400302; n3 = 1.06000;
%     n4 = -0.171587; n5 = 2.39219;
    
    % Reduced temperature and volume terms. 
    lambda0 = (theta .^ 0.5) .* term1sum;
    lambda1 = (-0.397070) + (0.400302) .* delta + (1.06000) .* exp((-0.171587) .* (delta + (2.39219)) .^ 2);
    
    % Coefficients for reduced temperature and volume interaction term. 
%     m1 = 0.0701309; m2 = 0.0118520; m3 = 0.642857; m4 = 0.00169937;
%     m5 = -1.02000; m6 = -4.11717; m7 = -6.17937; m8 = 0.0822994;
%     m9 = 10.0932; m10 = 0.00308976;
    
    termA = 2 + (0.0822994) .* (abs(theta-1)+(0.00308976)) .^ -0.6;

    if theta >= 1
        termB = (abs(theta-1)+(0.00308976)) .^ -1;
    else
        termB = (10.0932) .* ((abs(theta-1)+(0.00308976)).^-0.6);
    end

    % Combined reduced temperature and volume term. 
    lambda2 = ((0.0701309) .* (theta .^ -10) + (0.0118520)) .*...
        (delta .^ 1.8) .* exp((0.642857) .* (1 - (theta .^ 1.8))) +...
        (0.00169937) .* termA .* (delta .^ termB) .* exp((termB ./ ...
        (1 + termB) .* (1 - (delta .^ (1 + termB))))) + (-1.02000) .*...
        exp((-4.11717) .* (theta .^ 1.5) + (-6.17937) .* (delta .^ -5));

    % Sum terms to find thermal conductivity, in W/m.K
    PureCond(:,3,1) = lambda0 + lambda1 + lambda2; % W/m.K
    
    % In the expression from Mason & Saxena, the thermal conductivities of
    % each gas species are calculated, and are then summed up into the
    % total gas mixture. For example, for a CH4-CO2-H2O feed mixture, the
    % viscosity would be the sum of the binary mixture viscosities for
    % CH4-CO2, CH4-H2O, and CO2-H2O. Mason & Saxena are taken as a
    % semi-empirical method.
    
    % A number of alternative mixed gas methods can be found in The
    % Properties of Gases and Liquids, commonly derived from either
    % Chapman-Enskog theory or Corresponding States theory. 
    
    % Precalculate as much as possible, using the fact that molar weights
    % are constant throughout the reactor.s
    M_AB = PureCond(1,:,2).' * (1./(PureCond(1,:,2)));
    M_AB1 = (1./sqrt(8)) .* ((1 + M_AB) .^ (-1/2)); M_AB2 = ((1./M_AB).^(1/4));

    % Multicomponent conductivities for each species are calculated, one
    % species at a time. 
    SpecCond = zeros(i,1);
    for j = 1:i
        v_AB = PureCond(j,:,1).' * (1./(PureCond(j,:,1)));
        BinCond = M_AB1 .* (1 + ((v_AB).^(1/2)).*M_AB2).^2;
        SpecCond(j,1) = sum(PureCond(j,:,1) .* PureCond(j,:,3) .* (1./(PureCond(j,:,3) * BinCond.'))); 
    end
    
    % An alternate calculation based on simple ideal gas law mixing is made
    % available as well. 
    IGLCond = PureCond(:,1,1) .* PureCond(:,1,3) + PureCond(:,2,1) .* PureCond(:,2,3) + ...
        PureCond(:,3,1) .* PureCond(:,3,3) + PureCond(:,4,1) .* PureCond(:,4,3) + ...
        PureCond(:,5,1) .* PureCond(:,5,3) + PureCond(:,6,1) .* PureCond(:,6,3) + ...
        PureCond(:,7,1) .* PureCond(:,7,3) + PureCond(:,8,1) .* PureCond(:,8,3);
    
    % W/m.K --> J/m.s.k to kJ/m.s.K
    %TotalCond = IGLCond./1000;
    TotalCond = SpecCond./1000;
    
end