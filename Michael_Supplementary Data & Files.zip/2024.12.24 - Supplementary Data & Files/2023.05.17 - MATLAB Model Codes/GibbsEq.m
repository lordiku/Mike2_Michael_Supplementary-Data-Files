
% Gibbs free energy minimization is used to determine the equilibrium
% compositions of the gas-phase within the reactor for each cell within the
% reactor domain. This function can also be used independently as needed.
% Note that this function determines equilibrium for the steam-methane
% reforming reactions considered in this simulation; it will not compute
% generalized equilibria for a variety of possible species. 

% The Lagrange Multiplier method is used to minimize the gibbs free energy
% based on the species, elements, and reactions involved. See Tutorial B in
% the thesis for details. 

% Note that hydrogen sulfide is excluded from this calculation as it is a 
% minor component; its inclusion would require addition of the element 
% "sulfur" to the calculation in order to account for a species amounting 
% to ~0.01% mol fraction. A large increase in computational effort is 
% required for a small gain in precision of calculation. 

function NjEq = GibbsEq(P,T,xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2)

    % The moles of each element per atomic species, C, H, O, and N, are 
    % determined based on the molecular species present.  
    % Ordering is CH4, CO2, H2O, CO, H2, N2, O2.
    a = [1 1 0 1 0 0 0; 4 0 2 0 2 0 0; 0 2 1 1 0 0 2; 0 0 0 0 0 2 0];

    R = 8.314459; % J/mol.K, Universal gas constant. 
    T0 = 298; P0 = 101325; % Standard temperature and pressure defined. 

    % Where N2 or O2 are not present in the reactor, they are set to a very
    % small non-zero value in order to allow the solver to work. Values
    % cannot be zero. 
    if xMN2 <= 0
        xMN2 = 0.000000001; xMCH4 = xMCH4 - xMN2;
    end

    if xMO2 <= 0
        xMO2 = 0.000000001; xMCH4 = xMCH4 - xMO2;
    end
    
    % A starting quantity of 100 moles is set. 
    NT = 100; NTo = NT; % mol, total moles.

    % The corresponding number of moles per species is calculated. 
    y_i = [xMCH4; xMCO2; xMH2O; xMCO; xMH2; xMN2; xMO2];
    Nj = [xMCH4*NT; xMCO2*NT; xMH2O*NT; xMCO*NT; xMH2*NT; xMN2*NT; xMO2*NT]; 
    Njo = Nj; % mol, species moles. 

    % The corresponding numnber of moles per atomic element is calculated. 
    atom(1,1) = a(1,1)*Nj(1,1) + a(1,2)*Nj(2,1) + a(1,3)*Nj(3,1)...
        + a(1,4)*Nj(4,1) + a(1,5)*Nj(5,1) + a(1,6)*Nj(6,1) + a(1,7)*Nj(7,1);
    atom(2,1) = a(2,1)*Nj(1,1) + a(2,2)*Nj(2,1) + a(2,3)*Nj(3,1)...
        + a(2,4)*Nj(4,1) + a(2,5)*Nj(5,1) + a(2,6)*Nj(6,1) + a(2,7)*Nj(7,1);
    atom(3,1) = a(3,1)*Nj(1,1) + a(3,2)*Nj(2,1) + a(3,3)*Nj(3,1)...
        + a(3,4)*Nj(4,1) + a(3,5)*Nj(5,1) + a(3,6)*Nj(6,1) + a(3,7)*Nj(7,1);
    atom(4,1) = a(4,1)*Nj(1,1) + a(4,2)*Nj(2,1) + a(4,3)*Nj(3,1)...
        + a(4,4)*Nj(4,1) + a(4,5)*Nj(5,1) + a(4,6)*Nj(6,1) + a(4,7)*Nj(7,1);

    % Gibbs energy of formation vs. temperature. 
    % Correlated from data taken from CRC Handbook of Chemistry and
    % Physics, 102nd Edition. Values in J/mol.
    
    gf(1,1) = 104.26*T - 83848;                     % CH4
    gf(2,1) = 0.0011196*T^2 - 3.5778*T - 393407;    % CO2
    gf(3,1) = 53.429*T - 245497;                    % H2O
    gf(4,1) = -88.901*T - 111008;                   % CO
    gf(5,1) = 0;                                    % H2
    gf(6,1) = 0;                                    % N2
    gf(7,1) = 0;                                    % O2
    
   %% PENG ROBINSON CALC FOR FUGACITY
    % Zfactor uses the Peng-Robinson Equation of State to calculate the
    % compressibility factor (Z factor) for a given gaseous species. 
    % Dimensionless PR equation is used, cubic for Z is solved numerically.

    % P - Pa; T - K; i - number of cells/elements

    % Data taken from: 
    % Elliott, J., Lira, C. (2012). Introductory Chemical Engineering
    % Thermodynamics (2nd Ed.). Upper Saddle River, NJ: Pearson Education Inc.

    % R = ones(1,1)*8.3144598; % m^3*Pa/K/mol, universal gas constant

    % Critical temperatures, pressures, and acentric factors for species.
    % deg-K, MPa, [no dim.]
    PRSpec = [ 190.6  4.604  0.011       %CH4
               304.2  7.382  0.228       %CO2
               647.3  22.12  0.344       %H2O
               132.9  3.499  0.066       %CO
               33.3   1.297  -0.215      %H2
               126.1  3.394  0.040       %N2
               154.6  5.043  0.022       %O2
               ];

    % Retrieves values for desired species, based on [s] index. 
    T_crit = PRSpec(:,1).'; % deg-K
    P_crit = PRSpec(:,2).'; % MPa
    acentric = PRSpec(:,3).'; % no dim.

    % Calculation of coefficients for PR-EOS calculation. 
    kappa = ones(1,1)*(0.37464 + 1.54226 .* acentric - 0.26992 .* acentric .^ 2);

    alpha = (1 + kappa .* (1 - sqrt(T * (1 ./ T_crit)))).^2;
    a_c = (0.45723553 .* (R .^ 2)) * ((T_crit .^ 2) ./ (P_crit .* 10^6)); 
    a1 = a_c .* alpha; 
    b = (0.07779607 .* R) * (T_crit ./ (P_crit .* 10^6));

    % van der Waals mixing rules applied to Peng Robinson. 
    
   %% GIBBS MINIMIZATION VIA LAGRANGE MULTIPLIERS
    
    ItErr = 1; ItCount = 0;
    while ItErr > 10E-9
    
    % Solve species compressibility factors. 
    A = a1.*P./(R^2.*T.^2); B = b.*P./(R.*T);
    Zpoly = [ones(7,1) -(1-B).' (A-3.*B.^2-2.*B).' (A.*B-B.^2-B.^3).'];

    % The [roots] function is an in-built MATLAB function to help quickly
    % solve cubic equations. 
    ZCalc(:,1) = roots (Zpoly(1,:)); 
    ZCalc(:,2) = roots (Zpoly(2,:)); 
    ZCalc(:,3) = roots (Zpoly(3,:)); 
    ZCalc(:,4) = roots (Zpoly(4,:)); 
    ZCalc(:,5) = roots (Zpoly(5,:)); 
    ZCalc(:,6) = roots (Zpoly(6,:)); 
    ZCalc(:,7) = roots (Zpoly(7,:)); 

    % Three roots are calculated; the first is taken as the true value.
    Z = ZCalc(1,:);

    % Pure species fugacity is calculated for each species; note the gibbs
    % free energy minimization is done from a reference condition that
    % assumes a pure species. 
    f_phi = exp(Z-1-log(Z-B)-A./(B.*sqrt(8)).*log((Z+(1+sqrt(2)).*B)./(Z+(1-sqrt(2)).*B)));
    fug = zeros(1,7); fug(1,:) = f_phi(1,:)';

    % Gibbs energy for the species is calculated. 
    gj = (gf + R*T*log(Nj) - R*T*log(NT)*ones(7,1) + R*T*log((fug'.*P./P0))); 
    %gj = (gf + R*T*log((fug'/P0))); 
    
    % Gibbs minimization matrix is assembled.
    GibbsA = zeros(12,12); GibbsB = zeros(12,1);
    
    GibbsB(1,1) = -gj(1,1)/(R*T);
    GibbsB(2,1) = -gj(2,1)/(R*T);
    GibbsB(3,1) = -gj(3,1)/(R*T);
    GibbsB(4,1) = -gj(4,1)/(R*T);
    GibbsB(5,1) = -gj(5,1)/(R*T);
    GibbsB(6,1) = -gj(6,1)/(R*T);
    GibbsB(7,1) = -gj(7,1)/(R*T);
    GibbsB(8,1) = atom(1,1) - (a(1,1)*Nj(1,1) + a(1,2)*Nj(2,1) + a(1,3)*Nj(3,1) + a(1,4)*Nj(4,1) + a(1,5)*Nj(5,1) + a(1,6)*Nj(6,1) + a(1,7)*Nj(7,1));
    GibbsB(9,1) = atom(2,1) - (a(2,1)*Nj(1,1) + a(2,2)*Nj(2,1) + a(2,3)*Nj(3,1) + a(2,4)*Nj(4,1) + a(2,5)*Nj(5,1) + a(2,6)*Nj(6,1) + a(2,7)*Nj(7,1));
    GibbsB(10,1) = atom(3,1) - (a(3,1)*Nj(1,1) + a(3,2)*Nj(2,1) + a(3,3)*Nj(3,1) + a(3,4)*Nj(4,1) + a(3,5)*Nj(5,1) + a(3,6)*Nj(6,1) + a(3,7)*Nj(7,1));
    GibbsB(11,1) = atom(4,1) - (a(4,1)*Nj(1,1) + a(4,2)*Nj(2,1) + a(4,3)*Nj(3,1) + a(4,4)*Nj(4,1) + a(4,5)*Nj(5,1) + a(4,6)*Nj(6,1) + a(4,7)*Nj(7,1));
    GibbsB(12,1) = NT-sum(Nj);
    
    GibbsA(1:7,1:7) = eye(7);
    GibbsA(1:7,8:11) = -a.';
    GibbsA(1:7,12) = -1;
    GibbsA(8,1:7) = a(1,:).*Nj';
    GibbsA(9,1:7) = a(2,:).*Nj';
    GibbsA(10,1:7) = a(3,:).*Nj';
    GibbsA(11,1:7) = a(4,:).*Nj';
    GibbsA(12,1:7) = Nj;
    GibbsA(12,12) = -NT;
    
    % Gibbs minimization matrix is solved, and the corresponding moles for
    % each species as well as the total moles of the gas phase are
    % retrieved. 
    GibbsSol = GibbsA\GibbsB;
    
    dlnNj = GibbsSol(1:7,1);
    dlnNT = GibbsSol(12,1);
    
    Nj = exp(log(Nj) + dlnNj);
    NT = exp(log(NT) + dlnNT);
    
    % The total error, based on the sum of all species vs. the calculated
    % total moles in the gas-phase, is computed. The algorithm repeats
    % until these two values converge to within the error tolerance. 
    ItErr = abs((sum(Nj)-NT)/NT);
    ItCount = ItCount + 1;
    
    if ItErr < 0.01
        y_i(1:7) = Nj(1:7)./NT; 
    end

    end
    
    % Equilibrium mole fractions are then returned. 
    NjEq = Nj./NT;
    