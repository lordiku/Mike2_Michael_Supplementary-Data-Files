
% First, state values are retrieved for the domain. Pressure, temperature,
% and species composition (both mass and mole fraction). 
i = cellnum;
P = rMatrixPress(:,k); T = rMatrixTemp(:,k); xCH4 = rMatrixFrac_CH4(:,k);
xCO2 = rMatrixFrac_CO2(:,k); xH2O = rMatrixFrac_H2O(:,k);
xCO = rMatrixFrac_CO(:,k); xH2 = rMatrixFrac_H2(:,k); 
xN2 = rMatrixFrac_N2(:,k); xO2 = rMatrixFrac_O2(:,k); xH2S = rMatrixFrac_H2S(:,k); 
xMCH4 = rMatrixFracM_CH4(:,k); xMCO2 = rMatrixFracM_CO2(:,k); xMH2O = rMatrixFracM_H2O(:,k);
xMCO = rMatrixFracM_CO(:,k); xMH2 = rMatrixFracM_H2(:,k); 
xMN2 = rMatrixFracM_N2(:,k); xMO2 = rMatrixFracM_O2(:,k); xMH2S = rMatrixFracM_H2S(:,k); 

Ps = sMatrixPress(:,k); Ts = sMatrixTemp(:,k); xsCH4 = sMatrixFrac_CH4(:,k);
xsCO2 = sMatrixFrac_CO2(:,k); xsH2O = sMatrixFrac_H2O(:,k);
xsCO = sMatrixFrac_CO(:,k); xsH2 = sMatrixFrac_H2(:,k); 
xsN2 = sMatrixFrac_N2(:,k); xsO2 = sMatrixFrac_O2(:,k); xsH2S = sMatrixFrac_H2S(:,k); 
xsMCH4 = sMatrixFracM_CH4(:,k); xsMCO2 = sMatrixFracM_CO2(:,k); xsMH2O = sMatrixFracM_H2O(:,k);
xsMCO = sMatrixFracM_CO(:,k); xsMH2 = sMatrixFracM_H2(:,k); 
xsMN2 = sMatrixFracM_N2(:,k); xsMO2 = sMatrixFracM_O2(:,k); xsMH2S = sMatrixFracM_H2S(:,k); 

% H2S coverage data is also retrieved. 
H2SCov = sCoverage(:,k);

% Next, properties for gas-phase density, thermal conductivity, heat
% capacity, and dynamic viscosity are calculated. These are largely
% vectorized functions, and will return a vector of values for that
% property in this time step. 
rMatrixDens(:,k) = Mix_Dens(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, xMH2S, i);
rMatrix_cond(:,k) = Mix_Cond(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, xMH2S, i);
rMatrix_Mu(:,k) = Mix_Visc(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, xMH2S, i);

% Properties are also calculated at the catalyst surface, including an
% update to the rates of reaction. 
sMatrixDens(:,k) = Mix_Dens(Ps, Ts, xsMCH4, xsMCO2, xsMH2O, xsMCO, xsMH2, xsMN2, xsMO2, xsMH2S, i);
sMatrix_cond(:,k) = Mix_Cond(Ps, Ts, xsMCH4, xsMCO2, xsMH2O, xsMCO, xsMH2, xsMN2, xsMO2, xsMH2S, i);
sMatrix_Mu(:,k) = Mix_Visc(Ps, Ts, xsMCH4, xsMCO2, xsMH2O, xsMCO, xsMH2, xsMN2, xsMO2, xsMH2S, i);
sMatrixRXN(1:i,k,:) = RXNCalcVect(Ps, Ts, xsMCH4, xsMCO2, xsMH2O, xsMCO, xsMH2, xsMN2, xsMO2, H2SCov, i, rxnmech, convmod);

%% Gas-Phase Reactor-Scale Heat Capacity

% The following code calculates heat capacity of the gas phase. 

% Data taken from: 
% Elliott, J., Lira, C. (2012). Introductory Chemical Engineering
% Thermodynamics (2nd Ed.). Upper Saddle River, NJ: Pearson Education Inc.

% Coefficient value matrix
% Rows: CH4, CO2, H2O, CO, H2, N2, O2, H2S
% Columns: index, "C1", "C2", "C3", "C4"
Coeff = [   1   19.25   5.21E-02    1.20E-05   -1.13E-08
            2   19.80   7.34E-02   -5.60E-05    1.72E-08
            3   32.24   1.92E-03    1.06E-05   -3.60E-09
            4   30.87  -1.29E-02    2.79E-05   -1.27E-08
            5   27.14   9.27E-03   -1.38E-05    7.65E-09
            6   31.15  -0.01357     2.68E-05   -1.17E-08
            7   28.11  -3.70E-06    1.75E-05   -1.07E-08
            8   31.90   2.34E-03    2.18E-05   -1.02E-08];

% Calculations are based on an empirical relationship:
% C1 + C2 * T + C3 * T^2 + C4 * T^3

% Each individual gas species' heat capacity is calculated. 
% Returns as J/mol.K
Poly_Cp1 = (Coeff(1,2) + Coeff(1,3).*T + Coeff(1,4).*T.^2 + Coeff(1,5).*T.^3);
Poly_Cp2 = (Coeff(2,2) + Coeff(2,3).*T + Coeff(2,4).*T.^2 + Coeff(2,5).*T.^3);
Poly_Cp3 = (Coeff(3,2) + Coeff(3,3).*T + Coeff(3,4).*T.^2 + Coeff(3,5).*T.^3);
Poly_Cp4 = (Coeff(4,2) + Coeff(4,3).*T + Coeff(4,4).*T.^2 + Coeff(4,5).*T.^3);
Poly_Cp5 = (Coeff(5,2) + Coeff(5,3).*T + Coeff(5,4).*T.^2 + Coeff(5,5).*T.^3);
Poly_Cp6 = (Coeff(6,2) + Coeff(6,3).*T + Coeff(6,4).*T.^2 + Coeff(6,5).*T.^3);
Poly_Cp7 = (Coeff(7,2) + Coeff(7,3).*T + Coeff(7,4).*T.^2 + Coeff(7,5).*T.^3);
Poly_Cp8 = (Coeff(8,2) + Coeff(8,3).*T + Coeff(8,4).*T.^2 + Coeff(8,5).*T.^3);    

% Heat capacity is taken as the sum of products of individual species
% heat capacities and their molar fractions. 
CalcCp = Poly_Cp1.*xCH4 + Poly_Cp2.*xCO2 + Poly_Cp3.*xH2O +...
    Poly_Cp4.*xCO + Poly_Cp5.*xH2 + Poly_Cp6.*xN2 + ...
    Poly_Cp7.*xO2 + Poly_Cp8.*xH2S;

% Calculating mean mass density (g/mol) for gas mixture. 
mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
mN2 = 28.02; mO2 = 32.00; mH2S = 34.03;
MoltoMass = mCH4*xMCH4 + mCO*xMCO + mCO2*xMCO2 + mH2*xMH2 + mH2O*xMH2O + ...
    mN2*xMN2 + mO2*xMO2 + mH2S*xMH2S;

% Convert J/mol.K * (1 kJ/1000 J) * (mol/g) * (1000g/kg) = kJ/kg.K
rMatrixCp(:,k) = CalcCp .*(1/1000).*(1./MoltoMass).*1000;

% Calculations are also done for the catalyst surface concentration. 
% Individual gas speices heat capacities. Returns as J/mol.K
Poly_Cp1 = (Coeff(1,2) + Coeff(1,3).*Ts + Coeff(1,4).*Ts.^2 + Coeff(1,5).*Ts.^3);
Poly_Cp2 = (Coeff(2,2) + Coeff(2,3).*Ts + Coeff(2,4).*Ts.^2 + Coeff(2,5).*Ts.^3);
Poly_Cp3 = (Coeff(3,2) + Coeff(3,3).*Ts + Coeff(3,4).*Ts.^2 + Coeff(3,5).*Ts.^3);
Poly_Cp4 = (Coeff(4,2) + Coeff(4,3).*Ts + Coeff(4,4).*Ts.^2 + Coeff(4,5).*Ts.^3);
Poly_Cp5 = (Coeff(5,2) + Coeff(5,3).*Ts + Coeff(5,4).*Ts.^2 + Coeff(5,5).*Ts.^3);
Poly_Cp6 = (Coeff(6,2) + Coeff(6,3).*Ts + Coeff(6,4).*Ts.^2 + Coeff(6,5).*Ts.^3);
Poly_Cp7 = (Coeff(7,2) + Coeff(7,3).*Ts + Coeff(7,4).*Ts.^2 + Coeff(7,5).*Ts.^3);
Poly_Cp8 = (Coeff(8,2) + Coeff(8,3).*Ts + Coeff(8,4).*Ts.^2 + Coeff(8,5).*Ts.^3);    

% Heat capacity is taken as the sum of products of individual species
% heat capacities and their molar fractions. 
CalcCp = Poly_Cp1.*xsCH4 + Poly_Cp2.*xsCO2 + Poly_Cp3.*xsH2O +...
    Poly_Cp4.*xsCO + Poly_Cp5.*xsH2 + Poly_Cp6.*xsN2 + ...
    Poly_Cp7.*xsO2 + Poly_Cp8.*xsH2S;

% Getting mean mass density (g/mol) for gas mixture. 
mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
mN2 = 28.02; mO2 = 32.00; mH2S = 34.03;
MoltoMass = mCH4*xsMCH4 + mCO*xsMCO + mCO2*xsMCO2 + mH2*xsMH2 + mH2O*xsMH2O + ...
    mN2*xsMN2 + mO2*xsMO2 + mH2S*xsMH2S;

% Convert J/mol.K * (1 kJ/1000 J) * (mol/g) * (1000g/kg) = kJ/kg.K
sMatrixCp(:,k) = CalcCp .*(1/1000).*(1./MoltoMass).*1000;

%%

% Getting the average molar density for the reactor domain. 
% mol/m^3 = kg/m^3 / (g/mol *(1 kg/1000g)
rMatrixDensM(:,k) = rMatrixDens(:,k) ./ (MoltoMass/1000);
rho = rMatrixDens(:,k); rhoM = rMatrixDensM(:,k);

% Pressure, temperature, and species data are retrieved from memory. 
P = rMeshPress(:,k); T = rMeshTemp(:,k); xCH4 = rMeshFrac_CH4(:,k);
xCO2 = rMeshFrac_CO2(:,k); xH2O = rMeshFrac_H2O(:,k);
xCO = rMeshFrac_CO(:,k); xH2 = rMeshFrac_H2(:,k); 
xN2 = rMeshFrac_N2(:,k); xO2 = rMeshFrac_O2(:,k); xH2S = rMeshFrac_H2S(:,k); 
xMCH4 = rMeshFracM_CH4(:,k); xMCO2 = rMeshFracM_CO2(:,k); xMH2O = rMeshFracM_H2O(:,k);
xMCO = rMeshFracM_CO(:,k); xMH2 = rMeshFracM_H2(:,k); 
xMN2 = rMeshFracM_N2(:,k); xMO2 = rMeshFracM_O2(:,k); xMH2S = rMeshFracM_H2S(:,k); 

% Diffusivity is calculated at each face of the reactor domain. 
i = facenum;
rdiff = Mix_MolDiff(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, xMH2S, i, rp);

% Cell face properties are calculated as linear interpolations between cell
% centers. A more robust approach would be to calculate values directly,
% but this increases computational cost. 

i = cellnum;
muFace = cat(1,rMesh_mu(1,k-1),(rMatrix_Mu(1:i-1,k)+rMatrix_Mu(2:i,k))/2,rMatrix_Mu(i,k));
condFace = cat(1,rMesh_cond(1,k-1),(rMatrix_cond(1:i-1,k)+rMatrix_cond(2:i,k))/2,rMatrix_cond(i,k));
CpFace = cat(1,rMeshCp(1,k-1),(rMatrixCp(1:i-1,k)+rMatrixCp(2:i,k))/2,rMatrixCp(i,k));
DensFace = cat(1,rMeshDens(1,k-1),(rMatrixDens(1:i-1,k)+rMatrixDens(2:i,k))/2,rMatrixDens(i,k));

rMesh_mu(:,k) = muFace;
rMesh_cond(:,k) = condFace;
rMeshCp(:,k) = CpFace;
rMeshDens(:,k) = DensFace;

% Diffusivities for each of the species at every face are set. 
i = facenum;
rMesh_DCH4(:,k) = rdiff(:,1);
rMesh_DCO2(:,k) = rdiff(:,2);
rMesh_DH2O(:,k) = rdiff(:,3);
rMesh_DCO(:,k) = rdiff(:,4);
rMesh_DH2(:,k) = rdiff(:,5);
rMesh_DN2(:,k) = rdiff(:,6);
rMesh_DO2(:,k) = rdiff(:,7);
rMesh_DH2S(:,k) = rdiff(:,8);

% Getting mean mass density (g/mol) for gas mixture. 
mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
mN2 = 28.02; mO2 = 32.00; mH2S = 34.03;
MoltoMass = mCH4*xMCH4 + mCO*xMCO + mCO2*xMCO2 + mH2*xMH2 + mH2O*xMH2O + ...
        mN2*xMN2 + mO2*xMO2 + mH2S*xMH2S;

% mol/m^3 = kg/m^3 / (g/mol *(1 kg/1000g)
rMeshDensM(:,k) = rMeshDens(:,k) ./ (MoltoMass./1000);

%% Calculation of pellet internal gas-phase properties
% Triggers if the trip "convmod" is triggered, indicating that the
% simulation is running in conventional heterogeneous mode. 

if convmod ==1
    
    for j = 1:partnum
        % Reactions are calculated for every part of the catalyst in every cell
        % within the reactor domain. Data is retrieved from memory and used to
        % calculate reaction rate, which is then stored. 

        Pp = pMatrixPress(:,j,k); Tp = pMatrixTemp(:,j,k); xpMCH4 = pMatrixFracM_CH4(:,j,k);
        xpMCO2 = pMatrixFracM_CO2(:,j,k); xpMH2O = pMatrixFracM_H2O(:,j,k);
        xpMCO = pMatrixFracM_CO(:,j,k); xpMH2 = pMatrixFracM_H2(:,j,k); 
        xpMN2 = pMatrixFracM_N2(:,j,k); xpMO2 = pMatrixFracM_O2(:,j,k); xpH2S = pMatrixFrac_H2S(:,j,k); 
    
        H2SCov = pCoverage(:,j,k);
        RXNVal = RXNCalcVect(Pp, Tp, xpMCH4, xpMCO2, xpMH2O, xpMCO, xpMH2, xpMN2, xpMO2, H2SCov, i, rxnmech, convmod);
        pMatrixRXN(:,j,k,1) = RXNVal(:,1);
        pMatrixRXN(:,j,k,2) = RXNVal(:,2);
        pMatrixRXN(:,j,k,3) = RXNVal(:,3);    
    end
    
    for i = 1:cellnum
        % Catalyst effectiveness is calculated throughout the reactor. 
        eff1_c = sum(pMatrixRXN(i,:,k,1))./(pMatrixRXN(i,partnum,k,1).*partnum); rMatrixEff(i,k,1) = eff1_c;
        eff2_c = sum(pMatrixRXN(i,:,k,2))./(pMatrixRXN(i,partnum,k,2).*partnum); rMatrixEff(i,k,2) = eff2_c;
        eff3_c = sum(pMatrixRXN(i,:,k,3))./(pMatrixRXN(i,partnum,k,3).*partnum); rMatrixEff(i,k,3) = eff3_c;
    end
    
    for i = 1:cellnum
        % Catalyst properties are calculated throughout the reactor. Data
        % are retrieved for each reactor cell. 
        Pp = pMatrixPress(i,:,k)'; Tp = pMatrixTemp(i,:,k)'; xpCH4 = pMatrixFracM_CH4(i,:,k)';
        xpCO2 = pMatrixFracM_CO2(i,:,k)'; xpH2O = pMatrixFracM_H2O(i,:,k)';
        xpCO = pMatrixFracM_CO(i,:,k)'; xpH2 = pMatrixFracM_H2(i,:,k)'; 
        xpN2 = pMatrixFracM_N2(i,:,k)'; xpO2 = pMatrixFracM_O2(i,:,k)'; xpH2S = pMatrixFrac_H2S(i,:,k)'; 
    
        xpMCH4 = pMatrixFracM_CH4(i,:,k)'; xpMCO2 = pMatrixFracM_CO2(i,:,k)'; xpMH2O = pMatrixFracM_H2O(i,:,k)';
        xpMCO = pMatrixFracM_CO(i,:,k)'; xpMH2 = pMatrixFracM_H2(i,:,k)'; 
        xpMN2 = pMatrixFracM_N2(i,:,k)'; xpMO2 = pMatrixFracM_O2(i,:,k)'; xpMH2S = pMatrixFrac_H2S(i,:,k)'; 
        
        % Getting mean mass density (g/mol) for gas mixture. 
        mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
        mN2 = 28.02; mO2 = 32.00; mH2S = 34.03;
        MoltoMass = mCH4*xpMCH4 + mCO*xpMCO + mCO2*xpMCO2 + mH2*xpMH2 + mH2O*xpMH2O + ...
            mN2*xpMN2 + mO2*xpMO2 + mH2S*xpMH2S;
        
        % Catalyst pellet gas phase density is calculated. 
        pDensCalc = Mix_Dens(Pp, Tp, xpMCH4, xpMCO2, xpMH2O, xpMCO, xpMH2, xpMN2, xpMO2, xpMH2S, partnum); pMatrixDens(i,:,k) = pDensCalc'; 
        pMatrixDensM(i,:,k) = pMatrixDens(i,:,k) ./ (MoltoMass'/1000);        
        
        % The effective stagnant thermal conductivity of the pellet is
        % calculated as a function of solid and gas phase thermal
        % conductivities within the pellet, following Soomro & Hughes
        % (1979).

        % Catalyst pellet gas phase thermal conductivity is calculated.
        pCondCalc_g = Mix_Cond(Pp, Tp, xpMCH4, xpMCO2, xpMH2O, xpMCO, xpMH2, xpMN2, xpMO2, xpMH2S, partnum); 
    
        % Conductivity of alumina, A2O3, W/m.K
        % Calculated from Morrell, 1987; VTT, 1996. 
        cond_Al = 5.5 + 34.5 .* exp(-0.0033 .* (Tp - 273));  
        
        % Conductivity of nickel, W/m.K, estimated from Powell, 1965
        cond_Ni = 65; 
        
        % W/m.K --> J/m.s.k to kJ/m.s.K
        % Calculated based on assumed composition of 15% nickel. 
        cond_SMIX = (0.15.*cond_Ni + (1-0.15).*cond_Al)./1000; 
        
        % Calculation of the catalyst pellet effective stagnant thermal
        % conductivity, based on Soomro & Hughes, 1979. 
        pCondCalc = pCondCalc_g.*(cond_SMIX./pCondCalc_g).^(1-eps_p); 
        pMatrix_cond(i,:,k) = pCondCalc';
    
        % Calculations are also done for the pellet internal heat capacity as
        % well. 
    
        % Individual species heat capacities are calculated. 
        % Returns as J/mol.K
        Poly_Cp1 = (Coeff(1,2) + Coeff(1,3).*Tp + Coeff(1,4).*Tp.^2 + Coeff(1,5).*Tp.^3);
        Poly_Cp2 = (Coeff(2,2) + Coeff(2,3).*Tp + Coeff(2,4).*Tp.^2 + Coeff(2,5).*Tp.^3);
        Poly_Cp3 = (Coeff(3,2) + Coeff(3,3).*Tp + Coeff(3,4).*Tp.^2 + Coeff(3,5).*Tp.^3);
        Poly_Cp4 = (Coeff(4,2) + Coeff(4,3).*Tp + Coeff(4,4).*Tp.^2 + Coeff(4,5).*Tp.^3);
        Poly_Cp5 = (Coeff(5,2) + Coeff(5,3).*Tp + Coeff(5,4).*Tp.^2 + Coeff(5,5).*Tp.^3);
        Poly_Cp6 = (Coeff(6,2) + Coeff(6,3).*Tp + Coeff(6,4).*Tp.^2 + Coeff(6,5).*Tp.^3);
        Poly_Cp7 = (Coeff(7,2) + Coeff(7,3).*Tp + Coeff(7,4).*Tp.^2 + Coeff(7,5).*Tp.^3);
        Poly_Cp8 = (Coeff(8,2) + Coeff(8,3).*Tp + Coeff(8,4).*Tp.^2 + Coeff(8,5).*Tp.^3);    
        
        % Heat capacity is taken as the sum of products of individual species
        % heat capacities and their molar fractions. 
        pCpCalc = Poly_Cp1.*xpCH4 + Poly_Cp2.*xpCO2 + Poly_Cp3.*xpH2O +...
            Poly_Cp4.*xpCO + Poly_Cp5.*xpH2 + Poly_Cp6.*xpN2 + ...
            Poly_Cp7.*xpO2 + Poly_Cp8.*xpH2S;
        
        % Convert J/mol.K * (1 kJ/1000 J) * (mol/g) * (1000g/kg) = kJ/kg.K
        pMatrixCp(i,:,k) = pCpCalc' .*(1/1000).*(1./MoltoMass').*1000;
    
        % Values at the catalyst pellet surface are estimated based on the 
        % definition of the boundary condition at the surface. See Tutorial
        % D in the thesis for details. 

        pPressFace = cat(2,1.5.*pMatrixPress(i,1,k)-0.5.*pMatrixPress(i,2,k),...
            (pMatrixPress(i,1:partnum-1,k)+pMatrixPress(i,2:partnum,k))/2,...
            1.5.*pMatrixPress(i,partnum,k)-0.5*pMatrixPress(i,partnum-1,k));
        pTempFace = cat(2,1.5.*pMatrixTemp(i,1,k)-0.5.*pMatrixTemp(i,2,k),...
            (pMatrixTemp(i,1:partnum-1,k)+pMatrixTemp(i,2:partnum,k))/2,...
            1.5.*pMatrixTemp(i,partnum,k)-0.5*pMatrixTemp(i,partnum-1,k));
        xpCH4Face = cat(2,1.5.*pMatrixFrac_CH4(i,1,k)-0.5.*pMatrixFrac_CH4(i,2,k),...
            (pMatrixFrac_CH4(i,1:partnum-1,k)+pMatrixFrac_CH4(i,2:partnum,k))/2,...
            1.5.*pMatrixFrac_CH4(i,partnum,k)-0.5*pMatrixFrac_CH4(i,partnum-1,k));
        xpCO2Face = cat(2,1.5.*pMatrixFrac_CO2(i,1,k)-0.5.*pMatrixFrac_CO2(i,2,k),...
            (pMatrixFrac_CO2(i,1:partnum-1,k)+pMatrixFrac_CO2(i,2:partnum,k))/2,...
            1.5.*pMatrixFrac_CO2(i,partnum,k)-0.5*pMatrixFrac_CO2(i,partnum-1,k));
        xpH2OFace = cat(2,1.5.*pMatrixFrac_H2O(i,1,k)-0.5.*pMatrixFrac_H2O(i,2,k),...
            (pMatrixFrac_H2O(i,1:partnum-1,k)+pMatrixFrac_H2O(i,2:partnum,k))/2,...
            1.5.*pMatrixFrac_H2O(i,partnum,k)-0.5*pMatrixFrac_H2O(i,partnum-1,k));
        xpCOFace = cat(2,1.5.*pMatrixFrac_CO(i,1,k)-0.5.*pMatrixFrac_CO(i,2,k),...
            (pMatrixFrac_CO(i,1:partnum-1,k)+pMatrixFrac_CO(i,2:partnum,k))/2,...
            1.5.*pMatrixFrac_CO(i,partnum,k)-0.5*pMatrixFrac_CO(i,partnum-1,k));
        xpH2Face = cat(2,1.5.*pMatrixFrac_H2(i,1,k)-0.5.*pMatrixFrac_H2(i,2,k),...
            (pMatrixFrac_H2(i,1:partnum-1,k)+pMatrixFrac_H2(i,2:partnum,k))/2,...
            1.5.*pMatrixFrac_H2(i,partnum,k)-0.5*pMatrixFrac_H2(i,partnum-1,k));
        xpN2Face = cat(2,1.5.*pMatrixFrac_N2(i,1,k)-0.5.*pMatrixFrac_N2(i,2,k),...
            (pMatrixFrac_N2(i,1:partnum-1,k)+pMatrixFrac_N2(i,2:partnum,k))/2,...
            1.5.*pMatrixFrac_N2(i,partnum,k)-0.5*pMatrixFrac_N2(i,partnum-1,k));
        xpO2Face = cat(2,1.5.*pMatrixFrac_O2(i,1,k)-0.5.*pMatrixFrac_O2(i,2,k),...
            (pMatrixFrac_O2(i,1:partnum-1,k)+pMatrixFrac_O2(i,2:partnum,k))/2,...
            1.5.*pMatrixFrac_O2(i,partnum,k)-0.5*pMatrixFrac_O2(i,partnum-1,k));
        xpH2SFace = cat(2,1.5.*pMatrixFrac_H2S(i,1,k)-0.5.*pMatrixFrac_H2S(i,2,k),...
            (pMatrixFrac_H2S(i,1:partnum-1,k)+pMatrixFrac_H2S(i,2:partnum,k))/2,...
            1.5.*pMatrixFrac_H2S(i,partnum,k)-0.5*pMatrixFrac_H2S(i,partnum-1,k));
        pDensCalc = cat(2,1.5.*pMatrixDens(i,1,k)-0.5.*pMatrixDens(i,2,k),...
            (pMatrixDens(i,1:partnum-1,k)+pMatrixDens(i,2:partnum,k))/2,...
            1.5.*pMatrixDens(i,partnum,k)-0.5*pMatrixDens(i,partnum-1,k));
        pCondCalc = cat(2,1.5.*pMatrix_cond(i,1,k)-0.5.*pMatrix_cond(i,2,k),...
            (pMatrix_cond(i,1:partnum-1,k)+pMatrix_cond(i,2:partnum,k))/2,...
            1.5.*pMatrix_cond(i,partnum,k)-0.5*pMatrix_cond(i,partnum-1,k));
        pCpCalc = cat(2,1.5.*pMatrixCp(i,1,k)-0.5.*pMatrixCp(i,2,k),...
            (pMatrixCp(i,1:partnum-1,k)+pMatrixCp(i,2:partnum,k))/2,...
            1.5.*pMatrixCp(i,partnum,k)-0.5*pMatrixCp(i,partnum-1,k));
    
        pMeshPress(i,:,k) = pPressFace;
        pMeshTemp(i,:,k) = pTempFace;
        pMeshFrac_CH4(i,:,k) = xpCH4Face;
        pMeshFrac_CO2(i,:,k) = xpCO2Face;
        pMeshFrac_H2O(i,:,k) = xpH2OFace;
        pMeshFrac_CO(i,:,k) = xpCOFace;
        pMeshFrac_H2(i,:,k) = xpH2Face;
        pMeshFrac_N2(i,:,k) = xpN2Face;
        pMeshFrac_O2(i,:,k) = xpO2Face;
        pMeshFrac_H2S(i,:,k) = xpH2SFace;
         pMeshDens(i,:,k) = pDensCalc;
         pMesh_cond(i,:,k) = pCondCalc;
         pMeshCp(i,:,k) = pCpCalc;
    
        % Mole fractions of each species are calculated at each cell face
        % within the pellet. 
        MCH4 = pMeshFrac_CH4(i,:,k) ./ mCH4; MCO2 = pMeshFrac_CO2(i,:,k) ./ mCO2;
        MH2O = pMeshFrac_H2O(i,:,k) ./ mH2O; MCO = pMeshFrac_CO(i,:,k) ./ mCO;
        MH2 = pMeshFrac_H2(i,:,k) ./ mH2; MN2 = pMeshFrac_N2(i,:,k) ./ mN2;
        MO2 = pMeshFrac_O2(i,:,k) ./ mO2; MH2S = pMeshFrac_O2(i,:,k) ./ mH2S; 
        MTot = MCH4 + MCO2 + MH2O + MCO + MH2 + MN2 + MO2 + MH2S;
        
        pMeshFracM_CH4(i,:,k) = MCH4./MTot;
        pMeshFracM_CO2(i,:,k) = MCO2./MTot;
        pMeshFracM_H2O(i,:,k) = MH2O./MTot;
        pMeshFracM_CO(i,:,k) = MCO./MTot;
        pMeshFracM_H2(i,:,k) = MH2./MTot; 
        pMeshFracM_N2(i,:,k) = MN2./MTot; 
        pMeshFracM_O2(i,:,k) = MO2./MTot; 
        pMeshFracM_H2S(i,:,k) = MH2S./MTot; 
        pMeshFracM_ALL(i,:,k) = pMeshFracM_CH4(i,:,k) + pMeshFracM_CO2(i,:,k) + ...
            pMeshFracM_H2O(i,:,k) + pMeshFracM_CO(i,:,k) + pMeshFracM_H2(i,:,k) + ...
            pMeshFracM_N2(i,:,k) + pMeshFracM_O2(i,:,k) + pMeshFracM_H2S(i,:,k);
    
        % Reaction rates throughout the pellet are calculated and saved to 
        % memory.  
        Pp = pMeshPress(i,:,k)'; Tp = pMeshTemp(i,:,k)'; xpCH4 = pMeshFrac_CH4(i,:,k)';
        xpMCH4 = pMeshFracM_CH4(i,:,k)'; xpMCO2 = pMeshFracM_CO2(i,:,k)'; xpMH2O = pMeshFracM_H2O(i,:,k)';
        xpMCO = pMeshFracM_CO(i,:,k)'; xpMH2 = pMeshFracM_H2(i,:,k)'; 
        xpMN2 = pMeshFracM_N2(i,:,k)'; xpMO2 = pMeshFracM_O2(i,:,k)'; xpMH2S = pMeshFracM_H2S(i,:,k)'; 
        
        pdiffCalc = Mix_MolDiff(Pp, Tp, xpMCH4, xpMCO2, xpMH2O, xpMCO, xpMH2, xpMN2, xpMO2, xpMH2S, partface, rp);
        
        pdiff(i,:,k,1) = pdiffCalc(:,1); pMesh_DCH4(i,:,k) = pdiffCalc(:,1); 
        pdiff(i,:,k,2) = pdiffCalc(:,2); pMesh_DCO2(i,:,k) = pdiffCalc(:,2); 
        pdiff(i,:,k,3) = pdiffCalc(:,3); pMesh_DH2O(i,:,k) = pdiffCalc(:,3); 
        pdiff(i,:,k,4) = pdiffCalc(:,4); pMesh_DCO(i,:,k) = pdiffCalc(:,4); 
        pdiff(i,:,k,5) = pdiffCalc(:,5); pMesh_DH2(i,:,k) = pdiffCalc(:,5); 
        pdiff(i,:,k,6) = pdiffCalc(:,6); pMesh_DN2(i,:,k) = pdiffCalc(:,6); 
        pdiff(i,:,k,7) = pdiffCalc(:,7); pMesh_DO2(i,:,k) = pdiffCalc(:,7); 
        pdiff(i,:,k,8) = pdiffCalc(:,8); pMesh_DH2S(i,:,k) = pdiffCalc(:,8); 
    
    end
end