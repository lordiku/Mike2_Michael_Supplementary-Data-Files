
tic     % Begin MATLAB runtime timer; will record amount of time required 
        % to complete the simulation. 

% As part of the error trapping within [CalcSpec], "ForceReturn" is a flag
% to [CalcReactor] that an error has occurred and the program needs to
% immediately terminate. 
ForceReturn = 0;

% The first nested 'For-Next' loop allows iteration through differing H2S
% concentrations. This is initially set up to simulate the results of
% Koningen & Sjostrom (1998), but may be adapted as needed to simulate a
% range of H2S concentrations. 

for H2SParam = 1:6

% A 'Switch-Case' structure is used to select the appropriate H2S
% concentration. 

    switch H2SParam
        case 1
            H2Sppm = 0;
        case 2
            H2Sppm = 25;  
        case 3
            H2Sppm = 50;  
        case 4
            H2Sppm = 100;  
        case 5
            H2Sppm = 200;
        case 6
            H2Sppm = 300;
    end

% To simulate transient response to H2S turning "on" and "off" again in the
% feed, "tripstep" is used to signal the program to do so. Note that the 
% H2S concentration must be specified in the transient response block of 
% code below, and should be set to zero here in order to allow the reactor 
% to reach steady-state before introducing H2S into the feed. 

    tripstep = 2;   % Set this to '2' when not wanting to do transients. 

% "tripcount" designates the number of "runs" that must elapse before
% initiating H2S feed to the reactor. 

    tripcount = 0;

% The second nested 'For-Next' loop allows iteration through differing
% temperatures. Again, set up for K+S (1998), but may be adapted for
% whatever use is required. 

for TempParam = 2:9
    
% Data is cleared from MATLAB after each run, with the exception of
% indexing variables and key initializing variables. 

    clearvars -except ForceReturn TempParam H2SParam tripstep tripcount Truns T_init T_surr H2Sppm;
    
% An incrementation approach is taken to iterate through temperatures. In
% this code below, values from K+S are iterated through at 50 deg-K
% increments. The tube wall outer temperature is specified, with the
% reactor initial temperature and inlet temperature set to be the same as
% the tube outer wall temperature (assuming that the whole reactor is at
% temperature prior to any reaction beginning). 

    T_surr = 973 + 50 * (TempParam - 1); 
    T_in = T_surr;
    T_init = T_surr;
    
% When validating the model against Rout & Jakobsen (2015), inlet and wall
% temperatures are fixed per their modeling, with the initial tube
% temperature being set to the inlet temperature. The code shown here is
% adjusted to reflect this. 

% In some cases where reaction occurs very aggressively and requires very
% small time steps to be taken to remain stable, it may be suitable to set
% the reactor initial temperature to be much lower than the inlet or tube
% wall temperatures. If physically practical, this allows better stability
% at simulation start-up, and permits larger time steps to be considered.
% Another approach may be to start the reactor "inert" (i.e.,
% nitrogen-filled) in order to maintain stability at simulation start-up. 

% "WriteData" is used to index the writing of MATLAB data to excel
% following every call of [CalcOut]. It is reset here following every
% iteration of temperature and H2S concentration. 

    WriteData = 5;

% "rxnmech" and "convmod" allow switching between the reaction mechanism to
% use (1 - Xu & Froment, 1989; 2 - Hou, Fowles, & Hughes, 2001), and
% between which simulation framework to use (0 - simplified model; 1 - 
% conventional model. These must be set by the user prior to the start of
% simulation. Note also that there may be other configurations that need to
% be checked prior to the start of each run (e.g., heat transfer, reaction
% rate adjustments, etc.). 

    rxnmech = 2;
    convmod = 1; 

% [MeshGenXX] and [RXR_InitXX] are subroutines that first define the
% computational domain (1D axial for reactor, 1D radial for pellets) and
% set up the initial conditions of the simulation. "XX" here is meant for
% the initials / moniker identifying which case the subroutines are meant
% for; in what's shown here, K+S is initiallized. 

    MeshGenKS 
    RXR_InitKS

    R = 8.3144598; % Universal gas constant, m^3.Pa/K.mol or J/K.mol

    % Molar masses, g/mol
    mCH4 = sparse(16.04); mCO2 = sparse(44.02); mH2O = sparse(18.03); mCO = sparse(28.01); 
    mH2 = sparse(2.02); mN2 = sparse(28.02); mO2 = sparse(32.00);

% Iterations begin at the second time step - the first time step is defined
% at the initial conditions of the reactor. 'k' is the iterated variable
% for time. Time steps only advance once a complete solution for the
% reactor is achieved. 

% For greater clarity, "k" is meant to step through every discrete time dt
% for a fixed amount that can be easily stored in memory. Once all
% "timestep" has been completed, the values at time "k" are written to the
% value of "k=1" with the rest being cleared - effectively becoming the
% initial conditions for the next "run" of time. The "runs" of time then
% iterate until the total length of time desired has elapsed. 

% This architecture is necessary to avoid a blow-up of memory when trying
% to run a simulation (e.g., wanting 10 minutes of run-time, but needing to
% step through the simulation in 0.01 second increments). 

for run = 1:Truns
for k = 2:timestep

% Now the real fun begins :)

    i = cellnum;    % Used to keep the code clean, defining the size of the 
                    % arrays being referenced. 

% Values for pressure, temperature, and species mass fraction
% concentrations are retrieved from memory and loaded into working
% variables. Rows hold the value for each axial cell center, columns hold
% the values as they change through time. 

    % Retrieving reactor field property vectors. 
    P = rMatrixPress(:,k-1); T = rMatrixTemp(:,k-1); xCH4 = rMatrixFrac_CH4(:,k-1);
    xCO2 = rMatrixFrac_CO2(:,k-1); xH2O = rMatrixFrac_H2O(:,k-1);
    xCO = rMatrixFrac_CO(:,k-1); xH2 = rMatrixFrac_H2(:,k-1); 
    xN2 = rMatrixFrac_N2(:,k-1); xO2 = rMatrixFrac_O2(:,k-1); xH2S = rMatrixFrac_H2S(:,k-1);
    xMCH4 = rMatrixFracM_CH4(:,k-1); xMCO2 = rMatrixFracM_CO2(:,k-1); xMH2O = rMatrixFracM_H2O(:,k-1);
    xMCO = rMatrixFracM_CO(:,k-1); xMH2 = rMatrixFracM_H2(:,k-1); 
    xMN2 = rMatrixFracM_N2(:,k-1); xMO2 = rMatrixFracM_O2(:,k-1); xMH2S = rMatrixFracM_H2S(:,k-1); 

    % Computing average molecular weight, based on mole fractions. 
    M2m = mCH4.*xMCH4 + mCO.*xMCO + mCO2.*xMCO2 + mH2.*xMH2 + mH2O.*xMH2O + ...
        mN2.*xMN2 + mO2.*xMO2 + mH2S.*xMH2S;

    % Retrieving catalyst surface field property vectors.  
    Ts = sMatrixTemp(:,k-1); xsCH4 = sMatrixFrac_CH4(:,k-1);
    xsCO2 = sMatrixFrac_CO2(:,k-1); xsH2O = sMatrixFrac_H2O(:,k-1);
    xsCO = sMatrixFrac_CO(:,k-1); xsH2 = sMatrixFrac_H2(:,k-1); 
    xsN2 = sMatrixFrac_N2(:,k-1); xsO2 = sMatrixFrac_O2(:,k-1); xsH2S = sMatrixFrac_H2S(:,k-1);
    
    % Retrieving property data for coefficients. Cell centers are named,
    % face centers are indicated by number (1 - left face, 2 - right face).
    % uz - velocity; rho - gas density; Cp - gas heat capacity;
    % cond_g - gas thermal conductivity; mu - gas viscosity. 
    uz1 = rMeshVel(1:i,k-1); uz2 = rMeshVel(2:i+1,k-1); uz = rMatrixVel(:,k-1);
    rho1 = rMeshDens(1:i,k-1); rho2 = rMeshDens(2:i+1,k-1); rho = rMatrixDens(:,k-1);
    Cp1 = rMeshCp(1:i,k-1); Cp2 = rMeshCp(2:i+1,k-1); Cp = rMatrixCp(:,k-1);
    cond_g1 = rMesh_cond(1:i,k-1); cond_g2 = rMesh_cond(2:i+1,k-1); cond_g = rMatrix_cond(:,k-1);
    mu1 = rMesh_mu(1:i,k-1); mu2 = rMesh_mu(2:i+1,k-1); mu = rMatrix_Mu(:,k-1);

    % Retrieving property data at the catalyst surface. 
    rho_p = sMatrixDens(:,k-1); Cp_p = sMatrixCp(:,k-1);
    
    % Reynold's number and Prandtl numbers are computed, along with
    % friction coefficients used in total mass transport equation. 
    % Values are calculated at the faces. 

    % Note that some references indicate Reynold's number in porous media
    % as further needing to be divided by (1-eps). The definition of
    % Reynold's number used here is per Jakobsen (2008), "Chemical Reactor 
    % Modeling: Multiphase Reactive Flows", Eq. 11-4. This is also how
    % Reynold's number is defined in Wakao & Kaguei (1982), "Heat and Mass
    % Transfer in Packed Beds". 

    Re = rho.*uz.*d_p./(mu); Re1 = rho1.*uz1.*d_p./(mu1); Re2 = rho2.*uz2.*d_p./(mu2);
    Pr = Cp.*mu./cond_g; Pr1 = Cp1.*mu1./cond_g1; Pr2 = Cp2.*mu2./cond_g2;
    
    % Calculation of a pseudo-homogeneous mean density and heat capacity.
    % Taken as the volume-weighted average between solid and gas phases. 
    rhoCp = (1-eps).*rho_s.*Cp_s + (eps).*rho.*Cp; % Kg/m^3 * kJ/kg.K
    rhoCp_p = (1-eps_p).*rho_s.*Cp_s + (eps_p).*rho_p.*Cp_p; % Kg/m^3 * kJ/kg.K

% Calculation of effective thermal conductivity.
% This is based on the correlation of Kunii & Smith (1960). 
% Note that this calculation differs from what is used by R&J, where an
% earlier approach is used (Yagi et al., 1960). Kunii & Smith, however,
% is by far the most commonly used model, and therefore is used here. 

    % Conductivity of alumina, A2O3, W/m.K
    % Calculated from Morrell, 1987; VTT, 1996. 
    cond_Al = 5.5 + 34.5 .* exp(-0.0033 .* (T - 273));  
    
    % Conductivity of nickel, W/m.K, estimated from Powell, 1965
    cond_Ni = 65; 
    
    % W/m.K --> J/m.s.k to kJ/m.s.K
    cond_SMIX = (0.15.*cond_Ni + (1-0.15).*cond_Al)./1000; 
    
    % Based on Soomro & Hughes, 1979. 
    cond_s = cond_g.*(cond_SMIX./cond_g).^(1-eps_p);

    % Effective thermal conductivity is calculated for each face. First,
    % the "static" contribution is calculated, and then the "dynamic"
    % contribution (accounting for the influence of gas convection) is
    % calculated second, based on Reynolds and Prandtl numbers. 

    pe = 0.8; % Emissivity of alumina, A2O3, estimated (Morrell, 1987)
    
    % Temperature in radiative contributions defined in Kelvins
    arv = (0.227.*10.^-3)./(1+(eps./(2.*(1-eps))).*((1-pe)./pe)).*(T./100).^3;
    ars = (0.227.*10.^-3).*(pe./(2-pe)).*(T./100).^3;
    
    ksg1 = cond_s./cond_g1; ksg2 = cond_s./cond_g2;
    
    n1 = 1.42; n2 = 4 * sqrt(3); %sin2(th) = 1/n; cos(th) = sqrt(1-1/n) as per Kunii & Smith, 1960
    
    phi1a = (0.5).*(((((ksg1-1)./ksg1)).^2*(1./n1))./(log(ksg1-(ksg1-1).*(sqrt(1-1./n1)))-((ksg1-1)./ksg1)*(1-sqrt(1-1./n1))))-(2./3).*(1./ksg1);
    phi1b = (0.5).*(((((ksg1-1)./ksg1)).^2*(1./n2))./(log(ksg1-(ksg1-1).*(sqrt(1-1./n2)))-((ksg1-1)./ksg1)*(1-sqrt(1-1./n2))))-(2./3).*(1./ksg1);
    phi2a = (0.5).*(((((ksg2-1)./ksg2)).^2*(1./n1))./(log(ksg2-(ksg2-1).*(sqrt(1-1./n1)))-((ksg2-1)./ksg2)*(1-sqrt(1-1./n1))))-(2./3).*(1./ksg2);
    phi2b = (0.5).*(((((ksg2-1)./ksg2)).^2*(1./n2))./(log(ksg2-(ksg2-1).*(sqrt(1-1./n2)))-((ksg2-1)./ksg2)*(1-sqrt(1-1./n2))))-(2./3).*(1./ksg2);
    
    th1_sf = phi1b+(phi1a-phi1b).*(eps-0.260)./0.216;
    th2_sf = phi2b+(phi2a-phi2b).*(eps-0.260)./0.216;
    
    % Stagnant effective thermal conductivities are computed. 
    cond_e0_1 = cond_g1 .* (eps.*(1 + 0.9.*(arv.*d_p)./cond_g1) + ((0.9.*(1-eps))./((1./((1./th1_sf)+((d_p.*ars)./cond_g1))+(2/3).*(cond_g1./cond_s)))));
    cond_e0_2 = cond_g2 .* (eps.*(1 + 0.9.*(arv.*d_p)./cond_g2) + ((0.9.*(1-eps))./((1./((1./th2_sf)+((d_p.*ars)./cond_g2))+(2/3).*(cond_g2./cond_s)))));

    % Stagnant conductivity at the cell center is taken as a linear
    % interpolation between the faces. 
    cond_e0 = (cond_e0_1 + cond_e0_2) ./2;
    
    % Effective axial thermal conductivity is calculated. 
    cond_ea1 = cond_g1 .* ((cond_e0_1./cond_g1) + 0.75.*(Pr1 .* Re1));
    cond_ea2 = cond_g2 .* ((cond_e0_2./cond_g2) + 0.75.*(Pr2 .* Re2));
    
    % Next, the overall heat transfer coefficient is calculated, and the
    % rate of heat transfer into the tube from its walls is calculated as a
    % source term. Dimensionless parameters for the cell are calculated,
    % and passed to the U_Calc subroutine. Finally, the heat transferred
    % into the cell is calculated as Qhxg. 
    
    % Effective radial thermal conductivity is calculated.
    % Follows from Wakao & Kakguei (1982). 
    cond_er = cond_e0 + 0.10 .* cond_g .* Re .* Pr; 

    % Calculation for reactor side wall convective heat transfer 
    % coefficient follows from Dixon (2012). 
    Nu_w0 = (1.3+5.*(d_p/d_t)) * (cond_e0./cond_g);
    Nu_ww = 0.3.* Re .^ 0.75 .* Pr.^ (1/3); 
    Nu_m = 0.054 .* Pr .* Re ; 
    Nu_w = Nu_w0 + 1./(1./Nu_ww + 1./Nu_m); 
    a_w = Nu_w .* cond_g ./ d_p; 

    % De Wasch & Froment, 1972 - Alternative model referenced in F&B. 
%     a_w0 = 10.21 ./ (d_t .^(4/3)).*cond_e0;
%     a_w = a_w0 + 0.033 .* cond_g ./d_p .* Re .* Pr;
%     cond_er = cond_e0 + 0.14 .* cond_g .* Re .* Pr;

    % Effective reactor side wall convective heat transfer coefficient. 
    % Follows from Froment, 1962, 1967. 
    a_i  = (8 .* cond_er .* a_w)./(8 .* cond_er + a_w .* d_t);
    
    cond_t = (0.0161.*T_surr + 12.557)./1000;   % kJ/m.s.K, IN-519 Alloy, from INCO (1976)
                                                % Correlated from reference data. 
                                                % Estimated based on surface temperature. 
    
    U = (1./a_i + 0.5.*d_t./cond_t.*log(d_to/d_t)).^-1; % Heat Transfer Coefficient
                                                        % Based on Xu & Froment (1989b) 

    % Total amount of heat transferred into the reactor is calculated. 
    Qhxg = (4.*U./d_t).*(T_surr-T); 

% Mass/Heat Transfer Coefficient Calculations.
    
    % Mass transfer area per unit volume; calculated as particle surface
    % area per unit reactor volume, per Geankoplis (2003) and Wakao & Smith
    % (1978). In units of m2/m3. 
    av = 6 .* (1-eps) ./ d_p;

    % Thin film heat transfer coefficient is calculated. 
    % Correlation for Nusselt number follows from Wakao et al. (1979)
    Nu = 2 + 1.1.*(Pr.^(1/3)).*(Re.^0.6); h = Nu .* cond_g ./ d_p; % kJ/m^2.s.K
    
    % Diffusivities for each species are retrieved; again, cell-center
    % diffusivity taken as an interpolation between the faces. 
    D1 = rdiff(1:i,:); D2 = rdiff(2:i+1,:); D = (D1(:,:) + D2(:,:))./2;
    
    % Schmidt numbers are calculated. 
    Sc_CH4 = mu./rho./D(:,1); Sc_CO2 = mu./rho./D(:,2); Sc_H2O = mu./rho./D(:,3); 
    Sc_CO = mu./rho./D(:,4); Sc_H2 = mu./rho./D(:,5); 
    Sc_N2 = mu./rho./D(:,6); Sc_O2 = mu./rho./D(:,7); Sc_H2S = mu./rho./D(:,8);
    
    % Thin film mass transfer coefficient is calculated. 
    % Correlation for Sherwood number follows from Wakao & Funazkri (1978)
    Sh_CH4 = 2 + 1.1.*(Sc_CH4.^(1/3)).*(Re.^0.6); km_CH4 = Sh_CH4 .* D(:,1) ./ d_p;
    Sh_CO2 = 2 + 1.1.*(Sc_CO2.^(1/3)).*(Re.^0.6); km_CO2 = Sh_CO2 .* D(:,2) ./ d_p;
    Sh_H2O = 2 + 1.1.*(Sc_H2O.^(1/3)).*(Re.^0.6); km_H2O = Sh_H2O .* D(:,3) ./ d_p;
    Sh_CO = 2 + 1.1.*(Sc_CO.^(1/3)).*(Re.^0.6); km_CO = Sh_CO .* D(:,4) ./ d_p;
    Sh_H2 = 2 + 1.1.*(Sc_H2.^(1/3)).*(Re.^0.6); km_H2 = Sh_H2 .* D(:,5) ./ d_p;
    Sh_N2 = 2 + 1.1.*(Sc_N2.^(1/3)).*(Re.^0.6); km_N2 = Sh_N2 .* D(:,6) ./ d_p;
    Sh_O2 = 2 + 1.1.*(Sc_O2.^(1/3)).*(Re.^0.6); km_O2 = Sh_O2 .* D(:,7) ./ d_p;
    Sh_H2S = 2 + 1.1.*(Sc_H2S.^(1/3)).*(Re.^0.6); km_H2S = Sh_H2S .* D(:,8) ./ d_p;

    % Thin film heat transfer flux calculated. 
    Qfilm = h .* av .* (Ts - T); % kW_th

% Calculation of Peclet numbers and "correction" coefficients. See thesis,
% Tutorial C, for details. Briefly, calculation is improved by inserting a
% "correction" coefficient adjusting mathematical diffusion based on the
% relationship between convective and diffusive terms. This coefficient is
% derived from a "sort-of" weak form solution to a steady-state
% convection-diffusion problem, which helps improve numerical accuracy as
% the simulation proceeds. This technique follows from Patankar (1980). 

    % Peclet number and corresponding exponential correction factor is
    % calculated for each face of the cell. 
    Pec1 = (rho1 .* Cp1 .* uz1)./(cond_ea1./dz); Pec2 = (rho2 .* Cp2 .* uz2)./(cond_ea2./dz);
    Corr1 = Pec1 ./ (exp(Pec1)-1); Corr2 = Pec2 ./ (exp(Pec2)-1);
    
    % Same calculation, but modified for the inlet face of the first cell.
    Pec1(1,1) = (rho1(1,1) .* Cp1(1,1) .* uz1(1,1))./(cond_ea1(1,1)./(dz/2)); 
    Corr1(1,1) = Pec1(1,1) ./ (exp(Pec1(1,1))-1);
    
% Construction of the matrices containing all of the discretized equations
% to be solved using the finite volume method. Details regarding the
% discretization of the continuity equations is given in Tutorial D in the
% thesis. Programmatically, the matrix is assembled using vector matrices;
% each variable shown below (as well as the variables indicated above thus
% far) contain ALL values for each cell center (or face center) within the
% domain for a given time step "k-1". The coefficient values are calculated
% for the left cell, central cell, and right cell for each discretized cell
% in the domain, first as single-column vectors. They are then diagonalized
% into the appropriate N x N matrices (N representing the number of cells
% in the domain) and added together to construct the overall matrix. 

    % "Left" cell coefficients calculated and diagonalized. 
    HeatLHS_LFace = -(rho1.*Cp1.*uz1)-cond_ea1./dz.*Corr1;
    HeatLHS_LFace2 = cat(1,zeros(1,i),cat(2,diag(HeatLHS_LFace(2:i)),zeros(i-1,1)));

    % "Center" cell coefficients calculated and diagonalized. 
    HeatLHS_Cell = diag((rhoCp).*(dz./dt)+rho2.*Cp2.*uz2+cond_ea1./dz.*Corr1+cond_ea2./dz.*Corr2);
    
    % "Right" cell coefficients calculated and diagonalized. 
    HeatLHS_RFace = -cond_ea2./dz.*Corr2;   
    HeatLHS_RFace2 = cat(2,zeros(i,1),cat(1,diag(HeatLHS_RFace(1:i-1)),zeros(1,i-1)));

    % Overall matrix is constructed. 
    HeatLHS_Temp = HeatLHS_LFace2 + HeatLHS_Cell + HeatLHS_RFace2;

    % Source term and accumulation term matrices are constructed. This will
    % just be a N x 1 matrix. 
    HeatRHS = (rhoCp).*(dz./dt).*T + Qhxg.*dz + Qfilm.*dz;
    
    % Inlet boundary conditions are set for the energy continuity matrix, 
    % overwriting what is in the constructed matrices. 
    HeatLHS_Temp(1,1)= (rhoCp(1,1))*(dz/dt)+rho2(1,1)*Cp2(1,1)*uz2(1,1)+cond_ea1(1,1)/(dz/2).*Corr1(1,1)+cond_ea2(1,1)/dz.*Corr2(1,1);
    HeatLHS_Temp(1,2)= -cond_ea2(1,1)/dz.*Corr2(1,1);
    HeatRHS(1,1) = (rhoCp(1,1))*(dz/dt)*T(1,1)+Qhxg(1,1).*dz+Qfilm(1,1).*dz-(-(rho1(1,1)*Cp1(1,1)*uz1(1,1))-cond_ea1(1,1)/(dz/2).*Corr1(1,1))*T_in;

    % Outlet boundary conditions are set for the energy continuity matrix, 
    % overwriting what is in the constructed matrices.     
    HeatLHS_Temp(i,i-1)= -(rho1(i,1)*Cp1(i,1)*uz1(i,1))-cond_ea1(i,1)/dz.*Corr1(i,1);
    HeatLHS_Temp(i,i)= (rhoCp(i,1))*(dz/dt)+rho2(i,1)*Cp2(i,1)*uz2(i,1)+cond_ea1(i,1)/dz.*Corr1(i,1);
    HeatRHS(i,1) = (rhoCp(i,1))*(dz/dt)*T(i,1)+Qhxg(i,1).*dz+Qfilm(i,1).*dz;

    % MATLAB then solves the matrices using its internal solver. This is
    % very often faster (and simpler) than constructing a manual matrix
    % solver. Once solved, solution data is saved for current timestep "k". 
    rMatrixSoln = sparse(HeatLHS_Temp\HeatRHS); 
    RxrTemp = rMatrixSoln(1:cellnum,1); rMatrixTemp(:,k) = RxrTemp;

    rMeshTemp(1,k) = T_in;
    rMeshTemp(2:i,k) = (rMatrixTemp(1:i-1,k)+rMatrixTemp(2:i,k))/2;
    rMeshTemp(i+1,k) = rMatrixTemp(i,k);

% In similar fashion, species mass fractions are computed for timestep "k"
% using the [CalcSpec] subroutine. A dedicated subroutine is used just to
% maintain organization / cleanliness of the code. 

    CalcSpec

% As part of the error trapping within [CalcSpec], "ForceReturn" is a flag
% to [CalcReactor] that an error has occurred and the program needs to
% immediately terminate. 
    if ForceReturn == 1
    return
    end

% Changes in reactor gas-phase pressure and velocity are computed next. The
% calculation is iterative, based on maintaining continuity of mass within
% the reactor. 

% To compute values at the cell faces, linear interpolation is used.
% Given that this is a uniform mesh, face values are just taken as an
% average between the values of the two adjacent cells. Values at the faces
% will be used to calculate density and viscosity while solving for the
% reactor pressure and velocity profile. 

    % Face values are determined. 
    i = cellnum;
    TempFace = cat(1,T_in,(rMatrixTemp(1:i-1,k)+rMatrixTemp(2:i,k))/2,rMatrixTemp(i,k));
    xCH4Face = cat(1,xCH4_in,(rMatrixFrac_CH4(1:i-1,k)+rMatrixFrac_CH4(2:i,k))/2,rMatrixFrac_CH4(i,k));
    xCO2Face = cat(1,xCO2_in,(rMatrixFrac_CO2(1:i-1,k)+rMatrixFrac_CO2(2:i,k))/2,rMatrixFrac_CO2(i,k));
    xH2OFace = cat(1,xH2O_in,(rMatrixFrac_H2O(1:i-1,k)+rMatrixFrac_H2O(2:i,k))/2,rMatrixFrac_H2O(i,k));
    xCOFace = cat(1,xCO_in,(rMatrixFrac_CO(1:i-1,k)+rMatrixFrac_CO(2:i,k))/2,rMatrixFrac_CO(i,k));
    xH2Face = cat(1,xH2_in,(rMatrixFrac_H2(1:i-1,k)+rMatrixFrac_H2(2:i,k))/2,rMatrixFrac_H2(i,k));
    xN2Face = cat(1,xN2_in,(rMatrixFrac_N2(1:i-1,k)+rMatrixFrac_N2(2:i,k))/2,rMatrixFrac_N2(i,k));
    xO2Face = cat(1,xO2_in,(rMatrixFrac_O2(1:i-1,k)+rMatrixFrac_O2(2:i,k))/2,rMatrixFrac_O2(i,k));
    xH2SFace = cat(1,xH2S_in,(rMatrixFrac_H2S(1:i-1,k)+rMatrixFrac_H2S(2:i,k))/2,rMatrixFrac_H2S(i,k));
    
    rMeshTemp(:,k) = TempFace;
    rMeshFrac_CH4(:,k) = xCH4Face;
    rMeshFrac_CO2(:,k) = xCO2Face;
    rMeshFrac_H2O(:,k) = xH2OFace;
    rMeshFrac_CO(:,k) = xCOFace;
    rMeshFrac_H2(:,k) = xH2Face;
    rMeshFrac_N2(:,k) = xN2Face;
    rMeshFrac_O2(:,k) = xO2Face;
    rMeshFrac_H2S(:,k) = xH2SFace;
    
    % Mole fractions are solved from the mass fractions at the cell faces. 
    MCH4 = rMeshFrac_CH4(:,k) ./ mCH4; MCO2 = rMeshFrac_CO2(:,k) ./ mCO2;
    MH2O = rMeshFrac_H2O(:,k) ./ mH2O; MCO = rMeshFrac_CO(:,k) ./ mCO;
    MH2 = rMeshFrac_H2(:,k) ./ mH2; MN2 = rMeshFrac_N2(:,k) ./ mN2;
    MO2 = rMeshFrac_O2(:,k) ./ mO2; MH2S = rMeshFrac_O2(:,k) ./ mH2S; 
    MTot = MCH4 + MCO2 + MH2O + MCO + MH2 + MN2 + MO2 + MH2S;
    
    rMeshFracM_CH4(:,k) = MCH4./MTot;
    rMeshFracM_CO2(:,k) = MCO2./MTot;
    rMeshFracM_H2O(:,k) = MH2O./MTot;
    rMeshFracM_CO(:,k) = MCO./MTot;
    rMeshFracM_H2(:,k) = MH2./MTot; 
    rMeshFracM_N2(:,k) = MN2./MTot; 
    rMeshFracM_O2(:,k) = MO2./MTot; 
    rMeshFracM_H2S(:,k) = MH2S./MTot; 
    rMeshFracM_ALL(:,k) = rMeshFracM_CH4(:,k) + rMeshFracM_CO2(:,k) + ...
        rMeshFracM_H2O(:,k) + rMeshFracM_CO(:,k) + rMeshFracM_H2(:,k) + ...
        rMeshFracM_N2(:,k) + rMeshFracM_O2(:,k) + rMeshFracM_H2S(:,k);

    % Error tracking is set up; code is nested within a "while" loop to
    % continue computing until an acceptable error threshold has been
    % achieved for consistency between pressure and velocity. 

    err = 1; 
    while err > 10^-6

        % Velocities are retrieved. 
        uz1 = rMeshVel(1:i,k-1); uz2 = rMeshVel(2:i+1,k-1); uz = rMatrixVel(:,k-1);

        % Pressure drop is calculated using the Ergun equation. 
        dL(1,1) = (dz/2); dL(2:i,1) = dz; dL(i+1,1) = (dz/2);
        dPress = (((1.75 .* rho.* (1-eps) .* uz) ./ (d_p .* eps .^ 3)) + ...
            ((150 .* mu .* (1-eps) .^ 2) ./ (d_p .* eps .^ 3))) .* uz;

        % Reactor pressure profile is updated. 
        P(1,1) = P_in - dPress(1,1) * dL(1,1);
        for i = 2:cellnum
            P(i,1) = P(i-1,1) - dPress(i,1) * dL(i,1);
        end
        P_out = P(i,1) - dPress(i,1) * (dL(i,1) / 2); 

        % Changes in pressure are also recorded. 
        dP(1,1) = P_in - P(1,1);
        dP(2:i,1) = P(1:i-1,1) - P(2:i,1);
        dP(i+1,1) = P(i,1) - P_out;

        % Pressures located at the cell faces are determined. 
        Pf = P_in;
        Pf(2:i,1) = (P(1:i-1,1)+P(2:i,1))/2;
        Pf(i+1,1) = P_out;

        % Pressure will influence gas-phase density, which will in part
        % influence gas velocity. Given this is being calculated at time
        % increment "k", an updated temperature and species composition profile
        % must be used to ensure consistency. 
        Tf = rMeshTemp(:,k); xfMCH4 = rMeshFracM_CH4(:,k); 
        xfMCO2 = rMeshFracM_CO2(:,k); xfMH2O = rMeshFracM_H2O(:,k);
        xfMCO = rMeshFracM_CO(:,k); xfMH2 = rMeshFracM_H2(:,k); 
        xfMN2 = rMeshFracM_N2(:,k); xfMO2 = rMeshFracM_O2(:,k); 
        xfMH2S = rMeshFracM_H2S(:,k); 

        T = rMatrixTemp(:,k); xMCH4 = rMatrixFracM_CH4(:,k); 
        xMCO2 = rMatrixFracM_CO2(:,k); xMH2O = rMatrixFracM_H2O(:,k);
        xMCO = rMatrixFracM_CO(:,k); xMH2 = rMatrixFracM_H2(:,k); 
        xMN2 = rMatrixFracM_N2(:,k); xMO2 = rMatrixFracM_O2(:,k); 
        xMH2S = rMatrixFracM_H2S(:,k); 

        % Gas-phase density is updated for both cell faces and centers.  
        i = facenum;
        rMeshDens(:,k) = Mix_Dens(Pf, Tf, xfMCH4, xfMCO2, xfMH2O, xfMCO, xfMH2, xfMN2, xfMO2, xfMH2S, i);
        rMesh_mu(:,k) = Mix_Visc(Pf, Tf, xfMCH4, xfMCO2, xfMH2O, xfMCO, xfMH2, xfMN2, xfMO2, xfMH2S, i);

        i = cellnum; 
        rMatrixDens(:,k) = Mix_Dens(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, xMH2S, i);
        rMatrix_Mu(:,k) = Mix_Visc(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, xMH2S, i);

        rho1 = rMeshDens(1:i,k); rho2 = rMeshDens(2:i+1,k); rho = rMatrixDens(:,k);
        mu1 = rMesh_mu(1:i,k); mu2 = rMesh_mu(2:i+1,k); mu = rMatrix_Mu(:,k);


        % Conservation of mass and conservation of momentum are solved
        % simultaneously and - importantly - instantaneously; it is assumed
        % that no momentum accumulates within the gas-phase of the reactor.
        % Essentially, the simplifications imposed on the continuity
        % equations reduce them to explicit algebraic expressions for each
        % discretized part of the computational domain. Details are
        % provided in Tutorial D of the thesis. 

        % Continuity of mass is constructed first. Note that velocity is
        % taken as the variable being solved for. 
        ConsLHS_LFace = -(rho1);
        ConsLHS_LFace2 = full(cat(1,zeros(1,i),cat(2,diag(ConsLHS_LFace(2:i)),zeros(i-1,1))));
        ConsLHS_RFace = (rho2);  
        ConsLHS_RFace2 = full(cat(1,zeros(1,i),cat(2,zeros(i-1,1),diag(ConsLHS_RFace(2:i)))));
        ConsLHS = ConsLHS_LFace2 + ConsLHS_RFace2; 
        ConsRHS = sparse(zeros(i,1)); 

        % Boundary condition at the inlet is set; mass flux is defined by
        % the inlet velocity and gas-phase density. 
        ConsLHS(1,1) = rho(1,1); ConsRHS(1,1) = rho1(1,1) * uz_i;

        % Continuity of momentum is set as well; Ergun equation is used,
        % noting that it is rearranged to solve for velocity. An important
        % consideration is the quadradic nature of the Ergun equation; the
        % velocity must be used to calculate the coefficient value, and is
        % not completely separated out in isolation. Analytically, porous
        % media momentum correlations consider a magnitude of velocity,
        % which is itself scalar (see Kaviany, 1991; note however that this
        % association is heuristic). This implies that it may be considered
        % as a coefficient value. 

        % In any case, the algorithm is structured such that only a small
        % error exists between the axial velocity and the magnitude of the
        % axial velocity. The approach shown here is meant to maintain
        % consistency of treatment of reactor variables, though there may
        % be other means of solving algebraically. 

        % Momentum matrix is set up. 
        MomLHS_LFace = ones(i,1)*-1;
        MomLHS_LFace2 = cat(1,zeros(1,i),cat(2,diag(MomLHS_LFace(2:i)),zeros(i-1,1)));
        MomLHS_RFace = ones(i,1)*1;  
        MomLHS_RFace2 = cat(1,zeros(1,i),cat(2,zeros(i-1,1),diag(MomLHS_RFace(2:i))));
        MomLHS = MomLHS_LFace2 + MomLHS_RFace2;

        K1 = 1 ./ (((1.75 .* rho1.* (1-eps) .* uz1) ./ (d_p .* eps .^ 3)) + ...
            ((150 .* mu1 .* (1-eps) .^ 2) ./ ((d_p.^2) .* eps.^3)));
        K2 = 1 ./ (((1.75 .* rho2.* (1-eps) .* uz2) ./ (d_p .* eps .^ 3)) + ...
            ((150 .* mu2 .* (1-eps) .^ 2) ./ ((d_p.^2) .* eps.^3)));

        % Source term essentially "solves" for velocity using the Ergun
        % equation and the cell's pressure drop. 
        MomRHS = dP(2:i+1,1) ./ dL(2:i+1,1) .* K2 - dP(1:i,1) ./ dL(1:i,1) .* K1;

        MomLHS(1,1) = 1; 
        MomRHS(1,1) = dP(2,1) ./ dL(2,1) .* K2(1,1) - dP(1,1) ./ dL(1,1) .* K1(1,1) + uz_i;

        % Mass and momentum continuity equations are coupled together and
        % solved simultaneously. Velocities are determined at the cell
        % centers and faces. 
        VelLHS = sparse(cat(1,ConsLHS,MomLHS)); VelRHS = cat(1,ConsRHS,MomRHS);
        VelCell = VelLHS\VelRHS; 
        VelFace = cat(1,uz_i,(VelCell(1:i-1) + VelCell(2:i)) / 2,VelCell(i));
        
        % The error between current and preceding velocity is computed,
        % then the current velocity is saved in memory. 
        err = sum(abs(1-VelCell./rMatrixVel(:,k)));        
        rMatrixVel(:,k) = VelCell;
        rMeshVel(:,k) = VelFace;    

        % The loop repeats until the calculation of velocity is consistent.

    end
    
    % Updated pressure is saved as well. 
    rMatrixPress(:,k) = P;
    rMeshPress(1,k) = P_in;
    rMeshPress(2:i,k) = (rMatrixPress(1:i-1,k)+rMatrixPress(2:i,k))/2;
    rMeshPress(i+1,k) = rMatrixPress(i,k); %carries over cell value. 

% Having calculated the pressure, temperature, species, and velocities
% for a given time step, the properties that will exist at the next
% time step are evaluated using the [PropCalc] subroutine. 

    PropCalc

% At this point, all calculations for a given iteration through time have
% been completed. As the simulation proceeds, prompts are given to the user
% to allow monitoring of progress. Prompts are given at every 1/4th
% completion of a "run". 

    if k == timestep/4*1

        % Calculating methane conversion. 
        FCH4 = xMCH4(facenum,1) .* rhoM(cellnum,1) .* Acs .* uz(cellnum,1); 
        CH4Conv = num2str(1 - FCH4/FCH4_in); CH4Conv1 = (1 - FCH4/FCH4_in);
        CH4Conc = num2str(xCH4(cellnum,1));

        % Retrieving catalyst sulfur coverage. 
        if convmod == 1
            CovH2S = num2str(pCoverage(cellnum,1,k));
        else
            CovH2S = num2str(sCoverage(cellnum,k));
        end        

        % Retrieving other variables (may be adjusted as desired). 
        RxnEff = num2str(rMatrixEff(cellnum,k,1));
        RxrTemp = num2str(rMatrixTemp(cellnum,k));
        RxrsTemp = num2str(sMatrixTemp(cellnum,k));
        RxrpTemp = num2str(pMatrixTemp(cellnum,1,k));
        RxrPress = num2str(rMatrixPress(cellnum,k));

        % Current time of simulation is calculated for display. 
        stopwatch = num2str((run-1) * t + t * (1/4),'%.2f');

        % Prompt is displayed in the MATLAB consol. 
        format long
        Prompt = ['Time: ',stopwatch,' s   Conv: ',CH4Conv,'  Covg: ',CovH2S,'  EFF: ',RxnEff,'  SurfTemp: ',RxrsTemp,'  PelTemp: ',RxrpTemp,'  ExitTemp: ',RxrTemp,'  ExitPress: ',RxrPress];
        disp(Prompt);

    elseif k == timestep/4*2

        % Calculating methane conversion. 
        FCH4 = xMCH4(facenum,1) .* rhoM(cellnum,1) .* Acs .* uz(cellnum,1); 
        CH4Conv = num2str(1 - FCH4/FCH4_in); CH4Conv2 = (1 - FCH4/FCH4_in);
        CH4Conc = num2str(xCH4(cellnum,1));

        % Retrieving catalyst sulfur coverage. 
        if convmod == 1
            CovH2S = num2str(pCoverage(cellnum,1,k));
        else
            CovH2S = num2str(sCoverage(cellnum,k));
        end        

        % Retrieving other variables (may be adjusted as desired). 
        RxnEff = num2str(rMatrixEff(cellnum,k,1));
        RxrTemp = num2str(rMatrixTemp(cellnum,k));
        RxrsTemp = num2str(sMatrixTemp(cellnum,k));
        RxrpTemp = num2str(pMatrixTemp(cellnum,1,k));
        RxrPress = num2str(rMatrixPress(cellnum,k));

        % Current time of simulation is calculated for display. 
        stopwatch = num2str((run-1) * t + t * (2/4),'%.2f');

        % Prompt is displayed in the MATLAB consol. 
        format long
        Prompt = ['Time: ',stopwatch,' s   Conv: ',CH4Conv,'  Covg: ',CovH2S,'  EFF: ',RxnEff,'  SurfTemp: ',RxrsTemp,'  PelTemp: ',RxrpTemp,'  ExitTemp: ',RxrTemp,'  ExitPress: ',RxrPress];
        disp(Prompt);

    elseif k == timestep/4*3

        % Calculating methane conversion. 
        FCH4 = xMCH4(facenum,1) .* rhoM(cellnum,1) .* Acs .* uz(cellnum,1); 
        CH4Conv = num2str(1 - FCH4/FCH4_in); CH4Conv3 = (1 - FCH4/FCH4_in);
        CH4Conc = num2str(xCH4(cellnum,1));

        % Retrieving catalyst sulfur coverage. 
        if convmod == 1
            CovH2S = num2str(pCoverage(cellnum,1,k));
        else
            CovH2S = num2str(sCoverage(cellnum,k));
        end        

        % Retrieving other variables (may be adjusted as desired). 
        RxnEff = num2str(rMatrixEff(cellnum,k,1));
        RxrTemp = num2str(rMatrixTemp(cellnum,k));
        RxrsTemp = num2str(sMatrixTemp(cellnum,k));
        RxrpTemp = num2str(pMatrixTemp(cellnum,1,k));
        RxrPress = num2str(rMatrixPress(cellnum,k));

        % Current time of simulation is calculated for display. 
        stopwatch = num2str((run-1) * t + t * (3/4),'%.2f');

        % Prompt is displayed in the MATLAB consol. 
        format long
        Prompt = ['Time: ',stopwatch,' s   Conv: ',CH4Conv,'  Covg: ',CovH2S,'  EFF: ',RxnEff,'  SurfTemp: ',RxrsTemp,'  PelTemp: ',RxrpTemp,'  ExitTemp: ',RxrTemp,'  ExitPress: ',RxrPress];
        disp(Prompt);

    elseif k == timestep

        % Calculating methane conversion. 
        FCH4 = xMCH4(facenum,1) .* rhoM(cellnum,1) .* Acs .* uz(cellnum,1); 
        CH4Conv = num2str(1 - FCH4/FCH4_in); CH4Conv4 = (1 - FCH4/FCH4_in);
        CH4Conc = num2str(xCH4(cellnum,1));

        % Retrieving catalyst sulfur coverage. 
        if convmod == 1
            CovH2S = num2str(pCoverage(cellnum,1,k));
        else
            CovH2S = num2str(sCoverage(cellnum,k));
        end        

        % Retrieving other variables (may be adjusted as desired). 
        RxnEff = num2str(rMatrixEff(cellnum,k,1));
        RxrTemp = num2str(rMatrixTemp(cellnum,k));
        RxrsTemp = num2str(sMatrixTemp(cellnum,k));
        RxrpTemp = num2str(pMatrixTemp(cellnum,1,k));
        RxrPress = num2str(rMatrixPress(cellnum,k));

        % Current time of simulation is calculated for display. 
        stopwatch = num2str((run-1) * t + t * (4/4),'%.2f');

        % Prompt is displayed in the MATLAB consol. 
        format long
        Prompt = ['Time: ',stopwatch,' s   Conv: ',CH4Conv,'  Covg: ',CovH2S,'  EFF: ',RxnEff,'  SurfTemp: ',RxrsTemp,'  PelTemp: ',RxrpTemp,'  ExitTemp: ',RxrTemp,'  ExitPress: ',RxrPress];
        disp(Prompt);

        % As required, data may be recorded at the completion of each "run"
        % to excel. This may be used for either transient simulations, or
        % to assist in debugging the simulation. When this is not required
        % (given writing data consumes time), [CalcOut] and [CalcOut_p] may
        % be commented out to prevent execution. 

        CalcOut
        CalcOut_p
        
        % Where transient simulation is desired, "tripcount" may be used to
        % trigger the "if" block below. The simulation can only trip 'on'
        % with H2S, then trip 'off', once per simulation. 

        tripcount = tripcount + 1;

        if  abs(1-CH4Conv4/CH4Conv1) < 0.001 && tripcount > timestep / 4
            if tripstep == 0
                % Inlet composition is adjusted for H2S 'on'
                H2Sppm = 25; xMH2S_in = H2Sppm/(10^6);
                xMN2_in = 0.25-xMH2S_in-xMO2_in; 
                xH2S_in = mH2S*xMH2S_in/MoltoMass_i;
                xN2_in = mN2*xMN2_in/MoltoMass_i;
                xALL_in = xCH4_in + xCO2_in + xH2O_in + xCO_in + xH2_in + xN2_in + xO2_in + xH2S_in;
                xMALL_in = xMCH4_in + xMCO2_in + xMH2O_in + xMCO_in + xMH2_in + xMN2_in + xMO2_in + xMH2S_in;
                tripstep = 1; tripcount = 0;

            elseif tripstep == 1
                % Inlet composition is adjusted for H2S 'off'
                H2Sppm = 0; xMH2S_in = H2Sppm/(10^6);
                xMN2_in = 0.25-xMH2S_in-xMO2_in; 
                xH2S_in = mH2S*xMH2S_in/MoltoMass_i;
                xN2_in = mN2*xMN2_in/MoltoMass_i;
                xALL_in = xCH4_in + xCO2_in + xH2O_in + xCO_in + xH2_in + xN2_in + xO2_in + xH2S_in;
                xMALL_in = xMCH4_in + xMCO2_in + xMH2O_in + xMCO_in + xMH2_in + xMN2_in + xMO2_in + xMH2S_in;
                tripstep = 2; tripcount = 0;

            else 
                % The block is also used to indicate when satisfactory
                % convergence has been achieved (i.e., the reactor
                % simulation is at steady-state). In this case, the
                % simulation is set up to terminate. 
                run = Truns;
            end
        end

        % When the simulation has completed, it may need to write MATLAB
        % data to an excel file for later analysis. This may be commented
        % out of the code when not required. 
        if run == Truns
            CalcOut % COMMENT OUT IF DIAGNOSTICS ARE REQUIRED.
            CalcOut_p % COMMENT OUT IF DIAGNOSTICS ARE REQUIRED.
        end

        % At the end of each "run", the simulation executes [CalcLoop] to
        % reset initial conditions to the values found in the current
        % timestep, and clearing all other values. This allows the program
        % to operate without consuming too much memory. 
        CalcLoop
    end

end
    if run == Truns
       break % Simulation breaks the loop if it has achieved convergence. 
    end
end % For run = 1:Truns
end % For TempParam
end % For H2SParam

toc % Turns off the MATLAB timer, and displays the simulation run time. 

load train  % Provides a "toot toot!" to signal when the simulation is complete. 
sound(y,Fs) % A train sound is used, because this is for engineering :)
