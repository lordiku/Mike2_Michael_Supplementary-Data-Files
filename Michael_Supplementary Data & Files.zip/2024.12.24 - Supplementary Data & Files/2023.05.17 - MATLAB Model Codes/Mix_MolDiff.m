function TotalDiff = Mix_MolDiff(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, xMH2S, i, rp)

% Binary diffusion coefficients are calculated based on the semi-empirical
% correlation presented by Fuller et al., which makes use of atomic
% volumes. The multicomponent gas diffusivity is then computed from an 
% adaptation of the Stefan-Maxwell equation (see Fairbanks & Wilke, 1950). 

% Useful references are Geankoplis, and Bird et al.

    % Working matrix is initialized. 
    PureDiff = zeros(i,8,13);
    R = 8.3144598; % m^3*Pa/K/mol, universal gas constant
    P = P ./ 101325; % Pa to ATM. 
    
    % Species mole fractions stored. 
    Frac = [xMCH4 xMCO2 xMH2O xMCO xMH2 xMN2 xMO2 xMH2S]; 
        
    % Diffusion coefficients are used in the correlation; these are based
    % on the correlation of Fuller, Schettler, & Giddings (1966); these are
    % precalculations for each species pair based on molar masses and
    % atomic diffusion volumes. This helps reduce the number of
    % computations required. 
    DiffCoeff = [   0       	8.3877E-10	1.2531E-09	1.0114E-09	3.2139E-09	1.0289E-09	1.0295E-09	9.4563E-10
                    8.3877E-10	0       	9.8445E-10	7.5447E-10	2.9780E-09	7.6730E-10	7.5493E-10	6.8914E-10
                    1.2531E-09	9.8445E-10	0       	1.2093E-09	4.1031E-09	1.2327E-09	1.2345E-09	1.1234E-09
                    1.0114E-09	7.5447E-10	1.2093E-09	0       	3.4685E-09	9.5856E-10	9.5154E-10	8.6762E-10
                    3.2139E-09	2.9780E-09	4.1031E-09	3.4685E-09	0       	3.5420E-09	3.6304E-09	3.3089E-09
                    1.0289E-09	7.6730E-10	1.2327E-09	9.5856E-10	3.5420E-09	0       	9.6915E-10	8.8304E-10
                    1.0295E-09	7.5493E-10	1.2345E-09	9.5154E-10	3.6304E-09	9.6915E-10	0       	8.7336E-10
                    9.4563E-10	6.8914E-10	1.1234E-09	8.6762E-10	3.3089E-09	8.8304E-10	8.7336E-10	0
                ];
    
    % Methane diffusivity. 
    % Molecular diffusivities are calculated for the species. Specifically,
    % diffusivities for each species-species pairing are calculated.
    Dbin = (T.^(1.75)./P) * DiffCoeff(1,:); Dden = (Frac./(Dbin)); 
    
    % Error traps are set to catch where coefficients are zero, i.e., where
    % they're representing essentially species self-diffusion, which is not
    % considered as part of the correlation. 
    Dden(Dden>1E12) = 0; Dden(isnan(Dden)) = 0; 
    
    % Overall multicomponent diffusivity is calculated for the species. 
    Dsum = sum(Dden,2); DMix1 = (1 - Frac(:,1))./(Dsum);
    
    % Carbon dioxide diffusivity. 
    Dbin = (T.^(1.75)./P) * DiffCoeff(2,:);
    Dden = (Frac./(Dbin)); Dden(Dden>1E12) = 0; Dden(isnan(Dden)) = 0; Dsum = sum(Dden,2);
    DMix2 = (1 - Frac(:,2))./(Dsum);

    % Steam diffusivity. 
    Dbin = (T.^(1.75)./P) * DiffCoeff(3,:);
    Dden = (Frac./(Dbin)); Dden(Dden>1E12) = 0; Dden(isnan(Dden)) = 0; Dsum = sum(Dden,2);
    DMix3 = (1 - Frac(:,3))./(Dsum);
        
    % Carbon monoxide diffusivity. 
    Dbin = (T.^(1.75)./P) * DiffCoeff(4,:);
    Dden = (Frac./(Dbin)); Dden(Dden>1E12) = 0; Dden(isnan(Dden)) = 0; Dsum = sum(Dden,2);
    DMix4 = (1 - Frac(:,4))./(Dsum);
        
    % Hydrogen diffusivity. 
    Dbin = (T.^(1.75)./P) * DiffCoeff(5,:);
    Dden = (Frac./(Dbin)); Dden(Dden>1E12) = 0; Dden(isnan(Dden)) = 0; Dsum = sum(Dden,2);
    DMix5 = (1 - Frac(:,5))./(Dsum);
        
    % Nitrogen diffusivity. 
    Dbin = (T.^(1.75)./P) * DiffCoeff(6,:); 
    Dden = (Frac./(Dbin)); Dden(Dden>1E12) = 0; Dden(isnan(Dden)) = 0; Dsum = sum(Dden,2);
    DMix6 = (1 - Frac(:,6))./(Dsum);
       
    % Oxygen diffusivity. 
    Dbin = (T.^(1.75)./P) * DiffCoeff(7,:);
    Dden = (Frac./(Dbin)); Dden(Dden>1E12) = 0; Dden(isnan(Dden)) = 0; Dsum = sum(Dden,2);
    DMix7 = (1 - Frac(:,7))./(Dsum);
        
    % Hydrogen sulfide diffusivity. 
    Dbin = (T.^(1.75)./P) * DiffCoeff(8,:);
    Dden = (Frac./(Dbin)); Dden(Dden>1E12) = 0; Dden(isnan(Dden)) = 0; Dsum = sum(Dden,2);
    DMix8 = (1 - Frac(:,8))./(Dsum);
        
    % Returns all calculated diffusivities as a vector. 
    % Units of mol/m^2.s
    TotalDiff = cat(2,DMix1,DMix2,DMix3,DMix4,DMix5,DMix6,DMix7,DMix8);        
    
end