
P_in = 29*100000; P_out = 26.5*100000; P = P_in; 
T_in = 793; T_surr = 1048;
T = T_in; 
eff1 = 0.008; eff2 = 0.07; eff3 = 0.01;

seqCoverage = zeros(cellnum,timestep); sCoverage = zeros(cellnum,timestep);
ws_H2S = zeros(cellnum,timestep); wsat_H2S = zeros(cellnum,timestep);

peqCoverage = zeros(cellnum,partnum,timestep); pCoverage = zeros(cellnum,partnum,timestep);
wp_H2S = zeros(cellnum,partnum,timestep); pwsat_H2S = zeros(cellnum,partnum,timestep);

% Inlet conditions of the incoming gas stream - MUST BE MOLE FRACTIONS
xMCH4_in = 0.2121; xMCO2_in = 0.0081; xMH2O_in = 0.7135; 
xMCO_in = 0.0001; xMH2_in = 0.0256; xMH2S_in = H2Sppm/(10^6);
xMN2_in = 0.0407-xMH2S_in; xMO2_in = 0; 

% Inlet conditions of the incoming gas stream - MUST BE MOLE FRACTIONS
% xMCH4_in = 0.40; xMCO2_in = 0.40; xMH2O_in = 0.05; 
% xMCO_in = 0.025; xMH2_in = 0.025; xMH2S_in = H2Sppm/(10^6);
% xMN2_in = 0.1-xMH2S_in; xMO2_in = 0; 

% Initial conditions within the reactor - MUST BE MOLE FRACTIONS
xMCH4_init = 0.2121; xMCO2_init = 0.0081; xMH2O_init = 0.7135; 
xMCO_init = 0.0001; xMH2_init = 0.0256; xMH2S_init = 0; xMCoke_init = 0;
xMN2_init = 0.0407-xMH2S_init; xMO2_init = 0;

% Initial conditions within the reactor - MUST BE MOLE FRACTIONS
% xMCH4_init = 0.40; xMCO2_init = 0.40; xMH2O_init = 0.05; 
% xMCO_init = 0.025; xMH2_init = 0.025; xMH2S_init = 0; xMCoke_init = 0;
% xMN2_init = 0.1-xMH2S_init; xMO2_init = 0;

% Calculating initial tranpsort and thermodynamic properties. 
i = 1;
mu = Mix_Visc(P, T, xMCH4_init, xMCO2_init, xMH2O_init, xMCO_init, xMH2_init, xMN2_init, xMO2_init, xMH2S_init, i);
cond = Mix_Cond(P, T, xMCH4_init, xMCO2_init, xMH2O_init, xMCO_init, xMH2_init, xMN2_init, xMO2_init, xMH2S_init, i);
Cp = Mix_Cp(P, T, xMCH4_init, xMCO2_init, xMH2O_init, xMCO_init, xMH2_init, xMN2_init, xMO2_init, xMH2S_init, i);
rho = Mix_Dens(P, T, xMCH4_init, xMCO2_init, xMH2O_init, xMCO_init, xMH2_init, xMN2_init, xMO2_init, xMH2S_init, i);
diffCalc = Mix_MolDiff(P, T, xMCH4_init, xMCO2_init, xMH2O_init, xMCO_init, xMH2_init, xMN2_init, xMO2_init, xMH2S_init, i, rp);

i = cellnum;

% Getting mean mass density (g/mol) for gas mixture. 
mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
mN2 = 28.02; mO2 = 32.00; mH2S = 34.01; mCoke = 14.01; 
MoltoMass_i = mCH4*xMCH4_init + mCO*xMCO_init + mCO2*xMCO2_init + mH2*xMH2_init + ...
    mH2O*xMH2O_init + mN2*xMN2_init + mO2*xMO2_init + mH2S*xMH2S_init;
rhoM = rho / (MoltoMass_i/1000);

% Getting the mass fractions for each species.
xCH4_init = mCH4*xMCH4_init/MoltoMass_i; xCO2_init = mCO2*xMCO2_init/MoltoMass_i;
xH2O_init = mH2O*xMH2O_init/MoltoMass_i; xCO_init = mCO*xMCO_init/MoltoMass_i;
xH2_init = mH2*xMH2_init/MoltoMass_i; xN2_init = mN2*xMN2_init/MoltoMass_i;
xO2_init = mO2*xMO2_init/MoltoMass_i; xH2S_init = mH2S*xMH2S_init/MoltoMass_i; xCoke_init = mCoke*xMCoke_init/MoltoMass_i;
xALL_init = xCH4_init + xCO2_init + xH2O_init + xCO_init + xH2_init + xN2_init + xO2_init + xH2S_init;
xMALL_init = xMCH4_init + xMCO2_init + xMH2O_init + xMCO_init + xMH2_init + xMN2_init + xMO2_init + xMH2S_init;

% Getting the mass fractions for each species.
xCH4_in = mCH4*xMCH4_in/MoltoMass_i; xCO2_in = mCO2*xMCO2_in/MoltoMass_i;
xH2O_in = mH2O*xMH2O_in/MoltoMass_i; xCO_in = mCO*xMCO_in/MoltoMass_i;
xH2_in = mH2*xMH2_in/MoltoMass_i; xN2_in = mN2*xMN2_in/MoltoMass_i;
xO2_in = mO2*xMO2_in/MoltoMass_i; xH2S_in = mH2S*xMH2S_in/MoltoMass_i;
xALL_in = xCH4_in + xCO2_in + xH2O_in + xCO_in + xH2_in + xN2_in + xO2_in + xH2S_in;
xMALL_in = xMCH4_in + xMCO2_in + xMH2O_in + xMCO_in + xMH2_in + xMN2_in + xMO2_in + xMH2S_in;

% Calculating molar flow rates. 
FCH4_in = xMCH4_in * rhoM * Acs * uz_i; FCO2_in = xMCO2_in * rhoM * Acs * uz_i; 
FH2O_in = xMH2O_in * rhoM * Acs * uz_i; FCO_in = xMCO_in * rhoM * Acs * uz_i; 
FH2_in = xMH2_in * rhoM * Acs * uz_i; FN2_in = xMN2_in * rhoM * Acs * uz_i;
FO2_in = xMO2_in * rhoM * Acs * uz_i; FH2S_in = xMH2S_in * rhoM * Acs * uz_i;

rhoM_in = rhoM; rho_in = rho;
FALL_in = FCH4_in + FCO2_in + FH2O_in + FCO_in + FH2_in + FN2_in + FO2_in + FH2S_in;

%% Setting Reactor Properties.

rMatrixTestPress = sparse(ones(cellnum,timestep)); error_P = 1;
rMatrixTestTemp = sparse(ones(cellnum,timestep)); error_T = 1;
rMeshPress = sparse(ones(facenum,timestep)) * P;
rMeshTemp = sparse(ones(facenum,timestep)) * T;
rMatrixPress = sparse(ones(cellnum,timestep)) * P;
rMatrixTemp = sparse(ones(cellnum,timestep)) * T;

rMeshFracM_CH4 = sparse(ones(facenum,timestep)) * xMCH4_init;
rMeshFracM_CO2 = sparse(ones(facenum,timestep)) * xMCO2_init;
rMeshFracM_H2O = sparse(ones(facenum,timestep)) * xMH2O_init;
rMeshFracM_CO = sparse(ones(facenum,timestep)) * xMCO_init;
rMeshFracM_H2 = sparse(ones(facenum,timestep)) * xMH2_init;
rMeshFracM_N2 = sparse(ones(facenum,timestep)) * xMN2_init;
rMeshFracM_O2 = sparse(ones(facenum,timestep)) * xMO2_init;
rMeshFracM_H2S = sparse(ones(facenum,timestep)) * xMH2S_init;
rMeshFracM_ALL = sparse(ones(facenum,timestep)) * xMALL_init;

rMeshFrac_CH4 = sparse(ones(facenum,timestep)) * xCH4_init;
rMeshFrac_CO2 = sparse(ones(facenum,timestep)) * xCO2_init;
rMeshFrac_H2O = sparse(ones(facenum,timestep)) * xH2O_init;
rMeshFrac_CO = sparse(ones(facenum,timestep)) * xCO_init;
rMeshFrac_H2 = sparse(ones(facenum,timestep)) * xH2_init;
rMeshFrac_N2 = sparse(ones(facenum,timestep)) * xN2_init;
rMeshFrac_O2 = sparse(ones(facenum,timestep)) * xO2_init;
rMeshFrac_H2S = sparse(ones(facenum,timestep)) * xH2S_init;
rMeshFrac_ALL = sparse(ones(facenum,timestep)) * xALL_init;

rMatrixFrac_CH4 = sparse(ones(cellnum,timestep)) * xCH4_init;
rMatrixFrac_CO2 = sparse(ones(cellnum,timestep)) * xCO2_init;
rMatrixFrac_H2O = sparse(ones(cellnum,timestep)) * xH2O_init;
rMatrixFrac_CO = sparse(ones(cellnum,timestep)) * xCO_init;
rMatrixFrac_H2 = sparse(ones(cellnum,timestep)) * xH2_init;
rMatrixFrac_N2 = sparse(ones(cellnum,timestep)) * xN2_init;
rMatrixFrac_O2 = sparse(ones(cellnum,timestep)) * xO2_init;
rMatrixFrac_H2S = sparse(ones(cellnum,timestep)) * xH2S_init;
rMatrixFrac_ALL = sparse(ones(cellnum,timestep)) * xALL_init;

rMatrixFracM_CH4 = sparse(ones(cellnum,timestep)) * xMCH4_init;
rMatrixFracM_CO2 = sparse(ones(cellnum,timestep)) * xMCO2_init;
rMatrixFracM_H2O = sparse(ones(cellnum,timestep)) * xMH2O_init;
rMatrixFracM_CO = sparse(ones(cellnum,timestep)) * xMCO_init;
rMatrixFracM_H2 = sparse(ones(cellnum,timestep)) * xMH2_init;
rMatrixFracM_N2 = sparse(ones(cellnum,timestep)) * xMN2_init;
rMatrixFracM_O2 = sparse(ones(cellnum,timestep)) * xMO2_init;
rMatrixFracM_H2S = sparse(ones(cellnum,timestep)) * xMH2S_init;
rMatrixFracM_ALL = sparse(ones(cellnum,timestep)) * xMALL_init;

rMesh_mu = sparse(ones(facenum,timestep))*mu(1,1);
rMesh_cond = sparse(ones(facenum,timestep))*cond(1,1);
rMeshCp = sparse(ones(facenum,timestep))*Cp(1,1);
rMatrixDens = sparse(ones(cellnum,timestep))*rho(1,1);
rMatrixDensM = sparse(ones(cellnum,timestep))*rhoM(1,1);
rMatrix_Mu = sparse(ones(cellnum,timestep))*mu(1,1);
rMatrix_cond = sparse(ones(cellnum,timestep))*cond(1,1);
rMatrixCp = sparse(ones(cellnum,timestep))*Cp(1,1);
rdiff = ones(facenum,1) * diffCalc;

rMeshDens = sparse(ones(facenum,timestep))* rho(1,1); 
rMeshDensM = sparse(ones(facenum,timestep))* rhoM(1,1);

%% Pellet Surface Properties. 
% Surface data structures are used to allow communication between the
% pellet scale computations, and the reactor scale. They are calculated at
% the reactor scale. 

sMatrixPress = sparse(ones(cellnum,timestep)) * P;
sMatrixTemp = sparse(ones(cellnum,timestep)) * T;

sMatrixFrac_CH4 = sparse(ones(cellnum,timestep)) * xCH4_init;
sMatrixFrac_CO2 = sparse(ones(cellnum,timestep)) * xCO2_init;
sMatrixFrac_H2O = sparse(ones(cellnum,timestep)) * xH2O_init;
sMatrixFrac_CO = sparse(ones(cellnum,timestep)) * xCO_init;
sMatrixFrac_H2 = sparse(ones(cellnum,timestep)) * xH2_init;
sMatrixFrac_N2 = sparse(ones(cellnum,timestep)) * xN2_init;
sMatrixFrac_O2 = sparse(ones(cellnum,timestep)) * xO2_init;
sMatrixFrac_H2S = sparse(ones(cellnum,timestep)) * xH2S_init;
sMatrixFrac_Coke = sparse(ones(cellnum,timestep)) * xCoke_init;
sMatrixFrac_ALL = sparse(ones(cellnum,timestep)) * xALL_init;

sMatrixFracM_CH4 = sparse(ones(cellnum,timestep)) * xMCH4_init;
sMatrixFracM_CO2 = sparse(ones(cellnum,timestep)) * xMCO2_init;
sMatrixFracM_H2O = sparse(ones(cellnum,timestep)) * xMH2O_init;
sMatrixFracM_CO = sparse(ones(cellnum,timestep)) * xMCO_init;
sMatrixFracM_H2 = sparse(ones(cellnum,timestep)) * xMH2_init;
sMatrixFracM_N2 = sparse(ones(cellnum,timestep)) * xMN2_init;
sMatrixFracM_O2 = sparse(ones(cellnum,timestep)) * xMO2_init;
sMatrixFracM_H2S = sparse(ones(cellnum,timestep)) * xMH2S_init;
sMatrixFracM_Coke = sparse(ones(cellnum,timestep)) * xMCoke_init;
sMatrixFracM_ALL = sparse(ones(cellnum,timestep)) * xMALL_in;

sMatrixDens = sparse(ones(cellnum,timestep))*rho(1,1);
sMatrixDensM = sparse(ones(cellnum,timestep))*rhoM(1,1);
sMatrix_Mu = sparse(ones(cellnum,timestep))*mu(1,1);
sMatrix_cond = sparse(ones(cellnum,timestep))*cond(1,1);
sMatrixCp = sparse(ones(cellnum,timestep))*Cp(1,1);
sdiff = ones(facenum,1) * diffCalc;

rxn = RXNCalcVect(P, T, xMCH4_init, xMCO2_init, xMH2O_init, xMCO_init, xMH2_init, xMN2_init, xMO2_init, 0, 1, rxnmech, convmod);
sMatrixRXN = ones(cellnum,timestep,6);
sMatrixRXN(:,:,1) = sMatrixRXN(:,:,1) * rxn(1,1); 
sMatrixRXN(:,:,2) = sMatrixRXN(:,:,2) * rxn(1,2); 
sMatrixRXN(:,:,3) = sMatrixRXN(:,:,3) * rxn(1,3); 
sMatrixRXN(:,:,4) = sMatrixRXN(:,:,4) * rxn(1,4); 
sMatrixRXN(:,:,5) = sMatrixRXN(:,:,5) * rxn(1,5); 
sMatrixRXN(:,:,6) = sMatrixRXN(:,:,6) * rxn(1,6); 

sMatrixCokeRXN = zeros(cellnum,timestep,6);


%% Setting Pellet Properties.
% Pellet data structures are based on spatial discretiazation, i.e. the
% reactor dimension and hte pellet dimensions are stored. These data
% structures are not conserved through time, however. Only the last
% steady-state profile will be preserved. 

% NOTE: As these are 3D arrays, they cannot be defined as sparse matrices
% in MATLAB. There are custom options that may be worth exploring down the
% line, but - for the time being - these will have to be full matrices. 

pMeshPress = ones(cellnum,partface,timestep) * P;
pMeshTemp = ones(cellnum,partface,timestep) * T;
pMatrixPress = ones(cellnum,partnum,timestep) * P;
pMatrixTemp = ones(cellnum,partnum,timestep) * T;

pMeshFracM_CH4 = ones(cellnum,partface,timestep) * xMCH4_init;
pMeshFracM_CO2 = ones(cellnum,partface,timestep) * xMCO2_init;
pMeshFracM_H2O = ones(cellnum,partface,timestep) * xMH2O_init;
pMeshFracM_CO = ones(cellnum,partface,timestep) * xMCO_init;
pMeshFracM_H2 = ones(cellnum,partface,timestep) * xMH2_init;
pMeshFracM_N2 = ones(cellnum,partface,timestep) * xMN2_init;
pMeshFracM_O2 = ones(cellnum,partface,timestep) * xMO2_init;
pMeshFracM_H2S = ones(cellnum,partface,timestep) * xMH2S_init;
pMeshFracM_ALL = ones(cellnum,partface,timestep) * xMALL_in;

pMeshFrac_CH4 = ones(cellnum,partface,timestep) * xCH4_in;
pMeshFrac_CO2 = ones(cellnum,partface,timestep) * xCO2_in;
pMeshFrac_H2O = ones(cellnum,partface,timestep) * xH2O_in;
pMeshFrac_CO = ones(cellnum,partface,timestep) * xCO_in;
pMeshFrac_H2 = ones(cellnum,partface,timestep) * xH2_in;
pMeshFrac_N2 = ones(cellnum,partface,timestep) * xN2_in;
pMeshFrac_O2 = ones(cellnum,partface,timestep) * xO2_in;
pMeshFrac_H2S = ones(cellnum,partface,timestep) * xH2S_in;
pMeshFrac_ALL = ones(cellnum,partface,timestep) * xALL_in;

pMatrixFrac_CH4 = ones(cellnum,partnum,timestep) * xCH4_in;
pMatrixFrac_CO2 = ones(cellnum,partnum,timestep) * xCO2_in;
pMatrixFrac_H2O = ones(cellnum,partnum,timestep) * xH2O_in;
pMatrixFrac_CO = ones(cellnum,partnum,timestep) * xCO_in;
pMatrixFrac_H2 = ones(cellnum,partnum,timestep) * xH2_in;
pMatrixFrac_N2 = ones(cellnum,partnum,timestep) * xN2_in;
pMatrixFrac_O2 = ones(cellnum,partnum,timestep) * xO2_in;
pMatrixFrac_H2S = ones(cellnum,partnum,timestep) * xH2S_in;
pMatrixFrac_ALL = ones(cellnum,partnum,timestep) * xALL_in;

pMatrixFracM_CH4 = ones(cellnum,partnum,timestep) * xMCH4_init;
pMatrixFracM_CO2 = ones(cellnum,partnum,timestep) * xMCO2_init;
pMatrixFracM_H2O = ones(cellnum,partnum,timestep) * xMH2O_init;
pMatrixFracM_CO = ones(cellnum,partnum,timestep) * xMCO_init;
pMatrixFracM_H2 = ones(cellnum,partnum,timestep) * xMH2_init;
pMatrixFracM_N2 = ones(cellnum,partnum,timestep) * xMN2_init;
pMatrixFracM_O2 = ones(cellnum,partnum,timestep) * xMO2_init;
pMatrixFracM_H2S = ones(cellnum,partnum,timestep) * xMH2S_init;
pMatrixFracM_ALL = ones(cellnum,partnum,timestep) * xMALL_in;

pMatrixDens = ones(cellnum,partnum,timestep)*rho(1,1);
pMatrixDensM = ones(cellnum,partnum,timestep)*rhoM(1,1);
pMatrix_cond = ones(cellnum,partnum,timestep)*cond(1,1);
pMatrixCp = ones(cellnum,partnum,timestep)*Cp(1,1);
pdiff = ones(cellnum,partface,timestep,8); 

pdiff(:,:,:,1) = pdiff(:,:,:,1) .* diffCalc(1,1);
pdiff(:,:,:,2) = pdiff(:,:,:,2) .* diffCalc(1,2);
pdiff(:,:,:,3) = pdiff(:,:,:,3) .* diffCalc(1,3);
pdiff(:,:,:,4) = pdiff(:,:,:,4) .* diffCalc(1,4);
pdiff(:,:,:,5) = pdiff(:,:,:,5) .* diffCalc(1,5);
pdiff(:,:,:,6) = pdiff(:,:,:,6) .* diffCalc(1,6);
pdiff(:,:,:,7) = pdiff(:,:,:,7) .* diffCalc(1,7);
pdiff(:,:,:,8) = pdiff(:,:,:,8) .* diffCalc(1,8);

pMeshDens = ones(cellnum,partface,timestep)* rho(1,1); 
pMeshDensM = ones(cellnum,partface,timestep)* rhoM(1,1);
pMesh_cond = ones(cellnum,partface,timestep)*cond(1,1);
pMeshCp = ones(cellnum,partface,timestep)*Cp(1,1);

rxn = RXNCalcVect(P, T, xMCH4_init, xMCO2_init, xMH2O_init, xMCO_init, xMH2_init, xMN2_init, xMO2_init, 0, 1, rxnmech, convmod);
pMatrixRXN = ones(cellnum,partnum,timestep,6);
pMatrixRXN(:,:,:,1) = pMatrixRXN(:,:,:,1) .* rxn(1,1); 
pMatrixRXN(:,:,:,2) = pMatrixRXN(:,:,:,2) .* rxn(1,2); 
pMatrixRXN(:,:,:,3) = pMatrixRXN(:,:,:,3) .* rxn(1,3); 
pMatrixRXN(:,:,:,4) = pMatrixRXN(:,:,:,4) .* rxn(1,4); 
pMatrixRXN(:,:,:,5) = pMatrixRXN(:,:,:,5) .* rxn(1,5); 
pMatrixRXN(:,:,:,6) = pMatrixRXN(:,:,:,6) .* rxn(1,6); 

rMatrixEff = ones(cellnum,timestep,3);
rMatrixEff(:,:,1) = ones(cellnum,timestep) * eff1; 
rMatrixEff(:,:,2) = ones(cellnum,timestep) * eff2; 
rMatrixEff(:,:,3) = ones(cellnum,timestep) * eff3; 

%% Misc. Data

error_rho = 1;
rhobed = 53.5; % kg/m^3 for catalyst bulk density
catdV = rhobed * Acs * dz; % Amount of catalyst (kg) in each segment of bed.

%% Velocity

k = 2; 

rMeshVel = sparse(ones(facenum,timestep))* uz_i; 
rMatrixVel = sparse(ones(cellnum,timestep))* uz_i;

P = rMatrixPress(:,k-1); T = rMatrixTemp(:,k-1); xMCH4 = rMatrixFracM_CH4(:,k-1);
xMCO2 = rMatrixFracM_CO2(:,k-1); xMH2O = rMatrixFracM_H2O(:,k-1);
xMCO = rMatrixFracM_CO(:,k-1); xMH2 = rMatrixFracM_H2(:,k-1); 
xMN2 = rMatrixFracM_N2(:,k-1); xMO2 = rMatrixFracM_O2(:,k-1); xMH2S = rMatrixFracM_H2S(:,k-1); 

err = 1;

while err > 10^-3

uz1 = rMeshVel(1:i,k-1); uz2 = rMeshVel(2:i+1,k-1); uz = rMatrixVel(:,k-1);

dL(1,1) = (dz/2); dL(2:i,1) = dz; dL(i+1,1) = (dz/2);
dPress = (((1.75 .* rho.* (1-eps) .* uz) ./ (d_p .* eps .^ 3)) + ...
    ((150 .* mu .* (1-eps) .^ 2) ./ (d_p .* eps .^ 3))) .* uz;

P(1,1) = P_in - dPress(1,1) * dL(1,1);

for i = 2:cellnum
    P(i,1) = P(i-1,1) - dPress(i,1) * dL(i,1);
end

P_out = P(i,1) - dPress(i,1) * (dL(i,1) / 2); 

dP(1,1) = P_in - P(1,1);
dP(2:i,1) = P(1:i-1,1) - P(2:i,1);
dP(i+1,1) = P(i,1) - P_out;

rMatrixDens(:,k-1) = Mix_Dens(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, xMH2S, i);
rMeshDens(2:i,k-1) = (rMatrixDens(1:i-1,k-1)+rMatrixDens(2:i,k-1))/2;
rMeshDens(i+1,k-1) = rMatrixDens(i,k-1) * (P_out/P(i,1));

rMatrixDensM(:,k-1) = rMatrixDens(:,k-1) ./ (MoltoMass_i/1000); rhoM = rMatrixDensM(:,k-1);
rMeshDensM(2:i,k-1) = (rMatrixDensM(1:i-1,k-1)+rMatrixDens(2:i,k-1))/2;
rMeshDensM(i+1,k-1) = rMatrixDensM(i,k-1) * (P_out/P(i,1));

rho1 = rMeshDens(1:i,k-1); rho2 = rMeshDens(2:i+1,k-1); rho = rMatrixDens(:,k-1);
mu1 = rMesh_mu(1:i,k-1); mu2 = rMesh_mu(2:i+1,k-1); mu = rMatrix_Mu(:,k-1);

ConsLHS_LFace = -(rho1);
ConsLHS_LFace2 = full(cat(1,zeros(1,i),cat(2,diag(ConsLHS_LFace(2:i)),zeros(i-1,1))));
ConsLHS_RFace = (rho2);  
ConsLHS_RFace2 = full(cat(1,zeros(1,i),cat(2,zeros(i-1,1),diag(ConsLHS_RFace(2:i)))));
ConsLHS = ConsLHS_LFace2 + ConsLHS_RFace2; 
ConsRHS = zeros(i,1); 

ConsLHS(1,1) = rho(1,1); ConsRHS(1,1) = rho1(1,1) * uz_i;

MomLHS_LFace = ones(i,1)*-1;
MomLHS_LFace2 = cat(1,zeros(1,i),cat(2,diag(MomLHS_LFace(2:i)),zeros(i-1,1)));
MomLHS_RFace = ones(i,1)*1;  
MomLHS_RFace2 = cat(1,zeros(1,i),cat(2,zeros(i-1,1),diag(MomLHS_RFace(2:i))));
MomLHS = MomLHS_LFace2 + MomLHS_RFace2;

K1 = 1 ./ (((1.75 .* rho1.* (1-eps) .* uz1) ./ (d_p .* eps .^ 3)) + ...
    ((150 .* mu1 .* (1-eps) .^ 2) ./ ((d_p.^2) .* eps.^3)));
K2 = 1 ./ (((1.75 .* rho2.* (1-eps) .* uz2) ./ (d_p .* eps .^ 3)) + ...
    ((150 .* mu2 .* (1-eps) .^ 2) ./ ((d_p.^2) .* eps.^3)));

MomRHS = dP(2:i+1,1) ./ dL(2:i+1,1) .* K2 - dP(1:i,1) ./ dL(1:i,1) .* K1;

MomLHS(1,1) = 1; 
MomRHS(1,1) = dP(2,1) ./ dL(2,1) .* K2(1,1) - dP(1,1) ./ dL(1,1) .* K1(1,1) + uz_i;

VelLHS = cat(1,ConsLHS,MomLHS); VelRHS = cat(1,ConsRHS,MomRHS);
VelSol = VelLHS\VelRHS;

err = sum(abs(1-VelSol./rMatrixVel(:,k-1)));
rMatrixVel(:,k-1) = VelSol;
rMeshVel(2:i,k-1) = (rMatrixVel(1:i-1,k-1)+rMatrixVel(2:i,k-1))/2;
rMeshVel(i+1,k-1) = rMatrixVel(i,k-1);

end

rMatrixPress(:,k-1) = P;
rMeshPress(2:i,k-1) = (rMatrixPress(1:i-1,k-1)+rMatrixPress(2:i,k-1))/2;
rMeshPress(i+1,k-1) = rMatrixPress(i,k-1);




