%%
% Reactor Mesh. 

% d_t - Inner diameter of tube; d_p - diameter of particle. Meters, m. 
% From Rout & Jakobsen (2015). 
d_t = sparse(0.1016); d_to = sparse(0.1322); d_p = sparse(0.0173);

% Acs - Cross-sectional area of the tube. Square meters, m^2.
Acs = sparse(pi*(d_t/2)^2);

% eps - porosity of the packed bed. Dixon (1988) is used here.
% Calculates as percentage void space (%). 

eps = sparse(0.4 + 0.05*d_p/d_t + 0.412*(d_p/d_t)^2);

rho_s = sparse(2300); % rho_s - Catalyst solid density. kg/m^3 - Values are from Rout & Jakobsen (2015)
Cp_s = sparse(0.85); % Cp_s - Catalyst solid heat capacity. kJ/kg.K

AdCap_H2S = 1.5*10E-6; % ppm - Catalyst sulphur capacity, ppm by mass. 

uz_i = sparse(1.89);    % inlet velocity, m/s. From Rout & Jakobsen (2015).
L = sparse(7);          % Length of the reactor, in meters. From Rout & Jakobsen (2015).
Truns = 20000;     % Number of runs, accumulates time. Multiply against [t] for
                % total time. 
t = 1;        % Time of simulation run, in seconds. Defined. 

% cellnum - number of cells defined within the one-dimensional domain. 
% dz - discrete length of each cell defined within the domain. In this
% simulation, the mesh is defined to be uniform, though the uniformity of
% the mesh is not a condition for the solution.

% dt - discrete time step desired, in seconds. 
% timestep - number of timesteps required, based on the discrete time step
% desired as well as the total length of time simulated. NOTE that there
% are stability considerations when setting dz and dt. 

% facenum - number of faces defined within the one-dimensional domain. 
% MeshFace - matrix that stores the axial location of each face centroid. 
% MeshCell - matrix that stores the axial locatoin of each cell centroid. 

cellnum = 50; dz = L/cellnum;
dt = 0.001; timestep = t/dt; 

facenum = cellnum + 1;
MeshFace = zeros(facenum,2); 
MeshCell = zeros(cellnum,2);
graphcount = 0; WriteData = 0;

% The mesh is generated iteratively, based on the number of desired cells
% and the length defined for the domain. Face and cell centroid positions
% are defined for the mesh. 

for i = 1:cellnum
    
    MeshFace(1+i,1) = 1+i;
    MeshFace(1+i,2) = MeshFace(i,2) + L / cellnum;
    MeshCell(i,1) = i;
    MeshCell(i,2) = MeshFace(i,2) + (MeshFace(1+i,2) - MeshFace(i,2))/2;
    
end

%%
% Particle Mesh

eps_p = sparse(0.528); tort_p = sparse(3.5); % From Rout & Jakobsen (2015).
rp = sparse(100*10^-9); %in meters

% Keep partnum at >100 to maintain resolution at particle-gas interface.
partnum = 50; drp = sparse(d_p/2/partnum);

partface = partnum + 1;
pMeshCell = zeros(partnum,2); 
pMeshFace = zeros(partface,2);

pMeshFace(1,1) = 1; pMeshFace(1,2) = 0;

for i = 1:partnum
    
    pMeshFace(1+i,1) = 1+i;
    pMeshFace(1+i,2) = pMeshFace(i,2) + d_p/2 / partnum;
    pMeshCell(i,1) = i;
    pMeshCell(i,2) = pMeshFace(i,2) + (pMeshFace(1+i,2) - pMeshFace(i,2))/2;
    
end

