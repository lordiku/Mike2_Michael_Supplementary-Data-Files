
% Values within the catalyst pellets are computed in [CalcPellet]; these
% values are then used to approximate those of the catalyst surface. 

% Field values are retrieved for every cell within all catalyst pellets. 
i = cellnum; j = partnum; 
Pp = pMatrixPress(:,:,k-1); Tp = pMatrixTemp(:,:,k-1); xpCH4 = pMatrixFrac_CH4(:,:,k-1);
xpCO2 = pMatrixFrac_CO2(:,:,k-1); xpH2O = pMatrixFrac_H2O(:,:,k-1);
xpCO = pMatrixFrac_CO(:,:,k-1); xpH2 = pMatrixFrac_H2(:,:,k-1); 
xpN2 = pMatrixFrac_N2(:,:,k-1); xpO2 = pMatrixFrac_O2(:,:,k-1); xpH2S = pMatrixFrac_H2S(:,:,k-1); 

% Thermodynamic and transport values are retrieved for every face in the
% catalyst pellet. 
rho1_p = pMeshDens(:,1:j,k-1); rho2_p = pMeshDens(:,2:j+1,k-1); rho_p = pMatrixDens(:,:,k-1);
Cp1_p = pMeshCp(:,1:j,k-1); Cp2_p = pMeshCp(:,2:j+1,k-1); Cp_p = pMatrixCp(:,:,k-1);
cond1_p = pMesh_cond(:,1:j,k-1); cond2_p = pMesh_cond(:,2:j+1,k-1); cond_p = pMatrix_cond(:,:,k-1);

% Reaction rates are retrieved. Note that these are still in mol/kgcat.s
pMatrixSMR1 = pMatrixRXN(:,:,k-1,1); rxn1_p = pMatrixSMR1;   % CH4 + H2O -> CO + 3H2
pMatrixSMR2 = pMatrixRXN(:,:,k-1,2); rxn2_p = pMatrixSMR2;   % CO + H2O -> CO2 + H2
pMatrixSMR3 = pMatrixRXN(:,:,k-1,3); rxn3_p = pMatrixSMR3;   % CH4 + 2H2O -> CO2 + 4H2

% Finding species reaction rates, based on stoichiometric equations.
% Note: molar weights are adjusted to show Kg/mol from g/mol.
% Here, reaction rates are converted to kg/s, following SI unit convention.
% (kgcat/m^3)*(mol/kgcat.s)*(g/mol)*(kg/1000g) = kg/m^3.s
coeff1 = (1-eps_p).*rho_s.*drp./1000;
rxnCH4_p = coeff1.*mCH4.*  (-rxn1_p-rxn3_p); 
rxnCO2_p = coeff1.*mCO2.*  (rxn2_p+rxn3_p); 
rxnH2O_p = coeff1.*mH2O.*  (-rxn1_p-rxn2_p-rxn3_p-rxn3_p);
rxnCO_p = coeff1.*mCO.*    (rxn1_p-rxn2_p);
rxnH2_p = coeff1.*mH2.*    (rxn1_p+rxn1_p+rxn1_p+rxn2_p+rxn3_p+rxn3_p+rxn3_p+rxn3_p);

% Effective diffusivities are calculated based on the molecular
% diffusivities for each species.

% Diffusivities are retrieved, and effective diffusivities are defined. 
pD1_CH4 = pdiff(:,1:j,k-1,1); pD2_CH4 = pdiff(:,2:j+1,k-1,1);
pD1_CO2 = pdiff(:,1:j,k-1,2); pD2_CO2 = pdiff(:,2:j+1,k-1,2);
pD1_H2O = pdiff(:,1:j,k-1,3); pD2_H2O = pdiff(:,2:j+1,k-1,3);
pD1_CO = pdiff(:,1:j,k-1,4); pD2_CO = pdiff(:,2:j+1,k-1,4);
pD1_H2 = pdiff(:,1:j,k-1,5); pD2_H2 = pdiff(:,2:j+1,k-1,5);
pD1_N2 = pdiff(:,1:j,k-1,6); pD2_N2 = pdiff(:,2:j+1,k-1,6);
pD1_O2 = pdiff(:,1:j,k-1,7); pD2_O2 = pdiff(:,2:j+1,k-1,7);
pD1_H2S = pdiff(:,1:j,k-1,8); pD2_H2S = pdiff(:,2:j+1,k-1,8);
D_ep1 = zeros(i,j,8); D_ep2 = zeros(i,j,8);

% Knudsen Diffusivities are defined; effective diffusivities are calculated. 
D_ek_CH4 = 97.*rp.*sqrt(Tp./mCH4);
D_ep1(:,:,1) = (1 ./ (1 ./ (pD1_CH4 .* eps_p ./ tort_p) + 1 ./ D_ek_CH4));
D_ep2(:,:,1) = (1 ./ (1 ./ (pD2_CH4 .* eps_p ./ tort_p) + 1 ./ D_ek_CH4));

D_ek_CO2 = 97.*rp.*sqrt(Tp./mCO2);
D_ep1(:,:,2) = (1 ./ (1 ./ (pD1_CO2 .* eps_p ./ tort_p) + 1 ./ D_ek_CO2));
D_ep2(:,:,2) = (1 ./ (1 ./ (pD2_CO2 .* eps_p ./ tort_p) + 1 ./ D_ek_CO2));

D_ek_H2O = 97.*rp.*sqrt(Tp./mH2O);
D_ep1(:,:,3) = (1 ./ (1 ./ (pD1_H2O .* eps_p ./ tort_p) + 1 ./ D_ek_H2O));
D_ep2(:,:,3) = (1 ./ (1 ./ (pD2_H2O .* eps_p ./ tort_p) + 1 ./ D_ek_H2O));

D_ek_CO = 97.*rp.*sqrt(Tp./mCO);
D_ep1(:,:,4) = (1 ./ (1 ./ (pD1_CO .* eps_p ./ tort_p) + 1 ./ D_ek_CO));
D_ep2(:,:,4) = (1 ./ (1 ./ (pD2_CO .* eps_p ./ tort_p) + 1 ./ D_ek_CO));

D_ek_H2 = 97.*rp.*sqrt(Tp./mH2);
D_ep1(:,:,5) = (1 ./ (1 ./ (pD1_H2 .* eps_p ./ tort_p) + 1 ./ D_ek_H2));
D_ep2(:,:,5) = (1 ./ (1 ./ (pD2_H2 .* eps_p ./ tort_p) + 1 ./ D_ek_H2));

D_ek_N2 = 97.*rp.*sqrt(Tp./mN2);
D_ep1(:,:,6) = (1 ./ (1 ./ (pD1_N2 .* eps_p ./ tort_p) + 1 ./ D_ek_N2));
D_ep2(:,:,6) = (1 ./ (1 ./ (pD2_N2 .* eps_p ./ tort_p) + 1 ./ D_ek_N2));

D_ek_O2 = 97.*rp.*sqrt(Tp./mO2);
D_ep1(:,:,7) = (1 ./ (1 ./ (pD1_O2 .* eps_p ./ tort_p) + 1 ./ D_ek_O2));
D_ep2(:,:,7) = (1 ./ (1 ./ (pD2_O2 .* eps_p ./ tort_p) + 1 ./ D_ek_O2));

D_ek_H2S = 97.*rp.*sqrt(Tp./mH2S);
D_ep1(:,:,8) = (1 ./ (1 ./ (pD1_H2S .* eps_p ./ tort_p) + 1 ./ D_ek_H2S));
D_ep2(:,:,8) = (1 ./ (1 ./ (pD2_H2S .* eps_p ./ tort_p) + 1 ./ D_ek_H2S));

% Effective diffusivities for each species at every face are then set, in
% order to incorporate them into the species continuity equations. 
pDCH4_1 = D_ep1(:,:,1); pDCH4_2 = D_ep2(:,:,1); 
pDCO2_1 = D_ep1(:,:,2); pDCO2_2 = D_ep2(:,:,2); 
pDH2O_1 = D_ep1(:,:,3); pDH2O_2 = D_ep2(:,:,3); 
pDCO_1 = D_ep1(:,:,4); pDCO_2 = D_ep2(:,:,4); 
pDH2_1 = D_ep1(:,:,5); pDH2_2 = D_ep2(:,:,5); 
pDN2_1 = D_ep1(:,:,6); pDN2_2 = D_ep2(:,:,6); 
pDO2_1 = D_ep1(:,:,7); pDO2_2 = D_ep2(:,:,7); 
pDH2S_1 = D_ep1(:,:,8); pDH2S_2 = D_ep2(:,:,8); 

% Coefficient values are used to reduce the number of operations being
% calculated by MATLAB. "a_ps1" does not change. 
a_p1 = (eps_p.*rho_p).*(drp./dt);

% Each pellet is calculated as its own vector; pellets are sequentially
% solved along the length of the reactor. All calculations are for the
% current timestep. 

% A major future improvement would be to wrap this "for" loop in such a way
% that permits paralellization of these calculations. This would
% significantly increase the speed of the conventional heterogeneous model.
% Note, however, that the control of data may be challenging; this has not
% yet been investigated in depth. 

for c = 1:cellnum

% Heats of reaction determined for pellet based on temp. 
T_calc = Tp(c,:);
Hrxn1_p = H_Calc(T_calc,1); Hrxn2_p = H_Calc(T_calc,2); Hrxn3_p = H_Calc(T_calc,3);
Qrxn_p = -(rxn1_p(c,:).*Hrxn1_p+rxn2_p(c,:).*Hrxn2_p+rxn3_p(c,:).*Hrxn3_p).* rho_s .* (1-eps_p);

% Catalyst energy conservation continuity matrix is constructed. 
pHeatLHS_LFace = -cond1_p(c,:)./drp;
pHeatLHS_LFace2 = cat(1,zeros(1,j),cat(2,diag(pHeatLHS_LFace(2:j)),zeros(j-1,1)));
pHeatLHS_Cell = diag((rho_s.*Cp_s.*(drp./dt)+cond1_p(c,:)./drp+cond2_p(c,:)./drp));
pHeatLHS_RFace = -cond2_p(c,:)./drp;
pHeatLHS_RFace2 = cat(2,zeros(j,1),cat(1,diag(pHeatLHS_RFace(1:j-1)),zeros(1,j-1)));
pHeatLHS = pHeatLHS_LFace2 + pHeatLHS_Cell + pHeatLHS_RFace2;
pHeatRHS = rho_s.*Cp_s.*(drp./dt).*Tp(c,:)+Qrxn_p.*drp;

% Inlet boundaries are defined. 
pHeatLHS(1,1) = rho_s.*Cp_s.*(drp./dt)+cond2_p(c,1)./drp;
pHeatLHS(1,2) = -cond2_p(c,1)./drp;
pHeatRHS(1,1) = rho_s.*Cp_s.*(drp./dt).*Tp(c,1)+Qrxn_p(1,1).*drp;

% Outlet boundaries are defined. 
pHeatLHS(j,j-1) = -cond1_p(c,j)./drp-0.5.*h(c,1);
pHeatLHS(j,j) = rho_s.*Cp_s.*(drp./dt)+1.5.*h(c,1)+cond1_p(c,j)./drp;
pHeatRHS(1,j) = rho_s.*Cp_s.*(drp./dt).*Tp(c,j)+h(c,1).*T(c,1)+Qrxn_p(1,j).*drp;
pHeatRHS = pHeatRHS';

% Catalyst species mass conservation continuity matrix is constructed. 
Frac_pCH4LHS_LFace = -pDCH4_1(c,:)./drp.*rho1_p(c,:);
Frac_pCH4LHS_LFace2 = cat(1,zeros(1,j),cat(2,diag(Frac_pCH4LHS_LFace(2:j)),zeros(j-1,1)));
Frac_pCH4LHS_Cell = diag((a_p1(c,:)+pDCH4_2(c,:).*rho2_p(c,:)./drp+pDCH4_1(c,:).*rho1_p(c,:)./drp));
Frac_pCH4LHS_RFace = -pDCH4_2(c,:).*rho2_p(c,:)./drp;
Frac_pCH4LHS_RFace2 = cat(2,zeros(j,1),cat(1,diag(Frac_pCH4LHS_RFace(1:j-1)),zeros(1,j-1)));
Frac_pCH4LHS = Frac_pCH4LHS_LFace2 + Frac_pCH4LHS_Cell + Frac_pCH4LHS_RFace2;
Frac_pCH4RHS = eps_p.*rho_p(c,:).*xpCH4(c,:).*(drp/dt)+rxnCH4_p(c,:);

Frac_pCO2LHS_LFace = -pDCO2_1(c,:)./drp.*rho1_p(c,:);
Frac_pCO2LHS_LFace2 = cat(1,zeros(1,j),cat(2,diag(Frac_pCO2LHS_LFace(2:j)),zeros(j-1,1)));
Frac_pCO2LHS_Cell = diag((a_p1(c,:)+pDCO2_2(c,:).*rho2_p(c,:)./drp+pDCO2_1(c,:).*rho1_p(c,:)./drp));
Frac_pCO2LHS_RFace = -pDCO2_2(c,:).*rho2_p(c,:)./drp;
Frac_pCO2LHS_RFace2 = cat(2,zeros(j,1),cat(1,diag(Frac_pCO2LHS_RFace(1:j-1)),zeros(1,j-1)));
Frac_pCO2LHS = Frac_pCO2LHS_LFace2 + Frac_pCO2LHS_Cell + Frac_pCO2LHS_RFace2;
Frac_pCO2RHS = eps_p.*rho_p(c,:).*xpCO2(c,:).*(drp/dt)+rxnCO2_p(c,:);

Frac_pH2OLHS_LFace = -pDH2O_1(c,:)./drp.*rho1_p(c,:);
Frac_pH2OLHS_LFace2 = cat(1,zeros(1,j),cat(2,diag(Frac_pH2OLHS_LFace(2:j)),zeros(j-1,1)));
Frac_pH2OLHS_Cell = diag((a_p1(c,:)+pDH2O_2(c,:).*rho2_p(c,:)./drp+pDH2O_1(c,:).*rho1_p(c,:)./drp));
Frac_pH2OLHS_RFace = -pDH2O_2(c,:).*rho2_p(c,:)./drp;
Frac_pH2OLHS_RFace2 = cat(2,zeros(j,1),cat(1,diag(Frac_pH2OLHS_RFace(1:j-1)),zeros(1,j-1)));
Frac_pH2OLHS = Frac_pH2OLHS_LFace2 + Frac_pH2OLHS_Cell + Frac_pH2OLHS_RFace2;
Frac_pH2ORHS = eps_p.*rho_p(c,:).*xpH2O(c,:).*(drp/dt)+rxnH2O_p(c,:);

Frac_pCOLHS_LFace = -pDCO_1(c,:)./drp.*rho1_p(c,:);
Frac_pCOLHS_LFace2 = cat(1,zeros(1,j),cat(2,diag(Frac_pCOLHS_LFace(2:j)),zeros(j-1,1)));
Frac_pCOLHS_Cell = diag((a_p1(c,:)+pDCO_2(c,:).*rho2_p(c,:)./drp+pDCO_1(c,:).*rho1_p(c,:)./drp));
Frac_pCOLHS_RFace = -pDCO_2(c,:).*rho2_p(c,:)./drp;
Frac_pCOLHS_RFace2 = cat(2,zeros(j,1),cat(1,diag(Frac_pCOLHS_RFace(1:j-1)),zeros(1,j-1)));
Frac_pCOLHS = Frac_pCOLHS_LFace2 + Frac_pCOLHS_Cell + Frac_pCOLHS_RFace2;
Frac_pCORHS = eps_p.*rho_p(c,:).*xpCO(c,:).*(drp/dt)+rxnCO_p(c,:);

Frac_pH2LHS_LFace = -pDH2_1(c,:)./drp.*rho1_p(c,:);
Frac_pH2LHS_LFace2 = cat(1,zeros(1,j),cat(2,diag(Frac_pH2LHS_LFace(2:j)),zeros(j-1,1)));
Frac_pH2LHS_Cell = diag((a_p1(c,:)+pDH2_2(c,:).*rho2_p(c,:)./drp+pDH2_1(c,:).*rho1_p(c,:)./drp));
Frac_pH2LHS_RFace = -pDH2_2(c,:).*rho2_p(c,:)./drp;
Frac_pH2LHS_RFace2 = cat(2,zeros(j,1),cat(1,diag(Frac_pH2LHS_RFace(1:j-1)),zeros(1,j-1)));
Frac_pH2LHS = Frac_pH2LHS_LFace2 + Frac_pH2LHS_Cell + Frac_pH2LHS_RFace2;
Frac_pH2RHS = eps_p.*rho_p(c,:).*xpH2(c,:).*(drp/dt)+rxnH2_p(c,:);

Frac_pN2LHS_LFace = -pDN2_1(c,:)./drp.*rho1_p(c,:);
Frac_pN2LHS_LFace2 = cat(1,zeros(1,j),cat(2,diag(Frac_pN2LHS_LFace(2:j)),zeros(j-1,1)));
Frac_pN2LHS_Cell = diag((a_p1(c,:)+pDN2_2(c,:).*rho2_p(c,:)./drp+pDN2_1(c,:).*rho1_p(c,:)./drp));
Frac_pN2LHS_RFace = -pDN2_2(c,:).*rho2_p(c,:)./drp;
Frac_pN2LHS_RFace2 = cat(2,zeros(j,1),cat(1,diag(Frac_pN2LHS_RFace(1:j-1)),zeros(1,j-1)));
Frac_pN2LHS = Frac_pN2LHS_LFace2 + Frac_pN2LHS_Cell + Frac_pN2LHS_RFace2;
Frac_pN2RHS = eps_p.*rho_p(c,:).*xpN2(c,:).*(drp/dt);

Frac_pO2LHS_LFace = -pDO2_1(c,:)./drp.*rho1_p(c,:);
Frac_pO2LHS_LFace2 = cat(1,zeros(1,j),cat(2,diag(Frac_pO2LHS_LFace(2:j)),zeros(j-1,1)));
Frac_pO2LHS_Cell = diag((a_p1(c,:)+pDO2_2(c,:).*rho2_p(c,:)./drp+pDO2_1(c,:).*rho1_p(c,:)./drp));
Frac_pO2LHS_RFace = -pDO2_2(c,:).*rho2_p(c,:)./drp;
Frac_pO2LHS_RFace2 = cat(2,zeros(j,1),cat(1,diag(Frac_pO2LHS_RFace(1:j-1)),zeros(1,j-1)));
Frac_pO2LHS = Frac_pO2LHS_LFace2 + Frac_pO2LHS_Cell + Frac_pO2LHS_RFace2;
Frac_pO2RHS = eps_p.*rho_p(c,:).*xpO2(c,:).*(drp/dt);

Frac_pH2SLHS_LFace = -pDH2S_1(c,:)./drp.*rho1_p(c,:);
Frac_pH2SLHS_LFace2 = cat(1,zeros(1,j),cat(2,diag(Frac_pH2SLHS_LFace(2:j)),zeros(j-1,1)));
Frac_pH2SLHS_Cell = diag((a_p1(c,:)+pDH2S_2(c,:).*rho2_p(c,:)./drp+pDH2S_1(c,:).*rho1_p(c,:)./drp));
Frac_pH2SLHS_RFace = -pDH2S_2(c,:).*rho2_p(c,:)./drp;
Frac_pH2SLHS_RFace2 = cat(2,zeros(j,1),cat(1,diag(Frac_pH2SLHS_RFace(1:j-1)),zeros(1,j-1)));
Frac_pH2SLHS = Frac_pH2SLHS_LFace2 + Frac_pH2SLHS_Cell + Frac_pH2SLHS_RFace2;
Frac_pH2SRHS = eps_p.*rho_p(c,:).*xpH2S(c,:).*(drp/dt);

% Boundary conditions for the species continuity equations follow the same
% lines as that of the energy continuity equation. The pellet surface
% boundary is defined as Robins' boundary condition, while the cell center
% is defined as a Neumann boundary condition (to enforce symmetry about the
% pellet center). 

% Inlet boundaries are defined. 
Frac_pCH4LHS(1,1) = eps_p.*rho_p(c,1).*(drp/dt)+pDCH4_2(c,1).*rho2_p(c,1)./drp;
Frac_pCH4LHS(1,2) = -pDCH4_2(c,1).*rho2_p(c,1)./drp;
Frac_pCH4RHS(1,1) = eps_p.*rho_p(c,1).*xpCH4(c,1).*(drp/dt)+rxnCH4_p(c,1);

Frac_pCO2LHS(1,1) = eps_p.*rho_p(c,1).*(drp/dt)+pDCO2_2(c,1).*rho2_p(c,1)./drp;
Frac_pCO2LHS(1,2) = -pDCO2_2(c,1).*rho2_p(c,1)./drp;
Frac_pCO2RHS(1,1) = eps_p.*rho_p(c,1).*xpCO2(c,1).*(drp/dt)+rxnCO2_p(c,1);

Frac_pH2OLHS(1,1) = eps_p.*rho_p(c,1).*(drp/dt)+pDH2O_2(c,1).*rho2_p(c,1)./drp;
Frac_pH2OLHS(1,2) = -pDH2O_2(c,1).*rho2_p(c,1)./drp;
Frac_pH2ORHS(1,1) = eps_p.*rho_p(c,1).*xpH2O(c,1).*(drp/dt)+rxnH2O_p(c,1);

Frac_pCOLHS(1,1) = eps_p.*rho_p(c,1).*(drp/dt)+pDCO_2(c,1).*rho2_p(c,1)./drp;
Frac_pCOLHS(1,2) = -pDCO_2(c,1).*rho2_p(c,1)./drp;
Frac_pCORHS(1,1) = eps_p.*rho_p(c,1).*xpCO(c,1).*(drp/dt)+rxnCO_p(c,1);

Frac_pH2LHS(1,1) = eps_p.*rho_p(c,1).*(drp/dt)+pDH2_2(c,1).*rho2_p(c,1)./drp;
Frac_pH2LHS(1,2) = -pDH2_2(c,1).*rho2_p(c,1)./drp;
Frac_pH2RHS(1,1) = eps_p.*rho_p(c,1).*xpH2(c,1).*(drp/dt)+rxnH2_p(c,1);

Frac_pN2LHS(1,1) = eps_p.*rho_p(c,1).*(drp/dt)+pDN2_2(c,1).*rho2_p(c,1)./drp;
Frac_pN2LHS(1,2) = -pDN2_2(c,1).*rho2_p(c,1)./drp;
Frac_pN2RHS(1,1) = eps_p.*rho_p(c,1).*xpN2(c,1).*(drp/dt);

Frac_pO2LHS(1,1) = eps_p.*rho_p(c,1).*(drp/dt)+pDO2_2(c,1).*rho2_p(c,1)./drp;
Frac_pO2LHS(1,2) = -pDO2_2(c,1).*rho2_p(c,1)./drp;
Frac_pO2RHS(1,1) = eps_p.*rho_p(c,1).*xpO2(c,1).*(drp/dt);

Frac_pH2SLHS(1,1) = eps_p.*rho_p(c,1).*(drp/dt)+pDH2S_2(c,1).*rho2_p(c,1)./drp;
Frac_pH2SLHS(1,2) = -pDH2S_2(c,1).*rho2_p(c,1)./drp;
Frac_pH2SRHS(1,1) = eps_p.*rho_p(c,1).*xpH2S(c,1).*(drp/dt);

% Outlet boundaries are defined. 
Frac_pCH4LHS(j,j-1) = -pDCH4_1(c,j).*rho1_p(c,j)./drp - 0.5.*km_CH4(c,1).*rho1_p(c,j);
Frac_pCH4LHS(j,j) = eps_p.*rho_p(c,j).*(drp./dt) + 1.5.*km_CH4(c,1).*rho_p(c,j) + pDCH4_1(c,j).*rho1_p(c,j)./drp;
Frac_pCH4RHS(1,j) = eps_p.*rho_p(c,j).*xpCH4(c,j).*(drp./dt) + km_CH4(c,1).*rho_p(c,j).*xCH4_c(c,1)+rxnCH4_p(c,j);
Frac_pCH4RHS = Frac_pCH4RHS';

Frac_pCO2LHS(j,j-1) = -pDCO2_1(c,j).*rho1_p(c,j)./drp-0.5.*km_CO2(c,1).*rho1_p(c,j);
Frac_pCO2LHS(j,j) = eps_p.*rho_p(c,j).*(drp./dt)+1.5.*km_CO2(c,1).*rho_p(c,j)+pDCO2_1(c,j).*rho1_p(c,j)./drp;
Frac_pCO2RHS(1,j) = eps_p.*rho_p(c,j).*xpCO2(c,j).*(drp./dt)+km_CO2(c,1).*rho_p(c,j).*xCO2_c(c,1)+rxnCO2_p(c,j);
Frac_pCO2RHS = Frac_pCO2RHS';

Frac_pH2OLHS(j,j-1) = -pDH2O_1(c,j).*rho1_p(c,j)./drp-0.5.*km_H2O(c,1).*rho1_p(c,j);
Frac_pH2OLHS(j,j) = eps_p.*rho_p(c,j).*(drp./dt)+1.5.*km_H2O(c,1).*rho_p(c,j)+pDH2O_1(c,j).*rho1_p(c,j)./drp;
Frac_pH2ORHS(1,j) = eps_p.*rho_p(c,j).*xpH2O(c,j).*(drp./dt)+km_H2O(c,1).*rho_p(c,j).*xH2O_c(c,1)+rxnH2O_p(c,j);
Frac_pH2ORHS = Frac_pH2ORHS';

Frac_pCOLHS(j,j-1) = -pDCO_1(c,j).*rho1_p(c,j)./drp-0.5.*km_CO(c,1).*rho1_p(c,j);
Frac_pCOLHS(j,j) = eps_p.*rho_p(c,j).*(drp./dt)+1.5.*km_CO(c,1).*rho_p(c,j)+pDCO_1(c,j).*rho1_p(c,j)./drp;
Frac_pCORHS(1,j) = eps_p.*rho_p(c,j).*xpCO(c,j).*(drp./dt)+km_CO(c,1).*rho_p(c,j).*xCO_c(c,1)+rxnCO_p(c,j);
Frac_pCORHS = Frac_pCORHS';

Frac_pH2LHS(j,j-1) = -pDH2_1(c,j).*rho1_p(c,j)./drp-0.5.*km_H2(c,1).*rho1_p(c,j);
Frac_pH2LHS(j,j) = eps_p.*rho_p(c,j).*(drp./dt)+1.5.*km_H2(c,1).*rho_p(c,j)+pDH2_1(c,j).*rho1_p(c,j)./drp;
Frac_pH2RHS(1,j) = eps_p.*rho_p(c,j).*xpH2(c,j).*(drp./dt)+km_H2(c,1).*rho_p(c,j).*xH2_c(c,1)+rxnH2_p(c,j);
Frac_pH2RHS = Frac_pH2RHS';

Frac_pN2LHS(j,j-1) = -pDN2_1(c,j).*rho1_p(c,j)./drp-0.5.*km_N2(c,1).*rho1_p(c,j);
Frac_pN2LHS(j,j) = eps_p.*rho_p(c,j).*(drp./dt)+1.5.*km_N2(c,1).*rho_p(c,j)+pDN2_1(c,j).*rho1_p(c,j)./drp;
Frac_pN2RHS(1,j) = eps_p.*rho_p(c,j).*xpN2(c,j).*(drp./dt)+km_N2(c,1).*rho_p(c,j).*xN2_c(c,1);
Frac_pN2RHS = Frac_pN2RHS';

Frac_pO2LHS(j,j-1) = -pDO2_1(c,j).*rho1_p(c,j)./drp-0.5.*km_O2(c,1).*rho1_p(c,j);
Frac_pO2LHS(j,j) = eps_p.*rho_p(c,j).*(drp./dt)+1.5.*km_O2(c,1).*rho_p(c,j)+pDO2_1(c,j).*rho1_p(c,j)./drp;
Frac_pO2RHS(1,j) = eps_p.*rho_p(c,j).*xpO2(c,j).*(drp./dt)+km_O2(c,1).*rho_p(c,j).*xO2_c(c,1);
Frac_pO2RHS = Frac_pO2RHS';

Frac_pH2SLHS(j,j-1) = -pDH2S_1(c,j).*rho1_p(c,j)./drp-0.5.*km_H2S(c,1).*rho1_p(c,j);
Frac_pH2SLHS(j,j) = eps_p.*rho_p(c,j).*(drp./dt)+1.5.*km_H2S(c,1).*rho_p(c,j)+pDH2S_1(c,j).*rho1_p(c,j)./drp;
Frac_pH2SRHS(1,j) = eps_p.*rho_p(c,j).*xpH2S(c,j).*(drp./dt)+km_H2S(c,1).*rho_p(c,j).*xH2S_c(c,1);
Frac_pH2SRHS = Frac_pH2SRHS';

% With the completed coefficient and solution matrices, the mass fraction
% profiles of each species can now be solved for the whole domain. Each of
% these are solved individually. 

pMatrixSoln_Temp = sparse(pHeatLHS\pHeatRHS); pMatrixTemp(c,:,k) = pMatrixSoln_Temp(1:j,1);
pMatrixSoln_CH4 = sparse(Frac_pCH4LHS\Frac_pCH4RHS); CH4Neg = find(pMatrixSoln_CH4<0);
pMatrixSoln_CO2 = sparse(Frac_pCO2LHS\Frac_pCO2RHS); CO2Neg = find(pMatrixSoln_CO2<0);
pMatrixSoln_H2O = sparse(Frac_pH2OLHS\Frac_pH2ORHS); H2ONeg = find(pMatrixSoln_H2O<0);
pMatrixSoln_CO = sparse(Frac_pCOLHS\Frac_pCORHS); CONeg = find(pMatrixSoln_CO<0);
pMatrixSoln_H2 = sparse(Frac_pH2LHS\Frac_pH2RHS); H2Neg = find(pMatrixSoln_H2<0);
pMatrixSoln_N2 = sparse(Frac_pN2LHS\Frac_pN2RHS); N2Neg = find(pMatrixSoln_N2<0);
pMatrixSoln_O2 = sparse(Frac_pO2LHS\Frac_pO2RHS); O2Neg = find(pMatrixSoln_O2<0);
pMatrixSoln_H2S = sparse(Frac_pH2SLHS\Frac_pH2SRHS); H2SNeg = find(pMatrixSoln_H2S<0);

% ERROR TRAPPING - Goal here is to identify whether 'over-reaction' has
% occurred given the time step and reaction rate. In this case, the
% simulation may need to be relaxed in order to come to an acceptable
% solution. 

if sum(abs(CH4Neg))>0
    disp('Negative CH4 Detected - quitting program'); ForceReturn = 1; return
elseif sum(abs(CO2Neg))>0
    disp('Negative CO2  Detected - quitting program'); ForceReturn = 1; return  
elseif sum(abs(H2ONeg))>0
    disp('Negative H2O  Detected - quitting program'); ForceReturn = 1; return
elseif sum(abs(CONeg))>0
    disp('Negative CO  Detected - quitting program'); ForceReturn = 1; return
elseif sum(abs(H2Neg))>0
    disp('Negative H2  Detected - quitting program'); ForceReturn = 1; return
end

% Species concentrations are saved to memory. 
pMatrixFrac_CH4(c,:,k) = pMatrixSoln_CH4(1:j,1);
pMatrixFrac_CO2(c,:,k) = pMatrixSoln_CO2(1:j,1); 
pMatrixFrac_H2O(c,:,k) = pMatrixSoln_H2O(1:j,1); 
pMatrixFrac_CO(c,:,k) = pMatrixSoln_CO(1:j,1); 
pMatrixFrac_H2(c,:,k) = pMatrixSoln_H2(1:j,1); 
pMatrixFrac_N2(c,:,k) = pMatrixSoln_N2(1:j,1); 
pMatrixFrac_O2(c,:,k) = pMatrixSoln_O2(1:j,1); 
pMatrixFrac_H2S(c,:,k) = pMatrixSoln_H2S(1:j,1); 

pMatrixFrac_ALL(c,:,k) = pMatrixFrac_CH4(c,:,k) + pMatrixFrac_CO2(c,:,k) + ...
    pMatrixFrac_H2O(c,:,k) + pMatrixFrac_CO(c,:,k) + pMatrixFrac_H2(c,:,k) + ...
    pMatrixFrac_N2(c,:,k) + pMatrixFrac_O2(c,:,k) + pMatrixFrac_H2S(c,:,k);

% The mean molecular weight across the whole domain is calculated. 
pMasstoMol = pMatrixFrac_CH4(c,:,k)./mCH4 + pMatrixFrac_CO2(c,:,k)./mCO2 + ...
    pMatrixFrac_H2O(c,:,k)./mH2O + pMatrixFrac_CO(c,:,k)./mCO + ...
    pMatrixFrac_H2(c,:,k)./mH2 + pMatrixFrac_N2(c,:,k)./mN2 + ...
    pMatrixFrac_O2(c,:,k)./mO2 + pMatrixFrac_H2S(c,:,k)./mH2S; pMoltoMass = 1./pMasstoMol;

% Mole fractions for each species across the domain are then calculated. 
pMatrixFracM_CH4(c,:,k) = pMatrixFrac_CH4(c,:,k)./(mCH4./pMoltoMass);
pMatrixFracM_CO2(c,:,k) = pMatrixFrac_CO2(c,:,k)./(mCO2./pMoltoMass); 
pMatrixFracM_H2O(c,:,k) = pMatrixFrac_H2O(c,:,k)./(mH2O./pMoltoMass); 
pMatrixFracM_CO(c,:,k) = pMatrixFrac_CO(c,:,k)./(mCO./pMoltoMass); 
pMatrixFracM_H2(c,:,k) = pMatrixFrac_H2(c,:,k)./(mH2./pMoltoMass); 
pMatrixFracM_N2(c,:,k) = pMatrixFrac_N2(c,:,k)./(mN2./pMoltoMass); 
pMatrixFracM_O2(c,:,k) = pMatrixFrac_O2(c,:,k)./(mO2./pMoltoMass); 
pMatrixFracM_H2S(c,:,k) = pMatrixFrac_H2S(c,:,k)./(mH2S./pMoltoMass); 
pMatrixFracM_ALL(c,:,k) = pMatrixFracM_CH4(c,:,k) + pMatrixFracM_CO2(c,:,k) + ...
    pMatrixFracM_H2O(c,:,k) + pMatrixFracM_CO(c,:,k) + pMatrixFracM_H2(c,:,k) + ...
    pMatrixFracM_N2(c,:,k) + pMatrixFracM_O2(c,:,k) + pMatrixFracM_H2S(c,:,k);

% Considering the surface boundary (see Tutorial D for details), the
% catalyst surface is approximated based on the values of the two cells
% closest to the surface. 

% Approximation of surface composition using the pellet. 
Ts(c,1) = 1.5.*pMatrixTemp(c,j,k)-0.5.*pMatrixTemp(c,j-1,k); sMatrixTemp(c,k) = Ts(c,1);

rc = 0.0;   % Relaxation coefficient is defined for converging on the 
            % catalyst surface concentration. 

% The last iteration's calculation for catalyst surface species
% concentration is saved, while the current one is calculated. 
xsCH4_o(c,1) = xsCH4_c(c,1); xsCH4_n(c,1) = 1.5.*pMatrixSoln_CH4(j,1) -0.5.*pMatrixSoln_CH4(j-1,1); 

% Calculated concentration is then relaxed as needed to allow smooth
% convergence of the algorithm on the true surface concentration value. 
xsCH4_c(c,1) = xsCH4_o(c,1) .* rc + xsCH4_n(c,1) .* (1-rc); 

% Similar calculations are made for all species. 
xsCO2_o(c,1) = xsCO2_c(c,1); xsCO2_n(c,1) = 1.5.*pMatrixSoln_CO2(j,1) -0.5.*pMatrixSoln_CO2(j-1,1); 
xsCO2_c(c,1) = xsCO2_o(c,1) .* rc + xsCO2_n(c,1) .* (1-rc); 
xsH2O_o(c,1) = xsH2O_c(c,1); xsH2O_n(c,1) = 1.5.*pMatrixSoln_H2O(j,1) -0.5.*pMatrixSoln_H2O(j-1,1); 
xsH2O_c(c,1) = xsH2O_o(c,1) .* rc + xsH2O_n(c,1) .* (1-rc); 
xsCO_o(c,1) = xsCO_c(c,1); xsCO_n(c,1) = 1.5.*pMatrixSoln_CO(j,1) -0.5.*pMatrixSoln_CO(j-1,1); 
xsCO_c(c,1) = xsCO_o(c,1) .* rc + xsCO_n(c,1) .* (1-rc); 
xsH2_o(c,1) = xsH2_c(c,1); xsH2_n(c,1) = 1.5.*pMatrixSoln_H2(j,1) -0.5.*pMatrixSoln_H2(j-1,1); 
xsH2_c(c,1) = xsH2_o(c,1) .* rc + xsH2_n(c,1) .* (1-rc); 
xsN2_o(c,1) = xsN2_c(c,1); xsN2_n(c,1) = 1.5.*pMatrixSoln_N2(j,1) -0.5.*pMatrixSoln_N2(j-1,1); 
xsN2_c(c,1) = xsN2_o(c,1) .* rc + xsN2_n(c,1) .* (1-rc); 
xsO2_o(c,1) = xsO2_c(c,1); xsO2_n(c,1) = 1.5.*pMatrixSoln_O2(j,1) -0.5.*pMatrixSoln_O2(j-1,1); 
xsO2_c(c,1) = xsO2_o(c,1) .* rc + xsO2_n(c,1) .* (1-rc); 
xsH2S_o(c,1) = xsH2S_c(c,1); xsH2S_n(c,1) = 1.5.*pMatrixSoln_H2S(j,1) -0.5.*pMatrixSoln_H2S(j-1,1); 
xsH2S_c(c,1) = xsH2S_o(c,1) .* rc + xsH2S_n(c,1) .* (1-rc); 

end 

% Pressure within the pellet is assumed to be constant, as well as equal to
% the concentration within the reactor. 
pMatrixPress(:,:,k) = Pp; 
sMatrixPress(:,k) = Pp(:,j); 

