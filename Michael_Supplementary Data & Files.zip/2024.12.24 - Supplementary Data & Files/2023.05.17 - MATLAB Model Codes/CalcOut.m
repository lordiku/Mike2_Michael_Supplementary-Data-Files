
% Data is recorded to an MS Excel spreadsheet when [CalcOut] is called. 
% Specifically, data relating to the catalyst reactor scale domain is
% recorded. 

% [CalcOut] also manipulates the spreadsheet to allow for parametric data
% to be recorded based on the temperature or H2S increment simulated. 

% Data is retrieved from the simulation. 
MatrixSummary = zeros(cellnum,26);
MatrixSummary(:,1) = rMatrixTemp(:,timestep);       MatrixSummary(:,2) = rMatrixPress(:,timestep); 
MatrixSummary(:,3) = sMatrixTemp(:,timestep);       MatrixSummary(:,4) = rMatrixDens(:,timestep); 
MatrixSummary(:,5) = rMatrixVel(:,timestep);        MatrixSummary(:,6) = rMatrixFracM_CH4(:,timestep);
MatrixSummary(:,7) = rMatrixFracM_CO2(:,timestep);  MatrixSummary(:,8) = rMatrixFracM_H2O(:,timestep);
MatrixSummary(:,9) = rMatrixFracM_CO(:,timestep);   MatrixSummary(:,10) = rMatrixFracM_H2(:,timestep);
MatrixSummary(:,11) = rMatrixFracM_H2S(:,timestep); MatrixSummary(:,12) = rMatrixFracM_N2(:,timestep); 
MatrixSummary(:,13) = rMatrixFracM_O2(:,timestep);  MatrixSummary(:,14) = sCoverage(:,timestep);

MatrixSummary(:,15) = rxn1; MatrixSummary(:,16) = rxn2; MatrixSummary(:,17) = rxn3;
MatrixSummary(:,18) = rMatrixEff(:,timestep,1); MatrixSummary(:,19) = rMatrixEff(:,timestep,2); MatrixSummary(:,20) = rMatrixEff(:,timestep,3); 
%MatrixSummary(:,21) = Qrxn; 
MatrixSummary(:,22) = h; MatrixSummary(:,23) = sMatrixTemp(:,timestep); MatrixSummary(:,24) = Qfilm; 
MatrixSummary(:,25) = U; MatrixSummary(:,26) = Qhxg; 

% Data to be used for the calculation of equilibrium compositions
% throughout the reactor is retrieved below. Note that hydrogen sulfide is
% excluded from this calculation as it is a minor component; its inclusion
% would require addition of the element "sulfur" to the calculation in
% order to account for a species amounting to ~0.01% mol fraction. A large
% increase in computational effort is required for a small gain in
% precision of calculation. See Tutorial B in the thesis for details. 

Teq = rMatrixTemp(:,1); Peq = rMatrixPress(:,1);
xMCH4eq = rMatrixFracM_CH4(:,1); xMCO2eq = rMatrixFracM_CO2(:,1);
xMH2Oeq = rMatrixFracM_H2O(:,1); xMCOeq = rMatrixFracM_CO(:,1); 
xMH2eq = rMatrixFracM_H2(:,1); xMN2eq = rMatrixFracM_N2(:,1);
xMO2eq = rMatrixFracM_O2(:,1);

EqComp = zeros(cellnum,7);

% Gibbs free energy minimization, using the Lagrange multiplier approach,
% is used to calculate equilibrium compositions at every point within the
% reactor. This is done for each cell within the reactor domain. 

for i = 1:cellnum

    EqCompTemp =  GibbsEq(Peq(i,1),Teq(i,1),xMCH4eq(i,1), xMCO2eq(i,1), xMH2Oeq(i,1), xMCOeq(i,1), xMH2eq(i,1), xMN2eq(i,1), xMO2eq(i,1));
    EqComp(i,:) = EqCompTemp.';
    
end

% Simulation data is printed to a temporary Excel sheet called "DataDump"
% where it can then be moved into different spreadsheets depending on need.

% Placement of data within the spreadsheet is determined based on the
% current iteration through "WriteData"; column positions are manually
% set based on the number of variables to be reported. The cell center
% value of each variable to be reported is recorded. 
xlsrow = num2str(WriteData*(cellnum+5)+5);
SimData = strcat('B',xlsrow);
EqbData = strcat('AD',xlsrow);

% Navigation of the spreadsheet is done via a "switch-case" structure based
% on the H2S and temperature cases being ran. Generally, H2S will be
% recorded in individual workbooks, while temperature will be recorded
% in individual spreadsheets. The command "writematrix" then instructs
% MATLAB to record the information to MS Excel in the appropriate spot.
% Both simulated and equilibrium data are recorded. 

switch H2SParam
    case 1
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary,'DataDump0.xlsx','Sheet',1,'Range',SimData);
                writematrix(EqComp,'DataDump0.xlsx','Sheet',1,'Range',EqbData);
            case 2 % 1023 K
                writematrix(MatrixSummary,'DataDump0.xlsx','Sheet',2,'Range',SimData);
                writematrix(EqComp,'DataDump0.xlsx','Sheet',2,'Range',EqbData);
            case 3 % 1073 K
                writematrix(MatrixSummary,'DataDump0.xlsx','Sheet',3,'Range',SimData);
                writematrix(EqComp,'DataDump0.xlsx','Sheet',3,'Range',EqbData);
            case 4 % 1123 K
                writematrix(MatrixSummary,'DataDump0.xlsx','Sheet',4,'Range',SimData);
                writematrix(EqComp,'DataDump0.xlsx','Sheet',4,'Range',EqbData);
            case 5 % 1173 K
                writematrix(MatrixSummary,'DataDump0.xlsx','Sheet',5,'Range',SimData);
                writematrix(EqComp,'DataDump0.xlsx','Sheet',5,'Range',EqbData);
            case 6 % 1223 K
                writematrix(MatrixSummary,'DataDump0.xlsx','Sheet',6,'Range',SimData);
                writematrix(EqComp,'DataDump0.xlsx','Sheet',6,'Range',EqbData);
            case 7 % 1273 K
                writematrix(MatrixSummary,'DataDump0.xlsx','Sheet',7,'Range',SimData);
                writematrix(EqComp,'DataDump0.xlsx','Sheet',7,'Range',EqbData);
            case 8 % 1323 K
                writematrix(MatrixSummary,'DataDump0.xlsx','Sheet',8,'Range',SimData);
                writematrix(EqComp,'DataDump0.xlsx','Sheet',8,'Range',EqbData);
            case 9 % 1373 K
                writematrix(MatrixSummary,'DataDump0.xlsx','Sheet',9,'Range',SimData);
                writematrix(EqComp,'DataDump0.xlsx','Sheet',9,'Range',EqbData);
        end
    case 2
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary,'DataDump25.xlsx','Sheet',1,'Range',SimData);
                writematrix(EqComp,'DataDump25.xlsx','Sheet',1,'Range',EqbData);
            case 2 % 1023 K
                writematrix(MatrixSummary,'DataDump25.xlsx','Sheet',2,'Range',SimData);
                writematrix(EqComp,'DataDump25.xlsx','Sheet',2,'Range',EqbData);
            case 3 % 1073 K
                writematrix(MatrixSummary,'DataDump25.xlsx','Sheet',3,'Range',SimData);
                writematrix(EqComp,'DataDump25.xlsx','Sheet',3,'Range',EqbData);
            case 4 % 1123 K
                writematrix(MatrixSummary,'DataDump25.xlsx','Sheet',4,'Range',SimData);
                writematrix(EqComp,'DataDump25.xlsx','Sheet',4,'Range',EqbData);
            case 5 % 1173 K
                writematrix(MatrixSummary,'DataDump25.xlsx','Sheet',5,'Range',SimData);
                writematrix(EqComp,'DataDump25.xlsx','Sheet',5,'Range',EqbData);
            case 6 % 1223 K
                writematrix(MatrixSummary,'DataDump25.xlsx','Sheet',6,'Range',SimData);
                writematrix(EqComp,'DataDump25.xlsx','Sheet',6,'Range',EqbData);
            case 7 % 1273 K
                writematrix(MatrixSummary,'DataDump25.xlsx','Sheet',7,'Range',SimData);
                writematrix(EqComp,'DataDump25.xlsx','Sheet',7,'Range',EqbData);
            case 8 % 1323 K
                writematrix(MatrixSummary,'DataDump25.xlsx','Sheet',8,'Range',SimData);
                writematrix(EqComp,'DataDump25.xlsx','Sheet',8,'Range',EqbData);
            case 9 % 1373 K
                writematrix(MatrixSummary,'DataDump25.xlsx','Sheet',9,'Range',SimData);
                writematrix(EqComp,'DataDump25.xlsx','Sheet',9,'Range',EqbData);
        end
    case 3
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary,'DataDump50.xlsx','Sheet',1,'Range',SimData);
                writematrix(EqComp,'DataDump50.xlsx','Sheet',1,'Range',EqbData);
            case 2 % 1023 K
                writematrix(MatrixSummary,'DataDump50.xlsx','Sheet',2,'Range',SimData);
                writematrix(EqComp,'DataDump50.xlsx','Sheet',2,'Range',EqbData);
            case 3 % 1073 K
                writematrix(MatrixSummary,'DataDump50.xlsx','Sheet',3,'Range',SimData);
                writematrix(EqComp,'DataDump50.xlsx','Sheet',3,'Range',EqbData);
            case 4 % 1123 K
                writematrix(MatrixSummary,'DataDump50.xlsx','Sheet',4,'Range',SimData);
                writematrix(EqComp,'DataDump50.xlsx','Sheet',4,'Range',EqbData);
            case 5 % 1173 K
                writematrix(MatrixSummary,'DataDump50.xlsx','Sheet',5,'Range',SimData);
                writematrix(EqComp,'DataDump50.xlsx','Sheet',5,'Range',EqbData);
            case 6 % 1223 K
                writematrix(MatrixSummary,'DataDump50.xlsx','Sheet',6,'Range',SimData);
                writematrix(EqComp,'DataDump50.xlsx','Sheet',6,'Range',EqbData);
            case 7 % 1273 K
                writematrix(MatrixSummary,'DataDump50.xlsx','Sheet',7,'Range',SimData);
                writematrix(EqComp,'DataDump50.xlsx','Sheet',7,'Range',EqbData);
            case 8 % 1323 K
                writematrix(MatrixSummary,'DataDump50.xlsx','Sheet',8,'Range',SimData);
                writematrix(EqComp,'DataDump50.xlsx','Sheet',8,'Range',EqbData);
            case 9 % 1373 K
                writematrix(MatrixSummary,'DataDump50.xlsx','Sheet',9,'Range',SimData);
                writematrix(EqComp,'DataDump50.xlsx','Sheet',9,'Range',EqbData);
        end
    case 4
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary,'DataDump100.xlsx','Sheet',1,'Range',SimData);
                writematrix(EqComp,'DataDump100.xlsx','Sheet',1,'Range',EqbData);
            case 2 % 1023 K
                writematrix(MatrixSummary,'DataDump100.xlsx','Sheet',2,'Range',SimData);
                writematrix(EqComp,'DataDump100.xlsx','Sheet',2,'Range',EqbData);
            case 3 % 1073 K
                writematrix(MatrixSummary,'DataDump100.xlsx','Sheet',3,'Range',SimData);
                writematrix(EqComp,'DataDump100.xlsx','Sheet',3,'Range',EqbData);
            case 4 % 1123 K
                writematrix(MatrixSummary,'DataDump100.xlsx','Sheet',4,'Range',SimData);
                writematrix(EqComp,'DataDump100.xlsx','Sheet',4,'Range',EqbData);
            case 5 % 1173 K
                writematrix(MatrixSummary,'DataDump100.xlsx','Sheet',5,'Range',SimData);
                writematrix(EqComp,'DataDump100.xlsx','Sheet',5,'Range',EqbData);
            case 6 % 1223 K
                writematrix(MatrixSummary,'DataDump100.xlsx','Sheet',6,'Range',SimData);
                writematrix(EqComp,'DataDump100.xlsx','Sheet',6,'Range',EqbData);
            case 7 % 1273 K
                writematrix(MatrixSummary,'DataDump100.xlsx','Sheet',7,'Range',SimData);
                writematrix(EqComp,'DataDump100.xlsx','Sheet',7,'Range',EqbData);
            case 8 % 1323 K
                writematrix(MatrixSummary,'DataDump100.xlsx','Sheet',8,'Range',SimData);
                writematrix(EqComp,'DataDump100.xlsx','Sheet',8,'Range',EqbData);
            case 9 % 1373 K
                writematrix(MatrixSummary,'DataDump100.xlsx','Sheet',9,'Range',SimData);
                writematrix(EqComp,'DataDump100.xlsx','Sheet',9,'Range',EqbData);
        end
    case 5
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary,'DataDump200.xlsx','Sheet',1,'Range',SimData);
                writematrix(EqComp,'DataDump200.xlsx','Sheet',1,'Range',EqbData);
            case 2 % 1023 K
                writematrix(MatrixSummary,'DataDump200.xlsx','Sheet',2,'Range',SimData);
                writematrix(EqComp,'DataDump200.xlsx','Sheet',2,'Range',EqbData);
            case 3 % 1073 K
                writematrix(MatrixSummary,'DataDump200.xlsx','Sheet',3,'Range',SimData);
                writematrix(EqComp,'DataDump200.xlsx','Sheet',3,'Range',EqbData);
            case 4 % 1123 K
                writematrix(MatrixSummary,'DataDump200.xlsx','Sheet',4,'Range',SimData);
                writematrix(EqComp,'DataDump200.xlsx','Sheet',4,'Range',EqbData);
            case 5 % 1173 K
                writematrix(MatrixSummary,'DataDump200.xlsx','Sheet',5,'Range',SimData);
                writematrix(EqComp,'DataDump200.xlsx','Sheet',5,'Range',EqbData);
            case 6 % 1223 K
                writematrix(MatrixSummary,'DataDump200.xlsx','Sheet',6,'Range',SimData);
                writematrix(EqComp,'DataDump200.xlsx','Sheet',6,'Range',EqbData);
            case 7 % 1273 K
                writematrix(MatrixSummary,'DataDump200.xlsx','Sheet',7,'Range',SimData);
                writematrix(EqComp,'DataDump200.xlsx','Sheet',7,'Range',EqbData);
            case 8 % 1323 K
                writematrix(MatrixSummary,'DataDump200.xlsx','Sheet',8,'Range',SimData);
                writematrix(EqComp,'DataDump200.xlsx','Sheet',8,'Range',EqbData);
            case 9 % 1373 K
                writematrix(MatrixSummary,'DataDump200.xlsx','Sheet',9,'Range',SimData);
                writematrix(EqComp,'DataDump200.xlsx','Sheet',9,'Range',EqbData);
        end
    case 6
        switch TempParam 
            case 1 % 973 K
                writematrix(MatrixSummary,'DataDump300.xlsx','Sheet',1,'Range',SimData);
                writematrix(EqComp,'DataDump300.xlsx','Sheet',1,'Range',EqbData);
            case 2 % 1023 K
                writematrix(MatrixSummary,'DataDump300.xlsx','Sheet',2,'Range',SimData);
                writematrix(EqComp,'DataDump300.xlsx','Sheet',2,'Range',EqbData);
            case 3 % 1073 K
                writematrix(MatrixSummary,'DataDump300.xlsx','Sheet',3,'Range',SimData);
                writematrix(EqComp,'DataDump300.xlsx','Sheet',3,'Range',EqbData);
            case 4 % 1123 K
                writematrix(MatrixSummary,'DataDump300.xlsx','Sheet',4,'Range',SimData);
                writematrix(EqComp,'DataDump300.xlsx','Sheet',4,'Range',EqbData);
            case 5 % 1173 K
                writematrix(MatrixSummary,'DataDump300.xlsx','Sheet',5,'Range',SimData);
                writematrix(EqComp,'DataDump300.xlsx','Sheet',5,'Range',EqbData);
            case 6 % 1223 K
                writematrix(MatrixSummary,'DataDump300.xlsx','Sheet',6,'Range',SimData);
                writematrix(EqComp,'DataDump300.xlsx','Sheet',6,'Range',EqbData);
            case 7 % 1273 K
                writematrix(MatrixSummary,'DataDump300.xlsx','Sheet',7,'Range',SimData);
                writematrix(EqComp,'DataDump300.xlsx','Sheet',7,'Range',EqbData);
            case 8 % 1323 K
                writematrix(MatrixSummary,'DataDump300.xlsx','Sheet',8,'Range',SimData);
                writematrix(EqComp,'DataDump300.xlsx','Sheet',8,'Range',EqbData);
            case 9 % 1373 K
                writematrix(MatrixSummary,'DataDump300.xlsx','Sheet',9,'Range',SimData);
                writematrix(EqComp,'DataDump300.xlsx','Sheet',9,'Range',EqbData);
        end
end

% The data writing iteration is incremented forward by 1. Note that
% "WriteData" is iterated based on the number of times "CalcOut" is called,
% not necessarily based on the temperature, H2S, or time increments. 
WriteData = WriteData + 1;
