function dH = H_Calc(T,i)

    % Calculates the heat of reaction for a given reforming reaction. 
    % Returns the heat as kJ/mol.
    
    % The calculation is made on the basis of Kirchoff's law. 
    % I.e. H(T) = H(298K) + Int(T, 298)(CpdT). 
    % Where Cp(T) is usually a polynomial, it's typical to calculate this
    % integrated polynomial first, and just consider the change in
    % temperature to find the change in enthalpy for the reaction. 

    % Specific Heat Capacity coefficients, from Elliot & Lira.
    % CH4, CO2, H2O, CO, H2
    Coeff = [   19.25   5.213E-02    1.197E-05   -1.132E-08
                19.80   7.344E-02   -5.602E-05    1.715E-08        
                32.24   1.924E-03    1.055E-05   -3.596E-09
                30.87  -1.285E-02    2.789E-05   -1.272E-08
                27.14   9.274E-03   -1.381E-05    7.645E-09];

    % Enthalpies of formation, CH4, CO2, H2O, CO, H2
    Form = [    -074.893
                -393.510
                -241.835
                -110.530
                0];
            
    Tr = 298; % Reference Temperature, 298 K.
    
switch i
    case 1  % Steam Reforming, CH4 + H2O --> CO + 3H2
    da = Coeff(4,1) + 3 * Coeff(5,1) - Coeff(1,1) - Coeff(3,1);
    db = Coeff(4,2) + 3 * Coeff(5,2) - Coeff(1,2) - Coeff(3,2);
    dc = Coeff(4,3) + 3 * Coeff(5,3) - Coeff(1,3) - Coeff(3,3);
    dd = Coeff(4,4) + 3 * Coeff(5,4) - Coeff(1,4) - Coeff(3,4);
    dH_s = Form(4,1) + 3 * Form(5,1) - Form(1,1) - Form(3,1);
    dH = ((da.*(T-Tr) + db./2.*(T-Tr).^2 + dc./3.*(T-Tr).^3 + dd./4.*(T-Tr).^4))./1000 + dH_s;
    
    case 2  % Water Gas Shift, CO + H2O --> CO2 + H2
    da = Coeff(2,1) + Coeff(5,1) - Coeff(4,1) - Coeff(3,1);
    db = Coeff(2,2) + Coeff(5,2) - Coeff(4,2) - Coeff(3,2);
    dc = Coeff(2,3) + Coeff(5,3) - Coeff(4,3) - Coeff(3,3);
    dd = Coeff(2,4) + Coeff(5,4) - Coeff(4,4) - Coeff(3,4);
    dH_s = Form(2,1) + Form(5,1) - Form(4,1) - Form(3,1);
    dH = ((da.*(T-Tr) + db./2.*(T-Tr).^2 + dc./3.*(T-Tr).^3 + dd./4.*(T-Tr).^4))./1000 + dH_s;
       
    case 3  % Steam Reforming, CH4 + 2H2O --> CO2 + 4H2
    da = Coeff(2,1) + 4 * Coeff(5,1) - Coeff(1,1) - 2 * Coeff(3,1);
    db = Coeff(2,2) + 4 * Coeff(5,2) - Coeff(1,2) - 2 * Coeff(3,2);
    dc = Coeff(2,3) + 4 * Coeff(5,3) - Coeff(1,3) - 2 * Coeff(3,3);
    dd = Coeff(2,4) + 4 * Coeff(5,4) - Coeff(1,4) - 2 * Coeff(3,4);
    dH_s = Form(2,1) + 4 * Form(5,1) - Form(1,1) - 2 * Form(3,1);
    dH = ((da.*(T-Tr) + db./2.*(T-Tr).^2 + dc./3.*(T-Tr).^3 + dd./4.*(T-Tr).^4))./1000 + dH_s;
end 
end