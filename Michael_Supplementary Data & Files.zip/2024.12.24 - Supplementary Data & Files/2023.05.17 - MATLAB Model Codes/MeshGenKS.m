
% Geometry within the reactor is specified. 

% d_t - Inner diameter of tube; d_p - diameter of particle. Meters, m. 
% From Koningen & Sjostrom (1998). 
d_t = 0.015; d_to = 0.016; d_p = 0.00105; 

% Acs - Cross-sectional area of the tube. Square meters, m^2.
Acs = pi*(d_t/2)^2;

% eps - porosity of the packed bed. Dixon (1988) is used here.
% Calculates as percentage void space (%). 
eps = 0.4 + 0.05*d_p/d_t + 0.412*(d_p/d_t)^2;

rho_s = 2239; % rho_s - Catalyst solid density. kg/m^3
Cp_s = 0.85; % Cp_s - Catalyst solid heat capacity. kJ/kg.K

AdCap_H2S = 1500*10^-10; % ppm - Catalyst sulphur capacity, ppm by mass. 

uz_i = 0.101;       % inlet velocity, m/s
L = 0.0638;         % Length of the reactor, in meters.
Truns = 50000;      % Number of runs, accumulates time. Multiply against [t] for
                    % total time. 
t = 1;              % Time of simulation run, in seconds. Defined. 

% cellnum - number of cells defined within the one-dimensional domain. 
% dz - discrete length of each cell defined within the domain. In this
% simulation, the mesh is defined to be uniform.

% dt - discrete time step desired, in seconds. 
% timestep - number of timesteps required, based on the discrete time step
% desired as well as the total length of time simulated. NOTE that there
% are stability considerations when setting dz and dt. 

% facenum - number of faces defined within the one-dimensional domain. 
% MeshFace - matrix that stores the axial location of each face centroid. 
% MeshCell - matrix that stores the axial locatoin of each cell centroid. 

cellnum = 50; dz = L/cellnum;
dt = 0.01; timestep = t/dt; 

facenum = cellnum + 1;
MeshFace = zeros(facenum,2); 
MeshCell = zeros(cellnum,2);
graphcount = 0; WriteData = 0;

% The mesh is generated iteratively, based on the number of desired cells
% and the length defined for the domain. Face and cell center positions
% are defined for the mesh. 

for i = 1:cellnum
    
    MeshFace(1+i,1) = 1+i;
    MeshFace(1+i,2) = MeshFace(i,2) + L / cellnum;
    MeshCell(i,1) = i;
    MeshCell(i,2) = MeshFace(i,2) + (MeshFace(1+i,2) - MeshFace(i,2))/2;
    
end

%%
% Particle Mesh

% Pellet porosity, tortuosity, and mean pore radius are specified. 
eps_p = 0.500; tort_p = 3.5;
rp = 100*10^-9; %in meters

% partnum - number of cells defined within the one-dimensional domain. 
% drp - discrete length of each cell defined within the domain. In this
% simulation, the mesh is defined to be uniform. 

% partface- number of faces defined within the one-dimensional domain. 
% pMeshFace - matrix that stores the radial location of each face centroid. 
% pMeshCell - matrix that stores the radial locatoin of each cell centroid. 

partnum = 20; drp = d_p/2/partnum;

partface = partnum + 1;
pMeshCell = zeros(partnum,2); 
pMeshFace = zeros(partface,2);

pMeshFace(1,1) = 1; pMeshFace(1,2) = 0;

% The mesh is generated iteratively, based on the number of desired cells
% and the length defined for the domain. Face and cell center positions
% are defined for the mesh. Note that the domain is established for a
% "typical" pellet to be located at the center of each cell within the
% reactor computational domain. 

for i = 1:partnum
    
    pMeshFace(cellnum,1+i,1) = 1+i;
    pMeshFace(cellnum,1+i,2) = pMeshFace(i,2) + d_p/2 / partnum;
    pMeshCell(cellnum,i,1) = i;
    pMeshCell(cellnum,i,2) = pMeshFace(i,2) + (pMeshFace(1+i,2) - pMeshFace(i,2))/2;
    
end

