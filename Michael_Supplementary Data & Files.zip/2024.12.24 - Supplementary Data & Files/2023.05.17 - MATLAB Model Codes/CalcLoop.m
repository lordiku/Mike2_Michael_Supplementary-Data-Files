
% [CalcLoop] is called to move simulation data recorded for the current
% timestep "k" to the memory position containing the reactor's initial
% conditions. This is done to allow continuity of the simulation while
% avoiding consumption of very large amounts of memory during long-term
% simulations (otherwise fine-grained time increments combined with longer
% simulations would overwhelm the computer's memory). 

% "kt" is used to determine the number of "zero" columns that will need to
% be inserted to maintain the same size of matrix with respect to the
% number of time increments considered per "run". 
kt = timestep - 1;

% Reactor domain cell center data is transferred. 
P = cat(2,rMatrixPress(:,k),zeros(cellnum,kt));         rMatrixPress(:,:) = P;
T = cat(2,rMatrixTemp(:,k),zeros(cellnum,kt));          rMatrixTemp(:,:) = T;
xCH4 = cat(2,rMatrixFrac_CH4(:,k),zeros(cellnum,kt));   rMatrixFrac_CH4(:,:) = xCH4;
xCO2 = cat(2,rMatrixFrac_CO2(:,k),zeros(cellnum,kt));   rMatrixFrac_CO2(:,:) = xCO2;
xH2O = cat(2,rMatrixFrac_H2O(:,k),zeros(cellnum,kt));   rMatrixFrac_H2O(:,:) = xH2O;
xCO = cat(2,rMatrixFrac_CO(:,k),zeros(cellnum,kt));     rMatrixFrac_CO(:,:) = xCO;
xH2 = cat(2,rMatrixFrac_H2(:,k),zeros(cellnum,kt));     rMatrixFrac_H2(:,:) = xH2;
xN2 = cat(2,rMatrixFrac_N2(:,k),zeros(cellnum,kt));     rMatrixFrac_N2(:,:) = xN2;
xO2 = cat(2,rMatrixFrac_O2(:,k),zeros(cellnum,kt));     rMatrixFrac_O2(:,:) = xO2;
xH2S = cat(2,rMatrixFrac_H2S(:,k),zeros(cellnum,kt));   rMatrixFrac_H2S(:,:) = xH2S;
xMCH4 = cat(2,rMatrixFracM_CH4(:,k),zeros(cellnum,kt)); rMatrixFracM_CH4(:,:) = xMCH4;
xMCO2 = cat(2,rMatrixFracM_CO2(:,k),zeros(cellnum,kt)); rMatrixFracM_CO2(:,:) = xMCO2;
xMH2O = cat(2,rMatrixFracM_H2O(:,k),zeros(cellnum,kt)); rMatrixFracM_H2O(:,:) = xMH2O;
xMCO = cat(2,rMatrixFracM_CO(:,k),zeros(cellnum,kt));   rMatrixFracM_CO(:,:) = xMCO;
xMH2 = cat(2,rMatrixFracM_H2(:,k),zeros(cellnum,kt));   rMatrixFracM_H2(:,:) = xMH2;
xMN2 = cat(2,rMatrixFracM_N2(:,k),zeros(cellnum,kt));   rMatrixFracM_N2(:,:) = xMN2;
xMO2 = cat(2,rMatrixFracM_O2(:,k),zeros(cellnum,kt));   rMatrixFracM_O2(:,:) = xMO2;
xMH2S = cat(2,rMatrixFracM_H2S(:,k),zeros(cellnum,kt)); rMatrixFracM_H2S(:,:) = xMH2S;

rho = cat(2,rMatrixDens(:,k),zeros(cellnum,kt));        rMatrixDens(:,:) = rho;
cond = cat(2,rMatrix_cond(:,k),zeros(cellnum,kt));      rMatrix_cond(:,:) = cond;
Cp = cat(2,rMatrixCp(:,k),zeros(cellnum,kt));           rMatrixCp(:,:) = Cp;
mu = cat(2,rMatrix_Mu(:,k),zeros(cellnum,kt));          rMatrix_Mu(:,:) = mu;
rhoM = cat(2,rMatrixDensM(:,k),zeros(cellnum,kt));      rMatrixDensM(:,:) = rhoM;

% Reactor domain cell face data is transferred. 
Pf = cat(2,rMeshPress(:,k),zeros(facenum,kt));          rMeshPress(:,:) = Pf;
Tf = cat(2,rMeshTemp(:,k),zeros(facenum,kt));           rMeshTemp(:,:) = Tf;
xCH4f = cat(2,rMeshFrac_CH4(:,k),zeros(facenum,kt));    rMeshFrac_CH4(:,:) = xCH4f;
xCO2f = cat(2,rMeshFrac_CO2(:,k),zeros(facenum,kt));    rMeshFrac_CO2(:,:) = xCO2f;
xH2Of = cat(2,rMeshFrac_H2O(:,k),zeros(facenum,kt));    rMeshFrac_H2O(:,:) = xH2Of;
xCOf = cat(2,rMeshFrac_CO(:,k),zeros(facenum,kt));      rMeshFrac_CO(:,:) = xCOf;
xH2f = cat(2,rMeshFrac_H2(:,k),zeros(facenum,kt));      rMeshFrac_H2(:,:) = xH2f;
xN2f = cat(2,rMeshFrac_N2(:,k),zeros(facenum,kt));      rMeshFrac_N2(:,:) = xN2f;
xO2f = cat(2,rMeshFrac_O2(:,k),zeros(facenum,kt));      rMeshFrac_O2(:,:) = xO2f;
xH2Sf = cat(2,rMeshFrac_H2S(:,k),zeros(facenum,kt));    rMeshFrac_H2S(:,:) = xH2Sf;
xMCH4f = cat(2,rMeshFracM_CH4(:,k),zeros(facenum,kt));  rMeshFracM_CH4(:,:) = xMCH4f;
xMCO2f = cat(2,rMeshFracM_CO2(:,k),zeros(facenum,kt));  rMeshFracM_CO2(:,:) = xMCO2f;
xMH2Of = cat(2,rMeshFracM_H2O(:,k),zeros(facenum,kt));  rMeshFracM_H2O(:,:) = xMH2Of;
xMCOf = cat(2,rMeshFracM_CO(:,k),zeros(facenum,kt));    rMeshFracM_CO(:,:) = xMCOf;
xMH2f = cat(2,rMeshFracM_H2(:,k),zeros(facenum,kt));    rMeshFracM_H2(:,:) = xMH2f;
xMN2f = cat(2,rMeshFracM_N2(:,k),zeros(facenum,kt));    rMeshFracM_N2(:,:) = xMN2f;
xMO2f = cat(2,rMeshFracM_O2(:,k),zeros(facenum,kt));    rMeshFracM_O2(:,:) = xMO2f;
xMH2Sf = cat(2,rMeshFracM_H2S(:,k),zeros(facenum,kt));  rMeshFracM_H2S(:,:) = xMH2Sf;

muFace = cat(2,rMesh_mu(:,k),zeros(facenum,kt));        rMesh_mu(:,:) = muFace;
condFace = cat(2,rMesh_cond(:,k),zeros(facenum,kt));    rMesh_cond(:,:) = condFace;
CpFace = cat(2,rMeshCp(:,k),zeros(facenum,kt));         rMeshCp(:,:) = CpFace;
DensFace = cat(2,rMeshDens(:,k),zeros(facenum,kt));     rMeshDens(:,:) = DensFace;
DensFaceM = cat(2,rMeshDensM(:,k),zeros(facenum,kt));   rMeshDensM(:,:) = DensFaceM;

rDCH4 = cat(2,rMesh_DCH4(:,k),zeros(facenum,kt));       rMesh_DCH4(:,:) = rDCH4;
rDCO2 = cat(2,rMesh_DCO2(:,k),zeros(facenum,kt));       rMesh_DCO2(:,:) = rDCO2;
rDH2O = cat(2,rMesh_DH2O(:,k),zeros(facenum,kt));       rMesh_DH2O(:,:) = rDH2O;
rDCO = cat(2,rMesh_DCO(:,k),zeros(facenum,kt));         rMesh_DCO(:,:) = rDCO;
rDH2 = cat(2,rMesh_DH2(:,k),zeros(facenum,kt));         rMesh_DH2(:,:) = rDH2;
rDN2 = cat(2,rMesh_DN2(:,k),zeros(facenum,kt));         rMesh_DN2(:,:) = rDN2;
rDO2 = cat(2,rMesh_DO2(:,k),zeros(facenum,kt));         rMesh_DO2(:,:) = rDO2;
rDH2S = cat(2,rMesh_DH2S(:,k),zeros(facenum,kt));       rMesh_DH2S(:,:) = rDH2S;

% Hydrogen sulfide data is transferred. 
H2S_Sat = cat(2,wsat_H2S(:,k),zeros(cellnum,kt));       wsat_H2S(:,:) = H2S_Sat;
H2S_Ads = cat(2,ws_H2S(:,k),zeros(cellnum,kt));         ws_H2S(:,:) = H2S_Ads;
H2S_Cov = cat(2,sCoverage(:,k),zeros(cellnum,kt));      sCoverage(:,:) = H2S_Cov;

% Reactor gas-phase velocity data is transferred. 
rMatrixVel(:,1) = rMatrixVel(:,k); rMeshVel(:,1) = rMeshVel(:,k);

% Catalyst surface data is transferred. 
Ps = cat(2,sMatrixPress(:,k),zeros(cellnum,kt));        sMatrixPress(:,:) = Ps;
Ts = cat(2,sMatrixTemp(:,k),zeros(cellnum,kt));         sMatrixTemp(:,:) = Ts;
xsCH4 = cat(2,sMatrixFrac_CH4(:,k),zeros(cellnum,kt));  sMatrixFrac_CH4(:,:) = xsCH4;
xsCO2 = cat(2,sMatrixFrac_CO2(:,k),zeros(cellnum,kt));  sMatrixFrac_CO2(:,:) = xsCO2;
xsH2O = cat(2,sMatrixFrac_H2O(:,k),zeros(cellnum,kt));  sMatrixFrac_H2O(:,:) = xsH2O;
xsCO = cat(2,sMatrixFrac_CO(:,k),zeros(cellnum,kt));    sMatrixFrac_CO(:,:) = xsCO;
xsH2 = cat(2,sMatrixFrac_H2(:,k),zeros(cellnum,kt));    sMatrixFrac_H2(:,:) = xsH2;
xsN2 = cat(2,sMatrixFrac_N2(:,k),zeros(cellnum,kt));    sMatrixFrac_N2(:,:) = xsN2;
xsO2 = cat(2,sMatrixFrac_O2(:,k),zeros(cellnum,kt));    sMatrixFrac_O2(:,:) = xsO2;
xsH2S = cat(2,sMatrixFrac_H2S(:,k),zeros(cellnum,kt));  sMatrixFrac_H2S(:,:) = xsH2S;
xsMCH4 = cat(2,sMatrixFracM_CH4(:,k),zeros(cellnum,kt)); sMatrixFracM_CH4(:,:) = xsMCH4;
xsMCO2 = cat(2,sMatrixFracM_CO2(:,k),zeros(cellnum,kt)); sMatrixFracM_CO2(:,:) = xsMCO2;
xsMH2O = cat(2,sMatrixFracM_H2O(:,k),zeros(cellnum,kt)); sMatrixFracM_H2O(:,:) = xsMH2O;
xsMCO = cat(2,sMatrixFracM_CO(:,k),zeros(cellnum,kt));  sMatrixFracM_CO(:,:) = xsMCO;
xsMH2 = cat(2,sMatrixFracM_H2(:,k),zeros(cellnum,kt));  sMatrixFracM_H2(:,:) = xsMH2;
xsMN2 = cat(2,sMatrixFracM_N2(:,k),zeros(cellnum,kt));  sMatrixFracM_N2(:,:) = xsMN2;
xsMO2 = cat(2,sMatrixFracM_O2(:,k),zeros(cellnum,kt));  sMatrixFracM_O2(:,:) = xsMO2;
xsMH2S = cat(2,sMatrixFracM_H2S(:,k),zeros(cellnum,kt)); sMatrixFracM_H2S(:,:) = xsMH2S;

srho = cat(2,sMatrixDens(:,k),zeros(cellnum,kt));       sMatrixDens(:,:) = srho;
s_rxn1 = cat(2,sMatrixRXN(:,k,1),zeros(cellnum,kt));    sMatrixRXN(:,:,1) = s_rxn1;
s_rxn2 = cat(2,sMatrixRXN(:,k,2),zeros(cellnum,kt));    sMatrixRXN(:,:,2) = s_rxn2;
s_rxn3 = cat(2,sMatrixRXN(:,k,3),zeros(cellnum,kt));    sMatrixRXN(:,:,3) = s_rxn3;

% Catalyst pellet cell center data is transferred. 
Pp = cat(3,pMatrixPress(:,:,k),zeros(cellnum,partnum,kt));        pMatrixPress = Pp;
Tp = cat(3,pMatrixTemp(:,:,k),zeros(cellnum,partnum,kt));         pMatrixTemp = Tp;
xpCH4 = cat(3,pMatrixFrac_CH4(:,:,k),zeros(cellnum,partnum,kt));  pMatrixFrac_CH4 = xpCH4;
xpCO2 = cat(3,pMatrixFrac_CO2(:,:,k),zeros(cellnum,partnum,kt));  pMatrixFrac_CO2 = xpCO2;
xpH2O = cat(3,pMatrixFrac_H2O(:,:,k),zeros(cellnum,partnum,kt));  pMatrixFrac_H2O = xpH2O;
xpCO = cat(3,pMatrixFrac_CO(:,:,k),zeros(cellnum,partnum,kt));    pMatrixFrac_CO = xpCO;
xpH2 = cat(3,pMatrixFrac_H2(:,:,k),zeros(cellnum,partnum,kt));    pMatrixFrac_H2 = xpH2;
xpN2 = cat(3,pMatrixFrac_N2(:,:,k),zeros(cellnum,partnum,kt));    pMatrixFrac_N2 = xpN2;
xpO2 = cat(3,pMatrixFrac_O2(:,:,k),zeros(cellnum,partnum,kt));    pMatrixFrac_O2 = xpO2;
xpH2S = cat(3,pMatrixFrac_H2S(:,:,k),zeros(cellnum,partnum,kt));  pMatrixFrac_H2S = xpH2S;
xpMCH4 = cat(3,pMatrixFracM_CH4(:,:,k),zeros(cellnum,partnum,kt)); pMatrixFracM_CH4 = xpMCH4;
xpMCO2 = cat(3,pMatrixFracM_CO2(:,:,k),zeros(cellnum,partnum,kt)); pMatrixFracM_CO2 = xpMCO2;
xpMH2O = cat(3,pMatrixFracM_H2O(:,:,k),zeros(cellnum,partnum,kt)); pMatrixFracM_H2O = xpMH2O;
xpMCO = cat(3,pMatrixFracM_CO(:,:,k),zeros(cellnum,partnum,kt));  pMatrixFracM_CO = xpMCO;
xpMH2 = cat(3,pMatrixFracM_H2(:,:,k),zeros(cellnum,partnum,kt));  pMatrixFracM_H2 = xpMH2;
xpMN2 = cat(3,pMatrixFracM_N2(:,:,k),zeros(cellnum,partnum,kt));  pMatrixFracM_N2 = xpMN2;
xpMO2 = cat(3,pMatrixFracM_O2(:,:,k),zeros(cellnum,partnum,kt));  pMatrixFracM_O2 = xpMO2;
xpMH2S = cat(3,pMatrixFracM_H2S(:,:,k),zeros(cellnum,partnum,kt)); pMatrixFracM_H2S = xpMH2S;

p_rxn1 = zeros(cellnum,partnum,timestep); p_rxn1(:,:,1) = pMatrixRXN(:,:,k,1); 
pMatrixRXN(:,:,:,1) = p_rxn1;

p_rxn2 = zeros(cellnum,partnum,timestep); p_rxn2(:,:,1) = pMatrixRXN(:,:,k,2); 
pMatrixRXN(:,:,:,2) = p_rxn2;

p_rxn3 = zeros(cellnum,partnum,timestep); p_rxn2(:,:,1) = pMatrixRXN(:,:,k,3); 
pMatrixRXN(:,:,:,3) = p_rxn3;

rho_p = cat(3,pMatrixDens(:,:,k),zeros(cellnum,partnum,kt));        pMatrixDens(:,:,:) = rho_p;
cond_p = cat(3,pMatrix_cond(:,:,k),zeros(cellnum,partnum,kt));      pMatrix_cond(:,:,:) = cond_p;
Cp_p = cat(3,pMatrixCp(:,:,k),zeros(cellnum,partnum,kt));           pMatrixCp(:,:,:) = Cp_p;
rhoM_p = cat(3,pMatrixDensM(:,:,k),zeros(cellnum,partnum,kt));      pMatrixDensM(:,:,:) = rhoM_p;

% Catalyst pellet cell face data is transferred. 
Ppf = cat(3,pMeshPress(:,:,k),zeros(cellnum,partface,kt));          pMeshPress(:,:,:) = Ppf;
Tpf = cat(3,pMeshTemp(:,:,k),zeros(cellnum,partface,kt));           pMeshTemp(:,:,:) = Tpf;
xpCH4f = cat(3,pMeshFrac_CH4(:,:,k),zeros(cellnum,partface,kt));    pMeshFrac_CH4(:,:,:) = xpCH4f;
xpCO2f = cat(3,pMeshFrac_CO2(:,:,k),zeros(cellnum,partface,kt));    pMeshFrac_CO2(:,:,:) = xpCO2f;
xpH2Of = cat(3,pMeshFrac_H2O(:,:,k),zeros(cellnum,partface,kt));    pMeshFrac_H2O(:,:,:) = xpH2Of;
xpCOf = cat(3,pMeshFrac_CO(:,:,k),zeros(cellnum,partface,kt));      pMeshFrac_CO(:,:,:) = xpCOf;
xpH2f = cat(3,pMeshFrac_H2(:,:,k),zeros(cellnum,partface,kt));      pMeshFrac_H2(:,:,:) = xpH2f;
xpN2f = cat(3,pMeshFrac_N2(:,:,k),zeros(cellnum,partface,kt));      pMeshFrac_N2(:,:,:) = xpN2f;
xpO2f = cat(3,pMeshFrac_O2(:,:,k),zeros(cellnum,partface,kt));      pMeshFrac_O2(:,:,:) = xpO2f;
xpH2Sf = cat(3,pMeshFrac_H2S(:,:,k),zeros(cellnum,partface,kt));    pMeshFrac_H2S(:,:,:) = xpH2Sf;
xpMCH4f = cat(3,pMeshFracM_CH4(:,:,k),zeros(cellnum,partface,kt));  pMeshFracM_CH4(:,:,:) = xpMCH4f;
xpMCO2f = cat(3,pMeshFracM_CO2(:,:,k),zeros(cellnum,partface,kt));  pMeshFracM_CO2(:,:,:) = xpMCO2f;
xpMH2Of = cat(3,pMeshFracM_H2O(:,:,k),zeros(cellnum,partface,kt));  pMeshFracM_H2O(:,:,:) = xpMH2Of;
xpMCOf = cat(3,pMeshFracM_CO(:,:,k),zeros(cellnum,partface,kt));    pMeshFracM_CO(:,:,:) = xpMCOf;
xpMH2f = cat(3,pMeshFracM_H2(:,:,k),zeros(cellnum,partface,kt));    pMeshFracM_H2(:,:,:) = xpMH2f;
xpMN2f = cat(3,pMeshFracM_N2(:,:,k),zeros(cellnum,partface,kt));    pMeshFracM_N2(:,:,:) = xpMN2f;
xpMO2f = cat(3,pMeshFracM_O2(:,:,k),zeros(cellnum,partface,kt));    pMeshFracM_O2(:,:,:) = xpMO2f;
xpMH2Sf = cat(3,pMeshFracM_H2S(:,:,k),zeros(cellnum,partface,kt));  pMeshFracM_H2S(:,:,:) = xpMH2Sf;

pcondFace = cat(3,pMesh_cond(:,:,k),zeros(cellnum,partface,kt));    pMesh_cond(:,:,:) = pcondFace;
pCpFace = cat(3,pMeshCp(:,:,k),zeros(cellnum,partface,kt));         pMeshCp(:,:,:) = pCpFace;
pDensFace = cat(3,pMeshDens(:,:,k),zeros(cellnum,partface,kt));     pMeshDens(:,:,:) = pDensFace;
pDensFaceM = cat(3,pMeshDensM(:,:,k),zeros(cellnum,partface,kt));   pMeshDensM(:,:,:) = pDensFaceM;

for i = 1:cellnum
    pDCH4 = pdiff(i,:,k,1); pdiff(i,:,1,1) = pDCH4;
    pDCO2 = pdiff(i,:,k,2); pdiff(i,:,1,2) = pDCO2; 
    pDH2O = pdiff(i,:,k,3); pdiff(i,:,1,3) = pDH2O; 
    pDCO = pdiff(i,:,k,4); pdiff(i,:,1,4) = pDCO; 
    pDH2 = pdiff(i,:,k,5); pdiff(i,:,1,5) = pDH2; 
    pDN2 = pdiff(i,:,k,6); pdiff(i,:,1,6) = pDN2; 
    pDO2 = pdiff(i,:,k,7); pdiff(i,:,1,7) = pDO2; 
    pDH2S = pdiff(i,:,k,8); pdiff(i,:,1,8) = pDH2S; 
end

pdiff(:,:,2:timestep,1) = zeros(cellnum,partface,kt);
pdiff(:,:,2:timestep,2) = zeros(cellnum,partface,kt);
pdiff(:,:,2:timestep,3) = zeros(cellnum,partface,kt);
pdiff(:,:,2:timestep,4) = zeros(cellnum,partface,kt);
pdiff(:,:,2:timestep,5) = zeros(cellnum,partface,kt);
pdiff(:,:,2:timestep,6) = zeros(cellnum,partface,kt);
pdiff(:,:,2:timestep,7) = zeros(cellnum,partface,kt);
pdiff(:,:,2:timestep,8) = zeros(cellnum,partface,kt);

% Hydrogen sulfide data within the pellets is transferred. 
pH2S_Sat = cat(3,pwsat_H2S(:,:,k),zeros(cellnum,partnum,kt));      pwsat_H2S(:,:,:) = pH2S_Sat;
pH2S_Ads = cat(3,wp_H2S(:,:,k),zeros(cellnum,partnum,kt));         wp_H2S(:,:,:) = pH2S_Ads;
pH2S_Cov = cat(3,pCoverage(:,:,k),zeros(cellnum,partnum,kt));      pCoverage(:,:,:) = pH2S_Cov;

