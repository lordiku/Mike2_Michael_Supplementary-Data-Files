function rxns = RXNCalcVect(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, H2SCov, i, mech, mod)

% This function calculates the reaction rate, considering pressure,
% temperature, species concentrations, H2S coverage, and selected mechanism
% and modeling framework. 

% To prevent errors, any concentrations indicating 0% mole fraction are set
% to read slightly above 0%; reaction rate calculations can only accept
% non-zero values. 

if xMCH4 == 0
    xMCH4 = 1E-03;
end
if xMCO2 == 0
    xMCO2 = 1E-03;
end
if xMH2O == 0
    xMH2O = 1E-03;
end
if xMCO == 0
    xMCO = 1E-03;
end
if xMH2 == 0
    xMH2 = 1E-03;
end

if mech == 1

    % Xu & Froment, 1989
    % Steam Methane Reforming on Ni // MgAl2O4 spinel catalyst

    R = 8.3144598; % m^3*Pa/K/mol or J/K/mol, universal gas constant
    P = P./100000; % Convert pressure from Pa to bar; 

    % Convert concentrations to partial pressures, bar.
    PCH4 = P .* xMCH4; PCO2 = P .* xMCO2; PH2O = P .* xMH2O; PCO = P .* xMCO; 
    PH2 = P .* xMH2;

    % Activation energies and heats of adsorption, J/mol.
    E1 = 240100; E2 = 67130; E3 = 243900;
    H_CO = -70650; H_H2 = -82900; H_CH4 = -38280; H_H2O = 88680;

    % Rate coefficients & adsorption constants, from Arrhenius' Law, no dim.
    k1 = (4.225E15).*exp(-E1./R./T);    KCO = (8.23E-5).*exp(-H_CO./R./T);
    k2 = (1.955E6).*exp(-E2./R./T);     KH2 = (6.12E-9).*exp(-H_H2./R./T);
    k3 = (1.020E15).*exp(-E3./R./T);    KCH4 = (6.65E-4).*exp(-H_CH4./R./T);
                                        KH2O = (1.77E5).*exp(-H_H2O./R./T);

    % Equilibrium constants, no dim.
    % Calculated using shortcut rules from Hou & Hughes (2001).
    % 100 kPa --> 1 bar
    K1 = 1.198*(10.^17)*exp(-26830./T)/(100.^2);
    K2 = 1.767*(10.^-2)*exp(4400./T);
    K3 = 2.117*(10.^15)*exp(-22430./T)/(100.^2);

    % Denominator (adsorption) term is calculated. 
    DENDENCOV = ((1 + KCO.*PCO + KH2.*PH2 + KCH4.*PCH4 + KH2O.*PH2O./PH2).^2);

    % R1 - CH4 + H2O --> CO + 3H2
    % R2 - H2O + CO --> CO2 + H2
    % R3 - CH4 + 2H2O --> CO2 + 4H2

    % Reaction rates are computed. kmol/kgcat.hr
    % Calculates as kmol/kg.cat/hr
    r1 = (k1./(PH2.*PH2.*sqrt(PH2))).*(PCH4.*PH2O - (PH2.*PH2.*PH2).*PCO./K1)./DENDENCOV;
    r2 = (k2./PH2).*(PCO.*PH2O - PH2.*PCO2./K2)./DENDENCOV;
    r3 = (k3./(PH2.*PH2.*PH2.*sqrt(PH2))).*(PCH4.*(PH2O.*PH2O) - (PH2.*PH2.*PH2.*PH2).*PCO2./K3)./DENDENCOV;
    
    % A "damping" factor is used to match the CH4 conversion curve presented
    % by Koningen & Sjostrom, 1998. Details concerning the derivation of
    % this factor are given in the thesis. Note these factors are
    % calculated in the form of an Arrhenius expression. 

    if mod == 1
        DAMP = 34.472628730338 .* exp(-132730.975372756./(R.*T));
    else
        DAMP = 51.4815286002472 .* exp(-132660.038164189./(R.*T));
    end
    
    % Reaction rates are converted to the appropriate units, and a derating
    % of the reaction rate based on hydrogen sulfide concentration is made.
    % kmol/kgcat.hr * (1000 mol / kmol) * (1 hr / 3600 s) = mol/s/kg.cat;
    r1 = r1 .* (1000./3600) .* DAMP .* (1 - H2SCov);
    r2 = r2 .* (1000./3600) .* DAMP .* (1 - H2SCov);
    r3 = r3 .* (1000./3600) .* DAMP .* (1 - H2SCov);
    
elseif mech == 2 
    
    % Hou, Fowles, and Hughes, 1999/2000/2001
    % Steam Methane Reforming on Ni/alpha-alumina catalyst

    R = 8.3144598; % m^3*Pa/K/mol or J/K/mol, universal gas constant
    P = P./1000; % Convert pressure from Pa to kPa; 

    % Partial pressures, bar.
    PCH4 = P .* xMCH4; PCO2 = P .* xMCO2; PH2O = P .* xMH2O; PCO = P .* xMCO; 
    PH2 = P .* xMH2;
    
    % Activation energies and heats of adsorption, J/mol.
    E1 = 209200; E2 = 15400; E3 = 109400;
    H_CO = -140000; H_H = -93400; H_H2O = 15900;

    % Frequency factors & adsorption constants, from Arrhenius' Law, no dim.
    k1 = (5.922E8).*exp(-E1./R./T);     KCO = (5.127E-13).*exp(-H_CO./R./T);
    k2 = (6.028E-4).*exp(-E2./R./T);    KH = (5.680E-10).*exp(-H_H./R./T);
    k3 = (1.093E3).*exp(-E3./R./T);     KH2O = (9.251).*exp(-H_H2O./R./T);

    % Equilibrium constants, no dim.
    % Calculated using shortcut rules from Hou & Hughes (2001).
    % 100 kPa --> 1 bar
    K1 = 1.198*(10E17)*exp(-26830./T);
    K2 = 1.767*(10E-2)*exp(4400./T);
    K3 = 2.117*(10E15)*exp(-22430./T);

    % Denominator (adsorption) term is calculated. 
    DENDENCOV = ((1 + KCO.*PCO + KH.*PH2.^0.5 + KH2O.*PH2O./PH2).^2);

    % R1 - CH4 + H2O --> CO + 3H2
    % R2 - H2O + CO --> CO2 + H2
    % R3 - CH4 + 2H2O --> CO2 + 4H2

    % Reaction rates are computed. kmol/kgcat.hr
    % Calculates as kmol/kg.cat/hr
    r1 = (k1.*PCH4.*sqrt(PH2O)./(PH2.*PH2.^0.25)).*(1 - (PH2.^3).*PCO./(PCH4.*PH2O.*K1))./DENDENCOV;
    r2 = (k2.*PCO.*sqrt(PH2O)./sqrt(PH2)).*(1 - PH2.*PCO2./(K2.*PCO.*PH2O))./DENDENCOV;
    r3 = (k3.*PCH4.*PH2O./(PH2.*PH2.^0.75)).*(1 - (PH2.^4).*PCO2./(K3.*PCH4.*(PH2O.^2)))./DENDENCOV;
    
    % A "damping" factor is used to match the CH4 conversion curve presented
    % by Koningen & Sjostrom, 1998. Details concerning the derivation of
    % this factor are given in the thesis. Note these factors are
    % calculated in the form of an Arrhenius expression. 
    
    if mod == 1
        DAMP = 0.000883186649778941 .* exp(-24366.6435943481./(8.314459.*T));
    else
        DAMP = 0.00182122510349451 .* exp(-26983.7763823146./(8.314459.*T));
    end

    % Reaction rates are converted to the appropriate units, and a derating
    % of the reaction rate based on hydrogen sulfide concentration is made.
    % kmol/kgcat.hr * (1000 mol / kmol) * (1 hr / 3600 s) = mol/s/kg.cat;
    r1 = r1 .* 1000 .* DAMP .* (1 - H2SCov);
    r2 = r2 .* 1000 .* DAMP .* (1 - H2SCov);
    r3 = r3 .* 1000 .* DAMP .* (1 - H2SCov);
    
end

    % Rates are returned as a vector. 
    rxns = horzcat(r1, r2, r3, K1, K2, K3);

end